--
-- PostgreSQL database cluster dump
--

SET default_transaction_read_only = off;

SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;

--
-- Roles
--







--
-- Databases
--

--
-- Database "template1" dump
--

\connect template1

--
-- PostgreSQL database dump
--

-- Dumped from database version 13.3 (Debian 13.3-1.pgdg100+1)
-- Dumped by pg_dump version 13.3 (Debian 13.3-1.pgdg100+1)

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- PostgreSQL database dump complete
--

--
-- Database "keycloak" dump
--

--
-- PostgreSQL database dump
--

-- Dumped from database version 13.3 (Debian 13.3-1.pgdg100+1)
-- Dumped by pg_dump version 13.3 (Debian 13.3-1.pgdg100+1)

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- Name: keycloak; Type: DATABASE; Schema: -; Owner: keycloak
--



ALTER DATABASE keycloak OWNER TO keycloak;

\connect keycloak

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: admin_event_entity; Type: TABLE; Schema: public; Owner: keycloak
--

CREATE TABLE public.admin_event_entity (
    id character varying(36) NOT NULL,
    admin_event_time bigint,
    realm_id character varying(255),
    operation_type character varying(255),
    auth_realm_id character varying(255),
    auth_client_id character varying(255),
    auth_user_id character varying(255),
    ip_address character varying(255),
    resource_path character varying(2550),
    representation text,
    error character varying(255),
    resource_type character varying(64)
);


ALTER TABLE public.admin_event_entity OWNER TO keycloak;

--
-- Name: associated_policy; Type: TABLE; Schema: public; Owner: keycloak
--

CREATE TABLE public.associated_policy (
    policy_id character varying(36) NOT NULL,
    associated_policy_id character varying(36) NOT NULL
);


ALTER TABLE public.associated_policy OWNER TO keycloak;

--
-- Name: authentication_execution; Type: TABLE; Schema: public; Owner: keycloak
--

CREATE TABLE public.authentication_execution (
    id character varying(36) NOT NULL,
    alias character varying(255),
    authenticator character varying(36),
    realm_id character varying(36),
    flow_id character varying(36),
    requirement integer,
    priority integer,
    authenticator_flow boolean DEFAULT false NOT NULL,
    auth_flow_id character varying(36),
    auth_config character varying(36)
);


ALTER TABLE public.authentication_execution OWNER TO keycloak;

--
-- Name: authentication_flow; Type: TABLE; Schema: public; Owner: keycloak
--

CREATE TABLE public.authentication_flow (
    id character varying(36) NOT NULL,
    alias character varying(255),
    description character varying(255),
    realm_id character varying(36),
    provider_id character varying(36) DEFAULT 'basic-flow'::character varying NOT NULL,
    top_level boolean DEFAULT false NOT NULL,
    built_in boolean DEFAULT false NOT NULL
);


ALTER TABLE public.authentication_flow OWNER TO keycloak;

--
-- Name: authenticator_config; Type: TABLE; Schema: public; Owner: keycloak
--

CREATE TABLE public.authenticator_config (
    id character varying(36) NOT NULL,
    alias character varying(255),
    realm_id character varying(36)
);


ALTER TABLE public.authenticator_config OWNER TO keycloak;

--
-- Name: authenticator_config_entry; Type: TABLE; Schema: public; Owner: keycloak
--

CREATE TABLE public.authenticator_config_entry (
    authenticator_id character varying(36) NOT NULL,
    value text,
    name character varying(255) NOT NULL
);


ALTER TABLE public.authenticator_config_entry OWNER TO keycloak;

--
-- Name: broker_link; Type: TABLE; Schema: public; Owner: keycloak
--

CREATE TABLE public.broker_link (
    identity_provider character varying(255) NOT NULL,
    storage_provider_id character varying(255),
    realm_id character varying(36) NOT NULL,
    broker_user_id character varying(255),
    broker_username character varying(255),
    token text,
    user_id character varying(255) NOT NULL
);


ALTER TABLE public.broker_link OWNER TO keycloak;

--
-- Name: client; Type: TABLE; Schema: public; Owner: keycloak
--

CREATE TABLE public.client (
    id character varying(36) NOT NULL,
    enabled boolean DEFAULT false NOT NULL,
    full_scope_allowed boolean DEFAULT false NOT NULL,
    client_id character varying(255),
    not_before integer,
    public_client boolean DEFAULT false NOT NULL,
    secret character varying(255),
    base_url character varying(255),
    bearer_only boolean DEFAULT false NOT NULL,
    management_url character varying(255),
    surrogate_auth_required boolean DEFAULT false NOT NULL,
    realm_id character varying(36),
    protocol character varying(255),
    node_rereg_timeout integer DEFAULT 0,
    frontchannel_logout boolean DEFAULT false NOT NULL,
    consent_required boolean DEFAULT false NOT NULL,
    name character varying(255),
    service_accounts_enabled boolean DEFAULT false NOT NULL,
    client_authenticator_type character varying(255),
    root_url character varying(255),
    description character varying(255),
    registration_token character varying(255),
    standard_flow_enabled boolean DEFAULT true NOT NULL,
    implicit_flow_enabled boolean DEFAULT false NOT NULL,
    direct_access_grants_enabled boolean DEFAULT false NOT NULL,
    always_display_in_console boolean DEFAULT false NOT NULL
);


ALTER TABLE public.client OWNER TO keycloak;

--
-- Name: client_attributes; Type: TABLE; Schema: public; Owner: keycloak
--

CREATE TABLE public.client_attributes (
    client_id character varying(36) NOT NULL,
    value character varying(4000),
    name character varying(255) NOT NULL
);


ALTER TABLE public.client_attributes OWNER TO keycloak;

--
-- Name: client_auth_flow_bindings; Type: TABLE; Schema: public; Owner: keycloak
--

CREATE TABLE public.client_auth_flow_bindings (
    client_id character varying(36) NOT NULL,
    flow_id character varying(36),
    binding_name character varying(255) NOT NULL
);


ALTER TABLE public.client_auth_flow_bindings OWNER TO keycloak;

--
-- Name: client_initial_access; Type: TABLE; Schema: public; Owner: keycloak
--

CREATE TABLE public.client_initial_access (
    id character varying(36) NOT NULL,
    realm_id character varying(36) NOT NULL,
    "timestamp" integer,
    expiration integer,
    count integer,
    remaining_count integer
);


ALTER TABLE public.client_initial_access OWNER TO keycloak;

--
-- Name: client_node_registrations; Type: TABLE; Schema: public; Owner: keycloak
--

CREATE TABLE public.client_node_registrations (
    client_id character varying(36) NOT NULL,
    value integer,
    name character varying(255) NOT NULL
);


ALTER TABLE public.client_node_registrations OWNER TO keycloak;

--
-- Name: client_scope; Type: TABLE; Schema: public; Owner: keycloak
--

CREATE TABLE public.client_scope (
    id character varying(36) NOT NULL,
    name character varying(255),
    realm_id character varying(36),
    description character varying(255),
    protocol character varying(255)
);


ALTER TABLE public.client_scope OWNER TO keycloak;

--
-- Name: client_scope_attributes; Type: TABLE; Schema: public; Owner: keycloak
--

CREATE TABLE public.client_scope_attributes (
    scope_id character varying(36) NOT NULL,
    value character varying(2048),
    name character varying(255) NOT NULL
);


ALTER TABLE public.client_scope_attributes OWNER TO keycloak;

--
-- Name: client_scope_client; Type: TABLE; Schema: public; Owner: keycloak
--

CREATE TABLE public.client_scope_client (
    client_id character varying(255) NOT NULL,
    scope_id character varying(255) NOT NULL,
    default_scope boolean DEFAULT false NOT NULL
);


ALTER TABLE public.client_scope_client OWNER TO keycloak;

--
-- Name: client_scope_role_mapping; Type: TABLE; Schema: public; Owner: keycloak
--

CREATE TABLE public.client_scope_role_mapping (
    scope_id character varying(36) NOT NULL,
    role_id character varying(36) NOT NULL
);


ALTER TABLE public.client_scope_role_mapping OWNER TO keycloak;

--
-- Name: client_session; Type: TABLE; Schema: public; Owner: keycloak
--

CREATE TABLE public.client_session (
    id character varying(36) NOT NULL,
    client_id character varying(36),
    redirect_uri character varying(255),
    state character varying(255),
    "timestamp" integer,
    session_id character varying(36),
    auth_method character varying(255),
    realm_id character varying(255),
    auth_user_id character varying(36),
    current_action character varying(36)
);


ALTER TABLE public.client_session OWNER TO keycloak;

--
-- Name: client_session_auth_status; Type: TABLE; Schema: public; Owner: keycloak
--

CREATE TABLE public.client_session_auth_status (
    authenticator character varying(36) NOT NULL,
    status integer,
    client_session character varying(36) NOT NULL
);


ALTER TABLE public.client_session_auth_status OWNER TO keycloak;

--
-- Name: client_session_note; Type: TABLE; Schema: public; Owner: keycloak
--

CREATE TABLE public.client_session_note (
    name character varying(255) NOT NULL,
    value character varying(255),
    client_session character varying(36) NOT NULL
);


ALTER TABLE public.client_session_note OWNER TO keycloak;

--
-- Name: client_session_prot_mapper; Type: TABLE; Schema: public; Owner: keycloak
--

CREATE TABLE public.client_session_prot_mapper (
    protocol_mapper_id character varying(36) NOT NULL,
    client_session character varying(36) NOT NULL
);


ALTER TABLE public.client_session_prot_mapper OWNER TO keycloak;

--
-- Name: client_session_role; Type: TABLE; Schema: public; Owner: keycloak
--

CREATE TABLE public.client_session_role (
    role_id character varying(255) NOT NULL,
    client_session character varying(36) NOT NULL
);


ALTER TABLE public.client_session_role OWNER TO keycloak;

--
-- Name: client_user_session_note; Type: TABLE; Schema: public; Owner: keycloak
--

CREATE TABLE public.client_user_session_note (
    name character varying(255) NOT NULL,
    value character varying(2048),
    client_session character varying(36) NOT NULL
);


ALTER TABLE public.client_user_session_note OWNER TO keycloak;

--
-- Name: component; Type: TABLE; Schema: public; Owner: keycloak
--

CREATE TABLE public.component (
    id character varying(36) NOT NULL,
    name character varying(255),
    parent_id character varying(36),
    provider_id character varying(36),
    provider_type character varying(255),
    realm_id character varying(36),
    sub_type character varying(255)
);


ALTER TABLE public.component OWNER TO keycloak;

--
-- Name: component_config; Type: TABLE; Schema: public; Owner: keycloak
--

CREATE TABLE public.component_config (
    id character varying(36) NOT NULL,
    component_id character varying(36) NOT NULL,
    name character varying(255) NOT NULL,
    value character varying(4000)
);


ALTER TABLE public.component_config OWNER TO keycloak;

--
-- Name: composite_role; Type: TABLE; Schema: public; Owner: keycloak
--

CREATE TABLE public.composite_role (
    composite character varying(36) NOT NULL,
    child_role character varying(36) NOT NULL
);


ALTER TABLE public.composite_role OWNER TO keycloak;

--
-- Name: credential; Type: TABLE; Schema: public; Owner: keycloak
--

CREATE TABLE public.credential (
    id character varying(36) NOT NULL,
    salt bytea,
    type character varying(255),
    user_id character varying(36),
    created_date bigint,
    user_label character varying(255),
    secret_data text,
    credential_data text,
    priority integer
);


ALTER TABLE public.credential OWNER TO keycloak;

--
-- Name: databasechangelog; Type: TABLE; Schema: public; Owner: keycloak
--

CREATE TABLE public.databasechangelog (
    id character varying(255) NOT NULL,
    author character varying(255) NOT NULL,
    filename character varying(255) NOT NULL,
    dateexecuted timestamp without time zone NOT NULL,
    orderexecuted integer NOT NULL,
    exectype character varying(10) NOT NULL,
    md5sum character varying(35),
    description character varying(255),
    comments character varying(255),
    tag character varying(255),
    liquibase character varying(20),
    contexts character varying(255),
    labels character varying(255),
    deployment_id character varying(10)
);


ALTER TABLE public.databasechangelog OWNER TO keycloak;

--
-- Name: databasechangeloglock; Type: TABLE; Schema: public; Owner: keycloak
--

CREATE TABLE public.databasechangeloglock (
    id integer NOT NULL,
    locked boolean NOT NULL,
    lockgranted timestamp without time zone,
    lockedby character varying(255)
);


ALTER TABLE public.databasechangeloglock OWNER TO keycloak;

--
-- Name: default_client_scope; Type: TABLE; Schema: public; Owner: keycloak
--

CREATE TABLE public.default_client_scope (
    realm_id character varying(36) NOT NULL,
    scope_id character varying(36) NOT NULL,
    default_scope boolean DEFAULT false NOT NULL
);


ALTER TABLE public.default_client_scope OWNER TO keycloak;

--
-- Name: event_entity; Type: TABLE; Schema: public; Owner: keycloak
--

CREATE TABLE public.event_entity (
    id character varying(36) NOT NULL,
    client_id character varying(255),
    details_json character varying(2550),
    error character varying(255),
    ip_address character varying(255),
    realm_id character varying(255),
    session_id character varying(255),
    event_time bigint,
    type character varying(255),
    user_id character varying(255)
);


ALTER TABLE public.event_entity OWNER TO keycloak;

--
-- Name: fed_user_attribute; Type: TABLE; Schema: public; Owner: keycloak
--

CREATE TABLE public.fed_user_attribute (
    id character varying(36) NOT NULL,
    name character varying(255) NOT NULL,
    user_id character varying(255) NOT NULL,
    realm_id character varying(36) NOT NULL,
    storage_provider_id character varying(36),
    value character varying(2024)
);


ALTER TABLE public.fed_user_attribute OWNER TO keycloak;

--
-- Name: fed_user_consent; Type: TABLE; Schema: public; Owner: keycloak
--

CREATE TABLE public.fed_user_consent (
    id character varying(36) NOT NULL,
    client_id character varying(255),
    user_id character varying(255) NOT NULL,
    realm_id character varying(36) NOT NULL,
    storage_provider_id character varying(36),
    created_date bigint,
    last_updated_date bigint,
    client_storage_provider character varying(36),
    external_client_id character varying(255)
);


ALTER TABLE public.fed_user_consent OWNER TO keycloak;

--
-- Name: fed_user_consent_cl_scope; Type: TABLE; Schema: public; Owner: keycloak
--

CREATE TABLE public.fed_user_consent_cl_scope (
    user_consent_id character varying(36) NOT NULL,
    scope_id character varying(36) NOT NULL
);


ALTER TABLE public.fed_user_consent_cl_scope OWNER TO keycloak;

--
-- Name: fed_user_credential; Type: TABLE; Schema: public; Owner: keycloak
--

CREATE TABLE public.fed_user_credential (
    id character varying(36) NOT NULL,
    salt bytea,
    type character varying(255),
    created_date bigint,
    user_id character varying(255) NOT NULL,
    realm_id character varying(36) NOT NULL,
    storage_provider_id character varying(36),
    user_label character varying(255),
    secret_data text,
    credential_data text,
    priority integer
);


ALTER TABLE public.fed_user_credential OWNER TO keycloak;

--
-- Name: fed_user_group_membership; Type: TABLE; Schema: public; Owner: keycloak
--

CREATE TABLE public.fed_user_group_membership (
    group_id character varying(36) NOT NULL,
    user_id character varying(255) NOT NULL,
    realm_id character varying(36) NOT NULL,
    storage_provider_id character varying(36)
);


ALTER TABLE public.fed_user_group_membership OWNER TO keycloak;

--
-- Name: fed_user_required_action; Type: TABLE; Schema: public; Owner: keycloak
--

CREATE TABLE public.fed_user_required_action (
    required_action character varying(255) DEFAULT ' '::character varying NOT NULL,
    user_id character varying(255) NOT NULL,
    realm_id character varying(36) NOT NULL,
    storage_provider_id character varying(36)
);


ALTER TABLE public.fed_user_required_action OWNER TO keycloak;

--
-- Name: fed_user_role_mapping; Type: TABLE; Schema: public; Owner: keycloak
--

CREATE TABLE public.fed_user_role_mapping (
    role_id character varying(36) NOT NULL,
    user_id character varying(255) NOT NULL,
    realm_id character varying(36) NOT NULL,
    storage_provider_id character varying(36)
);


ALTER TABLE public.fed_user_role_mapping OWNER TO keycloak;

--
-- Name: federated_identity; Type: TABLE; Schema: public; Owner: keycloak
--

CREATE TABLE public.federated_identity (
    identity_provider character varying(255) NOT NULL,
    realm_id character varying(36),
    federated_user_id character varying(255),
    federated_username character varying(255),
    token text,
    user_id character varying(36) NOT NULL
);


ALTER TABLE public.federated_identity OWNER TO keycloak;

--
-- Name: federated_user; Type: TABLE; Schema: public; Owner: keycloak
--

CREATE TABLE public.federated_user (
    id character varying(255) NOT NULL,
    storage_provider_id character varying(255),
    realm_id character varying(36) NOT NULL
);


ALTER TABLE public.federated_user OWNER TO keycloak;

--
-- Name: group_attribute; Type: TABLE; Schema: public; Owner: keycloak
--

CREATE TABLE public.group_attribute (
    id character varying(36) DEFAULT 'sybase-needs-something-here'::character varying NOT NULL,
    name character varying(255) NOT NULL,
    value character varying(255),
    group_id character varying(36) NOT NULL
);


ALTER TABLE public.group_attribute OWNER TO keycloak;

--
-- Name: group_role_mapping; Type: TABLE; Schema: public; Owner: keycloak
--

CREATE TABLE public.group_role_mapping (
    role_id character varying(36) NOT NULL,
    group_id character varying(36) NOT NULL
);


ALTER TABLE public.group_role_mapping OWNER TO keycloak;

--
-- Name: identity_provider; Type: TABLE; Schema: public; Owner: keycloak
--

CREATE TABLE public.identity_provider (
    internal_id character varying(36) NOT NULL,
    enabled boolean DEFAULT false NOT NULL,
    provider_alias character varying(255),
    provider_id character varying(255),
    store_token boolean DEFAULT false NOT NULL,
    authenticate_by_default boolean DEFAULT false NOT NULL,
    realm_id character varying(36),
    add_token_role boolean DEFAULT true NOT NULL,
    trust_email boolean DEFAULT false NOT NULL,
    first_broker_login_flow_id character varying(36),
    post_broker_login_flow_id character varying(36),
    provider_display_name character varying(255),
    link_only boolean DEFAULT false NOT NULL
);


ALTER TABLE public.identity_provider OWNER TO keycloak;

--
-- Name: identity_provider_config; Type: TABLE; Schema: public; Owner: keycloak
--

CREATE TABLE public.identity_provider_config (
    identity_provider_id character varying(36) NOT NULL,
    value text,
    name character varying(255) NOT NULL
);


ALTER TABLE public.identity_provider_config OWNER TO keycloak;

--
-- Name: identity_provider_mapper; Type: TABLE; Schema: public; Owner: keycloak
--

CREATE TABLE public.identity_provider_mapper (
    id character varying(36) NOT NULL,
    name character varying(255) NOT NULL,
    idp_alias character varying(255) NOT NULL,
    idp_mapper_name character varying(255) NOT NULL,
    realm_id character varying(36) NOT NULL
);


ALTER TABLE public.identity_provider_mapper OWNER TO keycloak;

--
-- Name: idp_mapper_config; Type: TABLE; Schema: public; Owner: keycloak
--

CREATE TABLE public.idp_mapper_config (
    idp_mapper_id character varying(36) NOT NULL,
    value text,
    name character varying(255) NOT NULL
);


ALTER TABLE public.idp_mapper_config OWNER TO keycloak;

--
-- Name: keycloak_group; Type: TABLE; Schema: public; Owner: keycloak
--

CREATE TABLE public.keycloak_group (
    id character varying(36) NOT NULL,
    name character varying(255),
    parent_group character varying(36) NOT NULL,
    realm_id character varying(36)
);


ALTER TABLE public.keycloak_group OWNER TO keycloak;

--
-- Name: keycloak_role; Type: TABLE; Schema: public; Owner: keycloak
--

CREATE TABLE public.keycloak_role (
    id character varying(36) NOT NULL,
    client_realm_constraint character varying(255),
    client_role boolean DEFAULT false NOT NULL,
    description character varying(255),
    name character varying(255),
    realm_id character varying(255),
    client character varying(36),
    realm character varying(36)
);


ALTER TABLE public.keycloak_role OWNER TO keycloak;

--
-- Name: migration_model; Type: TABLE; Schema: public; Owner: keycloak
--

CREATE TABLE public.migration_model (
    id character varying(36) NOT NULL,
    version character varying(36),
    update_time bigint DEFAULT 0 NOT NULL
);


ALTER TABLE public.migration_model OWNER TO keycloak;

--
-- Name: offline_client_session; Type: TABLE; Schema: public; Owner: keycloak
--

CREATE TABLE public.offline_client_session (
    user_session_id character varying(36) NOT NULL,
    client_id character varying(255) NOT NULL,
    offline_flag character varying(4) NOT NULL,
    "timestamp" integer,
    data text,
    client_storage_provider character varying(36) DEFAULT 'local'::character varying NOT NULL,
    external_client_id character varying(255) DEFAULT 'local'::character varying NOT NULL
);


ALTER TABLE public.offline_client_session OWNER TO keycloak;

--
-- Name: offline_user_session; Type: TABLE; Schema: public; Owner: keycloak
--

CREATE TABLE public.offline_user_session (
    user_session_id character varying(36) NOT NULL,
    user_id character varying(255) NOT NULL,
    realm_id character varying(36) NOT NULL,
    created_on integer NOT NULL,
    offline_flag character varying(4) NOT NULL,
    data text,
    last_session_refresh integer DEFAULT 0 NOT NULL
);


ALTER TABLE public.offline_user_session OWNER TO keycloak;

--
-- Name: policy_config; Type: TABLE; Schema: public; Owner: keycloak
--

CREATE TABLE public.policy_config (
    policy_id character varying(36) NOT NULL,
    name character varying(255) NOT NULL,
    value text
);


ALTER TABLE public.policy_config OWNER TO keycloak;

--
-- Name: protocol_mapper; Type: TABLE; Schema: public; Owner: keycloak
--

CREATE TABLE public.protocol_mapper (
    id character varying(36) NOT NULL,
    name character varying(255) NOT NULL,
    protocol character varying(255) NOT NULL,
    protocol_mapper_name character varying(255) NOT NULL,
    client_id character varying(36),
    client_scope_id character varying(36)
);


ALTER TABLE public.protocol_mapper OWNER TO keycloak;

--
-- Name: protocol_mapper_config; Type: TABLE; Schema: public; Owner: keycloak
--

CREATE TABLE public.protocol_mapper_config (
    protocol_mapper_id character varying(36) NOT NULL,
    value text,
    name character varying(255) NOT NULL
);


ALTER TABLE public.protocol_mapper_config OWNER TO keycloak;

--
-- Name: realm; Type: TABLE; Schema: public; Owner: keycloak
--

CREATE TABLE public.realm (
    id character varying(36) NOT NULL,
    access_code_lifespan integer,
    user_action_lifespan integer,
    access_token_lifespan integer,
    account_theme character varying(255),
    admin_theme character varying(255),
    email_theme character varying(255),
    enabled boolean DEFAULT false NOT NULL,
    events_enabled boolean DEFAULT false NOT NULL,
    events_expiration bigint,
    login_theme character varying(255),
    name character varying(255),
    not_before integer,
    password_policy character varying(2550),
    registration_allowed boolean DEFAULT false NOT NULL,
    remember_me boolean DEFAULT false NOT NULL,
    reset_password_allowed boolean DEFAULT false NOT NULL,
    social boolean DEFAULT false NOT NULL,
    ssl_required character varying(255),
    sso_idle_timeout integer,
    sso_max_lifespan integer,
    update_profile_on_soc_login boolean DEFAULT false NOT NULL,
    verify_email boolean DEFAULT false NOT NULL,
    master_admin_client character varying(36),
    login_lifespan integer,
    internationalization_enabled boolean DEFAULT false NOT NULL,
    default_locale character varying(255),
    reg_email_as_username boolean DEFAULT false NOT NULL,
    admin_events_enabled boolean DEFAULT false NOT NULL,
    admin_events_details_enabled boolean DEFAULT false NOT NULL,
    edit_username_allowed boolean DEFAULT false NOT NULL,
    otp_policy_counter integer DEFAULT 0,
    otp_policy_window integer DEFAULT 1,
    otp_policy_period integer DEFAULT 30,
    otp_policy_digits integer DEFAULT 6,
    otp_policy_alg character varying(36) DEFAULT 'HmacSHA1'::character varying,
    otp_policy_type character varying(36) DEFAULT 'totp'::character varying,
    browser_flow character varying(36),
    registration_flow character varying(36),
    direct_grant_flow character varying(36),
    reset_credentials_flow character varying(36),
    client_auth_flow character varying(36),
    offline_session_idle_timeout integer DEFAULT 0,
    revoke_refresh_token boolean DEFAULT false NOT NULL,
    access_token_life_implicit integer DEFAULT 0,
    login_with_email_allowed boolean DEFAULT true NOT NULL,
    duplicate_emails_allowed boolean DEFAULT false NOT NULL,
    docker_auth_flow character varying(36),
    refresh_token_max_reuse integer DEFAULT 0,
    allow_user_managed_access boolean DEFAULT false NOT NULL,
    sso_max_lifespan_remember_me integer DEFAULT 0 NOT NULL,
    sso_idle_timeout_remember_me integer DEFAULT 0 NOT NULL,
    default_role character varying(255)
);


ALTER TABLE public.realm OWNER TO keycloak;

--
-- Name: realm_attribute; Type: TABLE; Schema: public; Owner: keycloak
--

CREATE TABLE public.realm_attribute (
    name character varying(255) NOT NULL,
    realm_id character varying(36) NOT NULL,
    value text
);


ALTER TABLE public.realm_attribute OWNER TO keycloak;

--
-- Name: realm_default_groups; Type: TABLE; Schema: public; Owner: keycloak
--

CREATE TABLE public.realm_default_groups (
    realm_id character varying(36) NOT NULL,
    group_id character varying(36) NOT NULL
);


ALTER TABLE public.realm_default_groups OWNER TO keycloak;

--
-- Name: realm_enabled_event_types; Type: TABLE; Schema: public; Owner: keycloak
--

CREATE TABLE public.realm_enabled_event_types (
    realm_id character varying(36) NOT NULL,
    value character varying(255) NOT NULL
);


ALTER TABLE public.realm_enabled_event_types OWNER TO keycloak;

--
-- Name: realm_events_listeners; Type: TABLE; Schema: public; Owner: keycloak
--

CREATE TABLE public.realm_events_listeners (
    realm_id character varying(36) NOT NULL,
    value character varying(255) NOT NULL
);


ALTER TABLE public.realm_events_listeners OWNER TO keycloak;

--
-- Name: realm_localizations; Type: TABLE; Schema: public; Owner: keycloak
--

CREATE TABLE public.realm_localizations (
    realm_id character varying(255) NOT NULL,
    locale character varying(255) NOT NULL,
    texts text NOT NULL
);


ALTER TABLE public.realm_localizations OWNER TO keycloak;

--
-- Name: realm_required_credential; Type: TABLE; Schema: public; Owner: keycloak
--

CREATE TABLE public.realm_required_credential (
    type character varying(255) NOT NULL,
    form_label character varying(255),
    input boolean DEFAULT false NOT NULL,
    secret boolean DEFAULT false NOT NULL,
    realm_id character varying(36) NOT NULL
);


ALTER TABLE public.realm_required_credential OWNER TO keycloak;

--
-- Name: realm_smtp_config; Type: TABLE; Schema: public; Owner: keycloak
--

CREATE TABLE public.realm_smtp_config (
    realm_id character varying(36) NOT NULL,
    value character varying(255),
    name character varying(255) NOT NULL
);


ALTER TABLE public.realm_smtp_config OWNER TO keycloak;

--
-- Name: realm_supported_locales; Type: TABLE; Schema: public; Owner: keycloak
--

CREATE TABLE public.realm_supported_locales (
    realm_id character varying(36) NOT NULL,
    value character varying(255) NOT NULL
);


ALTER TABLE public.realm_supported_locales OWNER TO keycloak;

--
-- Name: redirect_uris; Type: TABLE; Schema: public; Owner: keycloak
--

CREATE TABLE public.redirect_uris (
    client_id character varying(36) NOT NULL,
    value character varying(255) NOT NULL
);


ALTER TABLE public.redirect_uris OWNER TO keycloak;

--
-- Name: required_action_config; Type: TABLE; Schema: public; Owner: keycloak
--

CREATE TABLE public.required_action_config (
    required_action_id character varying(36) NOT NULL,
    value text,
    name character varying(255) NOT NULL
);


ALTER TABLE public.required_action_config OWNER TO keycloak;

--
-- Name: required_action_provider; Type: TABLE; Schema: public; Owner: keycloak
--

CREATE TABLE public.required_action_provider (
    id character varying(36) NOT NULL,
    alias character varying(255),
    name character varying(255),
    realm_id character varying(36),
    enabled boolean DEFAULT false NOT NULL,
    default_action boolean DEFAULT false NOT NULL,
    provider_id character varying(255),
    priority integer
);


ALTER TABLE public.required_action_provider OWNER TO keycloak;

--
-- Name: resource_attribute; Type: TABLE; Schema: public; Owner: keycloak
--

CREATE TABLE public.resource_attribute (
    id character varying(36) DEFAULT 'sybase-needs-something-here'::character varying NOT NULL,
    name character varying(255) NOT NULL,
    value character varying(255),
    resource_id character varying(36) NOT NULL
);


ALTER TABLE public.resource_attribute OWNER TO keycloak;

--
-- Name: resource_policy; Type: TABLE; Schema: public; Owner: keycloak
--

CREATE TABLE public.resource_policy (
    resource_id character varying(36) NOT NULL,
    policy_id character varying(36) NOT NULL
);


ALTER TABLE public.resource_policy OWNER TO keycloak;

--
-- Name: resource_scope; Type: TABLE; Schema: public; Owner: keycloak
--

CREATE TABLE public.resource_scope (
    resource_id character varying(36) NOT NULL,
    scope_id character varying(36) NOT NULL
);


ALTER TABLE public.resource_scope OWNER TO keycloak;

--
-- Name: resource_server; Type: TABLE; Schema: public; Owner: keycloak
--

CREATE TABLE public.resource_server (
    id character varying(36) NOT NULL,
    allow_rs_remote_mgmt boolean DEFAULT false NOT NULL,
    policy_enforce_mode character varying(15) NOT NULL,
    decision_strategy smallint DEFAULT 1 NOT NULL
);


ALTER TABLE public.resource_server OWNER TO keycloak;

--
-- Name: resource_server_perm_ticket; Type: TABLE; Schema: public; Owner: keycloak
--

CREATE TABLE public.resource_server_perm_ticket (
    id character varying(36) NOT NULL,
    owner character varying(255) NOT NULL,
    requester character varying(255) NOT NULL,
    created_timestamp bigint NOT NULL,
    granted_timestamp bigint,
    resource_id character varying(36) NOT NULL,
    scope_id character varying(36),
    resource_server_id character varying(36) NOT NULL,
    policy_id character varying(36)
);


ALTER TABLE public.resource_server_perm_ticket OWNER TO keycloak;

--
-- Name: resource_server_policy; Type: TABLE; Schema: public; Owner: keycloak
--

CREATE TABLE public.resource_server_policy (
    id character varying(36) NOT NULL,
    name character varying(255) NOT NULL,
    description character varying(255),
    type character varying(255) NOT NULL,
    decision_strategy character varying(20),
    logic character varying(20),
    resource_server_id character varying(36) NOT NULL,
    owner character varying(255)
);


ALTER TABLE public.resource_server_policy OWNER TO keycloak;

--
-- Name: resource_server_resource; Type: TABLE; Schema: public; Owner: keycloak
--

CREATE TABLE public.resource_server_resource (
    id character varying(36) NOT NULL,
    name character varying(255) NOT NULL,
    type character varying(255),
    icon_uri character varying(255),
    owner character varying(255) NOT NULL,
    resource_server_id character varying(36) NOT NULL,
    owner_managed_access boolean DEFAULT false NOT NULL,
    display_name character varying(255)
);


ALTER TABLE public.resource_server_resource OWNER TO keycloak;

--
-- Name: resource_server_scope; Type: TABLE; Schema: public; Owner: keycloak
--

CREATE TABLE public.resource_server_scope (
    id character varying(36) NOT NULL,
    name character varying(255) NOT NULL,
    icon_uri character varying(255),
    resource_server_id character varying(36) NOT NULL,
    display_name character varying(255)
);


ALTER TABLE public.resource_server_scope OWNER TO keycloak;

--
-- Name: resource_uris; Type: TABLE; Schema: public; Owner: keycloak
--

CREATE TABLE public.resource_uris (
    resource_id character varying(36) NOT NULL,
    value character varying(255) NOT NULL
);


ALTER TABLE public.resource_uris OWNER TO keycloak;

--
-- Name: role_attribute; Type: TABLE; Schema: public; Owner: keycloak
--

CREATE TABLE public.role_attribute (
    id character varying(36) NOT NULL,
    role_id character varying(36) NOT NULL,
    name character varying(255) NOT NULL,
    value character varying(255)
);


ALTER TABLE public.role_attribute OWNER TO keycloak;

--
-- Name: scope_mapping; Type: TABLE; Schema: public; Owner: keycloak
--

CREATE TABLE public.scope_mapping (
    client_id character varying(36) NOT NULL,
    role_id character varying(36) NOT NULL
);


ALTER TABLE public.scope_mapping OWNER TO keycloak;

--
-- Name: scope_policy; Type: TABLE; Schema: public; Owner: keycloak
--

CREATE TABLE public.scope_policy (
    scope_id character varying(36) NOT NULL,
    policy_id character varying(36) NOT NULL
);


ALTER TABLE public.scope_policy OWNER TO keycloak;

--
-- Name: user_attribute; Type: TABLE; Schema: public; Owner: keycloak
--

CREATE TABLE public.user_attribute (
    name character varying(255) NOT NULL,
    value character varying(255),
    user_id character varying(36) NOT NULL,
    id character varying(36) DEFAULT 'sybase-needs-something-here'::character varying NOT NULL
);


ALTER TABLE public.user_attribute OWNER TO keycloak;

--
-- Name: user_consent; Type: TABLE; Schema: public; Owner: keycloak
--

CREATE TABLE public.user_consent (
    id character varying(36) NOT NULL,
    client_id character varying(255),
    user_id character varying(36) NOT NULL,
    created_date bigint,
    last_updated_date bigint,
    client_storage_provider character varying(36),
    external_client_id character varying(255)
);


ALTER TABLE public.user_consent OWNER TO keycloak;

--
-- Name: user_consent_client_scope; Type: TABLE; Schema: public; Owner: keycloak
--

CREATE TABLE public.user_consent_client_scope (
    user_consent_id character varying(36) NOT NULL,
    scope_id character varying(36) NOT NULL
);


ALTER TABLE public.user_consent_client_scope OWNER TO keycloak;

--
-- Name: user_entity; Type: TABLE; Schema: public; Owner: keycloak
--

CREATE TABLE public.user_entity (
    id character varying(36) NOT NULL,
    email character varying(255),
    email_constraint character varying(255),
    email_verified boolean DEFAULT false NOT NULL,
    enabled boolean DEFAULT false NOT NULL,
    federation_link character varying(255),
    first_name character varying(255),
    last_name character varying(255),
    realm_id character varying(255),
    username character varying(255),
    created_timestamp bigint,
    service_account_client_link character varying(255),
    not_before integer DEFAULT 0 NOT NULL
);


ALTER TABLE public.user_entity OWNER TO keycloak;

--
-- Name: user_federation_config; Type: TABLE; Schema: public; Owner: keycloak
--

CREATE TABLE public.user_federation_config (
    user_federation_provider_id character varying(36) NOT NULL,
    value character varying(255),
    name character varying(255) NOT NULL
);


ALTER TABLE public.user_federation_config OWNER TO keycloak;

--
-- Name: user_federation_mapper; Type: TABLE; Schema: public; Owner: keycloak
--

CREATE TABLE public.user_federation_mapper (
    id character varying(36) NOT NULL,
    name character varying(255) NOT NULL,
    federation_provider_id character varying(36) NOT NULL,
    federation_mapper_type character varying(255) NOT NULL,
    realm_id character varying(36) NOT NULL
);


ALTER TABLE public.user_federation_mapper OWNER TO keycloak;

--
-- Name: user_federation_mapper_config; Type: TABLE; Schema: public; Owner: keycloak
--

CREATE TABLE public.user_federation_mapper_config (
    user_federation_mapper_id character varying(36) NOT NULL,
    value character varying(255),
    name character varying(255) NOT NULL
);


ALTER TABLE public.user_federation_mapper_config OWNER TO keycloak;

--
-- Name: user_federation_provider; Type: TABLE; Schema: public; Owner: keycloak
--

CREATE TABLE public.user_federation_provider (
    id character varying(36) NOT NULL,
    changed_sync_period integer,
    display_name character varying(255),
    full_sync_period integer,
    last_sync integer,
    priority integer,
    provider_name character varying(255),
    realm_id character varying(36)
);


ALTER TABLE public.user_federation_provider OWNER TO keycloak;

--
-- Name: user_group_membership; Type: TABLE; Schema: public; Owner: keycloak
--

CREATE TABLE public.user_group_membership (
    group_id character varying(36) NOT NULL,
    user_id character varying(36) NOT NULL
);


ALTER TABLE public.user_group_membership OWNER TO keycloak;

--
-- Name: user_required_action; Type: TABLE; Schema: public; Owner: keycloak
--

CREATE TABLE public.user_required_action (
    user_id character varying(36) NOT NULL,
    required_action character varying(255) DEFAULT ' '::character varying NOT NULL
);


ALTER TABLE public.user_required_action OWNER TO keycloak;

--
-- Name: user_role_mapping; Type: TABLE; Schema: public; Owner: keycloak
--

CREATE TABLE public.user_role_mapping (
    role_id character varying(255) NOT NULL,
    user_id character varying(36) NOT NULL
);


ALTER TABLE public.user_role_mapping OWNER TO keycloak;

--
-- Name: user_session; Type: TABLE; Schema: public; Owner: keycloak
--

CREATE TABLE public.user_session (
    id character varying(36) NOT NULL,
    auth_method character varying(255),
    ip_address character varying(255),
    last_session_refresh integer,
    login_username character varying(255),
    realm_id character varying(255),
    remember_me boolean DEFAULT false NOT NULL,
    started integer,
    user_id character varying(255),
    user_session_state integer,
    broker_session_id character varying(255),
    broker_user_id character varying(255)
);


ALTER TABLE public.user_session OWNER TO keycloak;

--
-- Name: user_session_note; Type: TABLE; Schema: public; Owner: keycloak
--

CREATE TABLE public.user_session_note (
    user_session character varying(36) NOT NULL,
    name character varying(255) NOT NULL,
    value character varying(2048)
);


ALTER TABLE public.user_session_note OWNER TO keycloak;

--
-- Name: username_login_failure; Type: TABLE; Schema: public; Owner: keycloak
--

CREATE TABLE public.username_login_failure (
    realm_id character varying(36) NOT NULL,
    username character varying(255) NOT NULL,
    failed_login_not_before integer,
    last_failure bigint,
    last_ip_failure character varying(255),
    num_failures integer
);


ALTER TABLE public.username_login_failure OWNER TO keycloak;

--
-- Name: web_origins; Type: TABLE; Schema: public; Owner: keycloak
--

CREATE TABLE public.web_origins (
    client_id character varying(36) NOT NULL,
    value character varying(255) NOT NULL
);


ALTER TABLE public.web_origins OWNER TO keycloak;

--
-- Data for Name: admin_event_entity; Type: TABLE DATA; Schema: public; Owner: keycloak
--

COPY public.admin_event_entity (id, admin_event_time, realm_id, operation_type, auth_realm_id, auth_client_id, auth_user_id, ip_address, resource_path, representation, error, resource_type) FROM stdin;
\.


--
-- Data for Name: associated_policy; Type: TABLE DATA; Schema: public; Owner: keycloak
--

COPY public.associated_policy (policy_id, associated_policy_id) FROM stdin;
\.


--
-- Data for Name: authentication_execution; Type: TABLE DATA; Schema: public; Owner: keycloak
--

COPY public.authentication_execution (id, alias, authenticator, realm_id, flow_id, requirement, priority, authenticator_flow, auth_flow_id, auth_config) FROM stdin;
f1fef9f1-678c-4f05-9b65-0629710df273	\N	auth-cookie	master	b4f74719-5181-4e61-9844-d5257d6493f4	2	10	f	\N	\N
76af4119-df74-4489-87cf-baeb84208881	\N	auth-spnego	master	b4f74719-5181-4e61-9844-d5257d6493f4	3	20	f	\N	\N
0dcaa0de-5a3b-43cf-8602-6114c225f2a3	\N	identity-provider-redirector	master	b4f74719-5181-4e61-9844-d5257d6493f4	2	25	f	\N	\N
e87fba46-f93e-4f76-a155-de303ab5e3a7	\N	\N	master	b4f74719-5181-4e61-9844-d5257d6493f4	2	30	t	cd4be97b-db36-431f-8864-025786bf6e1f	\N
fdb04240-18d2-49e0-835f-9d9d86b25593	\N	auth-username-password-form	master	cd4be97b-db36-431f-8864-025786bf6e1f	0	10	f	\N	\N
57f47101-84d7-42dc-80b6-de4d9687d3b4	\N	\N	master	cd4be97b-db36-431f-8864-025786bf6e1f	1	20	t	bce068a6-4d0d-43df-b6cf-ff19e4cfa94f	\N
f17a1880-5fd9-4f1e-ade8-d0365032e9be	\N	conditional-user-configured	master	bce068a6-4d0d-43df-b6cf-ff19e4cfa94f	0	10	f	\N	\N
cc641d32-bf75-453a-814c-5ab42fcf3355	\N	auth-otp-form	master	bce068a6-4d0d-43df-b6cf-ff19e4cfa94f	0	20	f	\N	\N
b8f92ed8-9099-4c11-b19f-6fcc3718a12f	\N	direct-grant-validate-username	master	a25459eb-a7a4-4f50-9147-1c6c6edc07a5	0	10	f	\N	\N
ae70d008-8b6c-40f9-b4ae-82616892c55d	\N	direct-grant-validate-password	master	a25459eb-a7a4-4f50-9147-1c6c6edc07a5	0	20	f	\N	\N
ab840e2c-113f-4400-b23d-4c7ebe0e3262	\N	\N	master	a25459eb-a7a4-4f50-9147-1c6c6edc07a5	1	30	t	b0fb76e6-9d71-481c-8c2b-fcf8e15a0304	\N
ac6cb331-d0a4-456e-b53e-421cc1a17a4d	\N	conditional-user-configured	master	b0fb76e6-9d71-481c-8c2b-fcf8e15a0304	0	10	f	\N	\N
4ebf3cd1-1978-4ee8-8bad-4a67d59692c4	\N	direct-grant-validate-otp	master	b0fb76e6-9d71-481c-8c2b-fcf8e15a0304	0	20	f	\N	\N
00e57be1-b154-4f1a-8adf-18a1cc10a9ef	\N	registration-page-form	master	6421bcdb-674f-453a-8d07-d4badef008e7	0	10	t	da5592c1-99b8-415a-973e-8446b272d1c3	\N
aeca8c08-6664-4bf2-8033-712b507d98f1	\N	registration-user-creation	master	da5592c1-99b8-415a-973e-8446b272d1c3	0	20	f	\N	\N
675c8611-2270-4d98-851e-5520f4a53403	\N	registration-profile-action	master	da5592c1-99b8-415a-973e-8446b272d1c3	0	40	f	\N	\N
acdc5d3b-ba7b-4e9e-9331-c51819e8e9df	\N	registration-password-action	master	da5592c1-99b8-415a-973e-8446b272d1c3	0	50	f	\N	\N
dfa64220-3e3c-4b99-8884-96585b3eb1a5	\N	registration-recaptcha-action	master	da5592c1-99b8-415a-973e-8446b272d1c3	3	60	f	\N	\N
65d72e54-576f-41e5-b2f1-41aa96e5df26	\N	reset-credentials-choose-user	master	7bb7ec8a-43a8-4046-afed-d28e9fd64c88	0	10	f	\N	\N
2e18f370-4f13-4b23-9bbc-d513e43fa86f	\N	reset-credential-email	master	7bb7ec8a-43a8-4046-afed-d28e9fd64c88	0	20	f	\N	\N
85f4ee40-f564-4ced-964c-faa3dd02ae7c	\N	reset-password	master	7bb7ec8a-43a8-4046-afed-d28e9fd64c88	0	30	f	\N	\N
abe689c4-3f56-4574-816e-c02dc45ea001	\N	\N	master	7bb7ec8a-43a8-4046-afed-d28e9fd64c88	1	40	t	1144245c-a117-4154-9fd3-d8bd0d90b79e	\N
9e3b3017-329e-4573-a64b-5d844a95fd93	\N	conditional-user-configured	master	1144245c-a117-4154-9fd3-d8bd0d90b79e	0	10	f	\N	\N
db6a89fa-89d1-4d6b-995f-03fa2ccc5444	\N	reset-otp	master	1144245c-a117-4154-9fd3-d8bd0d90b79e	0	20	f	\N	\N
b9eb9b13-b1c7-4177-b680-d4cd2932bf4d	\N	client-secret	master	a87d8849-4b61-43c7-a67a-8f85f415fe6e	2	10	f	\N	\N
fa7ee74c-4fd6-476f-8431-97bf6be7d8e6	\N	client-jwt	master	a87d8849-4b61-43c7-a67a-8f85f415fe6e	2	20	f	\N	\N
3e2a6948-f81c-401e-88d8-f2b3522954f4	\N	client-secret-jwt	master	a87d8849-4b61-43c7-a67a-8f85f415fe6e	2	30	f	\N	\N
8effd00e-982f-49af-bb4d-812aa05b2993	\N	client-x509	master	a87d8849-4b61-43c7-a67a-8f85f415fe6e	2	40	f	\N	\N
e567ed10-ca60-4b44-a002-cea8578826a4	\N	idp-review-profile	master	bec78592-496d-4b30-b436-8bc1051e787d	0	10	f	\N	534f92cf-bccc-42fc-8a0b-d90e0d9ecdeb
36b4b71f-9f81-4c49-b43d-169f01bec230	\N	\N	master	bec78592-496d-4b30-b436-8bc1051e787d	0	20	t	82ad6e10-175b-46f0-9c39-8918b58d17d1	\N
be0a83c0-f14a-49c4-9a9b-71ec68b46cb6	\N	idp-create-user-if-unique	master	82ad6e10-175b-46f0-9c39-8918b58d17d1	2	10	f	\N	05d29d1e-aba9-4b98-b8d5-deb0d70edc54
afdc8d5f-dffa-475b-863d-51646c7aa995	\N	\N	master	82ad6e10-175b-46f0-9c39-8918b58d17d1	2	20	t	17b73b3d-6b5a-4033-8fec-442b9eac26da	\N
d0f4731e-98b2-4da1-9903-07bcc35ec02f	\N	idp-confirm-link	master	17b73b3d-6b5a-4033-8fec-442b9eac26da	0	10	f	\N	\N
6d7d6df4-cffa-42ac-bc99-db10a492f280	\N	\N	master	17b73b3d-6b5a-4033-8fec-442b9eac26da	0	20	t	fe058741-9078-49b1-a5e9-4ec34cf1513b	\N
470de342-30c1-47b6-8ce1-35b51e97aef8	\N	idp-email-verification	master	fe058741-9078-49b1-a5e9-4ec34cf1513b	2	10	f	\N	\N
9c353c37-d5dc-48ab-aedd-d78b50001c06	\N	\N	master	fe058741-9078-49b1-a5e9-4ec34cf1513b	2	20	t	98da1f8f-aeab-4da3-bc2a-8bc820a395a0	\N
84501579-e8e3-4c57-8054-d89e2e0e6269	\N	idp-username-password-form	master	98da1f8f-aeab-4da3-bc2a-8bc820a395a0	0	10	f	\N	\N
0be3fb81-1b84-46c9-9958-615b64462831	\N	\N	master	98da1f8f-aeab-4da3-bc2a-8bc820a395a0	1	20	t	81ae7ef6-d5a2-43aa-af27-4501b77192a6	\N
21492099-34b3-4b1f-9b04-b886130938af	\N	conditional-user-configured	master	81ae7ef6-d5a2-43aa-af27-4501b77192a6	0	10	f	\N	\N
d191969d-c430-495b-a054-52124926b934	\N	auth-otp-form	master	81ae7ef6-d5a2-43aa-af27-4501b77192a6	0	20	f	\N	\N
585939d6-0e5a-411e-8604-5bb6f12247f9	\N	http-basic-authenticator	master	8f0237df-a577-434d-9299-f9ae14c4370d	0	10	f	\N	\N
68335549-e685-43af-bd8e-6d75c7780e9f	\N	docker-http-basic-authenticator	master	60e4eac4-9aae-4729-9453-f81ca44fa4b6	0	10	f	\N	\N
68617375-f21f-42a9-99ee-467a95b00ea9	\N	no-cookie-redirect	master	23850125-9a0d-4eb5-adab-d8825ddab123	0	10	f	\N	\N
54a32566-2903-4553-b585-990bb1907e7a	\N	\N	master	23850125-9a0d-4eb5-adab-d8825ddab123	0	20	t	3766d65d-e476-4808-85cf-1fd9b6e05b42	\N
ed7a9dd9-ea8b-4d42-a921-16abacda6cea	\N	basic-auth	master	3766d65d-e476-4808-85cf-1fd9b6e05b42	0	10	f	\N	\N
3ecaeb56-ca0f-435e-9ec6-255cf71adf37	\N	basic-auth-otp	master	3766d65d-e476-4808-85cf-1fd9b6e05b42	3	20	f	\N	\N
fdac3f4b-bf94-4e92-b8c2-081dd07670da	\N	auth-spnego	master	3766d65d-e476-4808-85cf-1fd9b6e05b42	3	30	f	\N	\N
6b3d2f9c-e77d-48e8-ac77-92eacf3f263b	\N	auth-cookie	fiware_service	46601f6a-192b-4f2f-8012-dcba10eca461	2	10	f	\N	\N
4a855355-a6c2-483d-aca8-843d091a19ce	\N	auth-spnego	fiware_service	46601f6a-192b-4f2f-8012-dcba10eca461	3	20	f	\N	\N
55816a44-6df4-435b-a156-fdfbf316262c	\N	identity-provider-redirector	fiware_service	46601f6a-192b-4f2f-8012-dcba10eca461	2	25	f	\N	\N
ff2be4f8-1785-4e92-adb3-d0de510362eb	\N	\N	fiware_service	46601f6a-192b-4f2f-8012-dcba10eca461	2	30	t	0bd572da-a7e3-4bb8-bc8e-aeadc0be35aa	\N
de30b420-19a0-4e07-9ca0-ed80950c8082	\N	auth-username-password-form	fiware_service	0bd572da-a7e3-4bb8-bc8e-aeadc0be35aa	0	10	f	\N	\N
0f9bfa83-176f-4190-b7c2-5882331a942b	\N	\N	fiware_service	0bd572da-a7e3-4bb8-bc8e-aeadc0be35aa	1	20	t	49964fb6-aa36-4cf3-8aa9-a1c3a234db00	\N
15f4e0f1-d3ac-4a20-94b1-e5ca30765a4f	\N	conditional-user-configured	fiware_service	49964fb6-aa36-4cf3-8aa9-a1c3a234db00	0	10	f	\N	\N
5b5c29a9-6ad7-4842-8308-3b69227f606e	\N	auth-otp-form	fiware_service	49964fb6-aa36-4cf3-8aa9-a1c3a234db00	0	20	f	\N	\N
e129818c-c97b-47c9-ae54-c865da4a9450	\N	direct-grant-validate-username	fiware_service	013fc056-3ba8-4a33-8b3d-c058d3feb3d3	0	10	f	\N	\N
b80b8b7b-11b8-4975-8d9c-ece6505d961e	\N	direct-grant-validate-password	fiware_service	013fc056-3ba8-4a33-8b3d-c058d3feb3d3	0	20	f	\N	\N
a2e51fd6-8724-4fa5-b258-941d67b3d77c	\N	\N	fiware_service	013fc056-3ba8-4a33-8b3d-c058d3feb3d3	1	30	t	a5001be4-1f75-401c-9c45-0d9bfab0e1c6	\N
7fe15e5a-635b-4af8-a736-bcc83b1de46a	\N	conditional-user-configured	fiware_service	a5001be4-1f75-401c-9c45-0d9bfab0e1c6	0	10	f	\N	\N
b511eeff-ff65-4f71-994b-731180e0b8a8	\N	direct-grant-validate-otp	fiware_service	a5001be4-1f75-401c-9c45-0d9bfab0e1c6	0	20	f	\N	\N
bc1c66e4-2abf-4b2d-b095-56160baed786	\N	registration-page-form	fiware_service	a12a5b0d-1a80-4ea7-92a4-335dabcb58e9	0	10	t	1ed50072-89cf-4e82-bf5a-4bc72d5bdc61	\N
4dd470b1-1d5a-4397-bfb0-048689b7bbe6	\N	registration-user-creation	fiware_service	1ed50072-89cf-4e82-bf5a-4bc72d5bdc61	0	20	f	\N	\N
4b6bfd2f-627c-4fc0-a3c0-42d0067ebf2b	\N	registration-profile-action	fiware_service	1ed50072-89cf-4e82-bf5a-4bc72d5bdc61	0	40	f	\N	\N
7f2e05ae-0d4d-4053-8c70-4f2e24ec1a0e	\N	registration-password-action	fiware_service	1ed50072-89cf-4e82-bf5a-4bc72d5bdc61	0	50	f	\N	\N
c779ece9-4615-4aa6-88fd-b9e5fd32e0c4	\N	registration-recaptcha-action	fiware_service	1ed50072-89cf-4e82-bf5a-4bc72d5bdc61	3	60	f	\N	\N
1521d41b-ae26-4849-bab5-1c9318c5a13f	\N	reset-credentials-choose-user	fiware_service	0e0113b9-d907-4896-8bee-468b80af852c	0	10	f	\N	\N
a1ae9c8d-67ef-4c5a-bf88-0a7834a1eed7	\N	reset-credential-email	fiware_service	0e0113b9-d907-4896-8bee-468b80af852c	0	20	f	\N	\N
4306907d-63be-4359-97c4-87046bfcfd44	\N	reset-password	fiware_service	0e0113b9-d907-4896-8bee-468b80af852c	0	30	f	\N	\N
54391964-51d6-4d40-8580-17a346889ec3	\N	\N	fiware_service	0e0113b9-d907-4896-8bee-468b80af852c	1	40	t	d3751999-2019-4f2b-b3f3-71f2d83becb9	\N
91297c0d-02c8-422d-84da-4cf2239f3664	\N	conditional-user-configured	fiware_service	d3751999-2019-4f2b-b3f3-71f2d83becb9	0	10	f	\N	\N
a20f72da-e311-4b0c-8847-b52726eab4b3	\N	reset-otp	fiware_service	d3751999-2019-4f2b-b3f3-71f2d83becb9	0	20	f	\N	\N
7c6f0406-0930-4748-933c-c3658cc2f424	\N	client-secret	fiware_service	f1966204-8255-4984-9bd1-9152736eb81e	2	10	f	\N	\N
b833a716-ee27-4a5e-8e85-accbfe352397	\N	client-jwt	fiware_service	f1966204-8255-4984-9bd1-9152736eb81e	2	20	f	\N	\N
ead82e1b-e509-4dcf-b0d1-6f67547f87ee	\N	client-secret-jwt	fiware_service	f1966204-8255-4984-9bd1-9152736eb81e	2	30	f	\N	\N
613e67ee-3bfa-47a5-9ac9-6c617c419b8c	\N	client-x509	fiware_service	f1966204-8255-4984-9bd1-9152736eb81e	2	40	f	\N	\N
bd3c4fbb-8a35-4c72-bf54-7121aef6b883	\N	idp-review-profile	fiware_service	42e2db9e-fd7b-4cca-bc69-fa2d66741eaa	0	10	f	\N	613f08b5-0317-4d01-a5f2-94e4f7eb6c39
1a3e56ce-ccef-4de8-9495-962322015c59	\N	\N	fiware_service	42e2db9e-fd7b-4cca-bc69-fa2d66741eaa	0	20	t	3db116f7-7423-4512-9816-7c6471a31dbf	\N
d995999f-772c-46d6-b165-034e767e9723	\N	idp-create-user-if-unique	fiware_service	3db116f7-7423-4512-9816-7c6471a31dbf	2	10	f	\N	744c5b9c-5052-4dad-9ec6-db5a7a532573
0957cec4-2601-4c09-9733-dafac900b977	\N	\N	fiware_service	3db116f7-7423-4512-9816-7c6471a31dbf	2	20	t	897e7e9e-d45b-407b-8334-aec083b8b539	\N
b39890bb-f7e3-4329-95a5-b62b18d18c1c	\N	idp-confirm-link	fiware_service	897e7e9e-d45b-407b-8334-aec083b8b539	0	10	f	\N	\N
0d87e2d0-5547-420f-8bb5-42aec79c811b	\N	\N	fiware_service	897e7e9e-d45b-407b-8334-aec083b8b539	0	20	t	34c88706-97e9-4519-b9dd-f2cbf01a6fcc	\N
69030b0e-fb88-404f-ae9c-545107caa348	\N	idp-email-verification	fiware_service	34c88706-97e9-4519-b9dd-f2cbf01a6fcc	2	10	f	\N	\N
1ca7d47d-5426-4b3e-9291-ea38d06cdaeb	\N	\N	fiware_service	34c88706-97e9-4519-b9dd-f2cbf01a6fcc	2	20	t	d2dde5a5-b04f-44fc-bfec-a0f69696d786	\N
54393e8c-d900-42b8-9353-7297f6b7fa85	\N	idp-username-password-form	fiware_service	d2dde5a5-b04f-44fc-bfec-a0f69696d786	0	10	f	\N	\N
6c6f32b0-56f0-4af0-842f-7cbda01ced5b	\N	\N	fiware_service	d2dde5a5-b04f-44fc-bfec-a0f69696d786	1	20	t	01e0287d-3473-45fb-b9c6-5cd54d06fe8a	\N
a64b1f3c-f404-4e5e-b9c5-4b1348df973f	\N	conditional-user-configured	fiware_service	01e0287d-3473-45fb-b9c6-5cd54d06fe8a	0	10	f	\N	\N
41dd19e6-e738-4902-9270-536888835085	\N	auth-otp-form	fiware_service	01e0287d-3473-45fb-b9c6-5cd54d06fe8a	0	20	f	\N	\N
20fc85ea-cec3-48df-972c-f99fb8b76b91	\N	http-basic-authenticator	fiware_service	7cef95af-bac1-4400-bb54-fdcb6b6edee1	0	10	f	\N	\N
89f2b17a-043a-480d-ae6c-c7239c7fb527	\N	docker-http-basic-authenticator	fiware_service	6b1890c5-4fab-4408-988f-f1566d9b8c6d	0	10	f	\N	\N
76fdaa34-bfd2-4984-94f7-133ffe82f96e	\N	no-cookie-redirect	fiware_service	65d7e892-5577-4406-9ba6-bafc3e3cfc69	0	10	f	\N	\N
e8d353a0-a1ee-4889-bf94-ab9d908c73b1	\N	\N	fiware_service	65d7e892-5577-4406-9ba6-bafc3e3cfc69	0	20	t	330f5123-1c88-4a58-a008-0ac80dcb8046	\N
fd9f4938-7edf-488a-af79-2244d9f347b6	\N	basic-auth	fiware_service	330f5123-1c88-4a58-a008-0ac80dcb8046	0	10	f	\N	\N
c7eecf11-fea1-4175-86d1-9828055e5e52	\N	basic-auth-otp	fiware_service	330f5123-1c88-4a58-a008-0ac80dcb8046	3	20	f	\N	\N
0d43279a-d29a-41ff-83c5-d72a348f31fb	\N	auth-spnego	fiware_service	330f5123-1c88-4a58-a008-0ac80dcb8046	3	30	f	\N	\N
\.


--
-- Data for Name: authentication_flow; Type: TABLE DATA; Schema: public; Owner: keycloak
--

COPY public.authentication_flow (id, alias, description, realm_id, provider_id, top_level, built_in) FROM stdin;
b4f74719-5181-4e61-9844-d5257d6493f4	browser	browser based authentication	master	basic-flow	t	t
cd4be97b-db36-431f-8864-025786bf6e1f	forms	Username, password, otp and other auth forms.	master	basic-flow	f	t
bce068a6-4d0d-43df-b6cf-ff19e4cfa94f	Browser - Conditional OTP	Flow to determine if the OTP is required for the authentication	master	basic-flow	f	t
a25459eb-a7a4-4f50-9147-1c6c6edc07a5	direct grant	OpenID Connect Resource Owner Grant	master	basic-flow	t	t
b0fb76e6-9d71-481c-8c2b-fcf8e15a0304	Direct Grant - Conditional OTP	Flow to determine if the OTP is required for the authentication	master	basic-flow	f	t
6421bcdb-674f-453a-8d07-d4badef008e7	registration	registration flow	master	basic-flow	t	t
da5592c1-99b8-415a-973e-8446b272d1c3	registration form	registration form	master	form-flow	f	t
7bb7ec8a-43a8-4046-afed-d28e9fd64c88	reset credentials	Reset credentials for a user if they forgot their password or something	master	basic-flow	t	t
1144245c-a117-4154-9fd3-d8bd0d90b79e	Reset - Conditional OTP	Flow to determine if the OTP should be reset or not. Set to REQUIRED to force.	master	basic-flow	f	t
a87d8849-4b61-43c7-a67a-8f85f415fe6e	clients	Base authentication for clients	master	client-flow	t	t
bec78592-496d-4b30-b436-8bc1051e787d	first broker login	Actions taken after first broker login with identity provider account, which is not yet linked to any Keycloak account	master	basic-flow	t	t
82ad6e10-175b-46f0-9c39-8918b58d17d1	User creation or linking	Flow for the existing/non-existing user alternatives	master	basic-flow	f	t
17b73b3d-6b5a-4033-8fec-442b9eac26da	Handle Existing Account	Handle what to do if there is existing account with same email/username like authenticated identity provider	master	basic-flow	f	t
fe058741-9078-49b1-a5e9-4ec34cf1513b	Account verification options	Method with which to verity the existing account	master	basic-flow	f	t
98da1f8f-aeab-4da3-bc2a-8bc820a395a0	Verify Existing Account by Re-authentication	Reauthentication of existing account	master	basic-flow	f	t
81ae7ef6-d5a2-43aa-af27-4501b77192a6	First broker login - Conditional OTP	Flow to determine if the OTP is required for the authentication	master	basic-flow	f	t
8f0237df-a577-434d-9299-f9ae14c4370d	saml ecp	SAML ECP Profile Authentication Flow	master	basic-flow	t	t
60e4eac4-9aae-4729-9453-f81ca44fa4b6	docker auth	Used by Docker clients to authenticate against the IDP	master	basic-flow	t	t
23850125-9a0d-4eb5-adab-d8825ddab123	http challenge	An authentication flow based on challenge-response HTTP Authentication Schemes	master	basic-flow	t	t
3766d65d-e476-4808-85cf-1fd9b6e05b42	Authentication Options	Authentication options.	master	basic-flow	f	t
46601f6a-192b-4f2f-8012-dcba10eca461	browser	browser based authentication	fiware_service	basic-flow	t	t
0bd572da-a7e3-4bb8-bc8e-aeadc0be35aa	forms	Username, password, otp and other auth forms.	fiware_service	basic-flow	f	t
49964fb6-aa36-4cf3-8aa9-a1c3a234db00	Browser - Conditional OTP	Flow to determine if the OTP is required for the authentication	fiware_service	basic-flow	f	t
013fc056-3ba8-4a33-8b3d-c058d3feb3d3	direct grant	OpenID Connect Resource Owner Grant	fiware_service	basic-flow	t	t
a5001be4-1f75-401c-9c45-0d9bfab0e1c6	Direct Grant - Conditional OTP	Flow to determine if the OTP is required for the authentication	fiware_service	basic-flow	f	t
a12a5b0d-1a80-4ea7-92a4-335dabcb58e9	registration	registration flow	fiware_service	basic-flow	t	t
1ed50072-89cf-4e82-bf5a-4bc72d5bdc61	registration form	registration form	fiware_service	form-flow	f	t
0e0113b9-d907-4896-8bee-468b80af852c	reset credentials	Reset credentials for a user if they forgot their password or something	fiware_service	basic-flow	t	t
d3751999-2019-4f2b-b3f3-71f2d83becb9	Reset - Conditional OTP	Flow to determine if the OTP should be reset or not. Set to REQUIRED to force.	fiware_service	basic-flow	f	t
f1966204-8255-4984-9bd1-9152736eb81e	clients	Base authentication for clients	fiware_service	client-flow	t	t
42e2db9e-fd7b-4cca-bc69-fa2d66741eaa	first broker login	Actions taken after first broker login with identity provider account, which is not yet linked to any Keycloak account	fiware_service	basic-flow	t	t
3db116f7-7423-4512-9816-7c6471a31dbf	User creation or linking	Flow for the existing/non-existing user alternatives	fiware_service	basic-flow	f	t
897e7e9e-d45b-407b-8334-aec083b8b539	Handle Existing Account	Handle what to do if there is existing account with same email/username like authenticated identity provider	fiware_service	basic-flow	f	t
34c88706-97e9-4519-b9dd-f2cbf01a6fcc	Account verification options	Method with which to verity the existing account	fiware_service	basic-flow	f	t
d2dde5a5-b04f-44fc-bfec-a0f69696d786	Verify Existing Account by Re-authentication	Reauthentication of existing account	fiware_service	basic-flow	f	t
01e0287d-3473-45fb-b9c6-5cd54d06fe8a	First broker login - Conditional OTP	Flow to determine if the OTP is required for the authentication	fiware_service	basic-flow	f	t
7cef95af-bac1-4400-bb54-fdcb6b6edee1	saml ecp	SAML ECP Profile Authentication Flow	fiware_service	basic-flow	t	t
6b1890c5-4fab-4408-988f-f1566d9b8c6d	docker auth	Used by Docker clients to authenticate against the IDP	fiware_service	basic-flow	t	t
65d7e892-5577-4406-9ba6-bafc3e3cfc69	http challenge	An authentication flow based on challenge-response HTTP Authentication Schemes	fiware_service	basic-flow	t	t
330f5123-1c88-4a58-a008-0ac80dcb8046	Authentication Options	Authentication options.	fiware_service	basic-flow	f	t
\.


--
-- Data for Name: authenticator_config; Type: TABLE DATA; Schema: public; Owner: keycloak
--

COPY public.authenticator_config (id, alias, realm_id) FROM stdin;
534f92cf-bccc-42fc-8a0b-d90e0d9ecdeb	review profile config	master
05d29d1e-aba9-4b98-b8d5-deb0d70edc54	create unique user config	master
613f08b5-0317-4d01-a5f2-94e4f7eb6c39	review profile config	fiware_service
744c5b9c-5052-4dad-9ec6-db5a7a532573	create unique user config	fiware_service
\.


--
-- Data for Name: authenticator_config_entry; Type: TABLE DATA; Schema: public; Owner: keycloak
--

COPY public.authenticator_config_entry (authenticator_id, value, name) FROM stdin;
534f92cf-bccc-42fc-8a0b-d90e0d9ecdeb	missing	update.profile.on.first.login
05d29d1e-aba9-4b98-b8d5-deb0d70edc54	false	require.password.update.after.registration
613f08b5-0317-4d01-a5f2-94e4f7eb6c39	missing	update.profile.on.first.login
744c5b9c-5052-4dad-9ec6-db5a7a532573	false	require.password.update.after.registration
\.


--
-- Data for Name: broker_link; Type: TABLE DATA; Schema: public; Owner: keycloak
--

COPY public.broker_link (identity_provider, storage_provider_id, realm_id, broker_user_id, broker_username, token, user_id) FROM stdin;
\.


--
-- Data for Name: client; Type: TABLE DATA; Schema: public; Owner: keycloak
--

COPY public.client (id, enabled, full_scope_allowed, client_id, not_before, public_client, secret, base_url, bearer_only, management_url, surrogate_auth_required, realm_id, protocol, node_rereg_timeout, frontchannel_logout, consent_required, name, service_accounts_enabled, client_authenticator_type, root_url, description, registration_token, standard_flow_enabled, implicit_flow_enabled, direct_access_grants_enabled, always_display_in_console) FROM stdin;
3f8f0ad2-a399-4b08-969d-cff26f73eb7d	t	f	master-realm	0	f	\N	\N	t	\N	f	master	\N	0	f	f	master Realm	f	client-secret	\N	\N	\N	t	f	f	f
e3222dd4-baa4-4f42-9042-e0190fb22ef8	t	f	account	0	t	\N	/realms/master/account/	f	\N	f	master	openid-connect	0	f	f	${client_account}	f	client-secret	${authBaseUrl}	\N	\N	t	f	f	f
3ac10acb-7ef8-4489-9077-16a81264dd18	t	f	account-console	0	t	\N	/realms/master/account/	f	\N	f	master	openid-connect	0	f	f	${client_account-console}	f	client-secret	${authBaseUrl}	\N	\N	t	f	f	f
45c60e97-84b5-4742-97d8-c57fa691d587	t	f	broker	0	f	\N	\N	t	\N	f	master	openid-connect	0	f	f	${client_broker}	f	client-secret	\N	\N	\N	t	f	f	f
eaa78be2-e4bb-47af-8f6b-5aa43b433ab5	t	f	security-admin-console	0	t	\N	/admin/master/console/	f	\N	f	master	openid-connect	0	f	f	${client_security-admin-console}	f	client-secret	${authAdminUrl}	\N	\N	t	f	f	f
0a1f9cfc-c2e8-485c-9029-fa5e2154726a	t	f	admin-cli	0	t	\N	\N	f	\N	f	master	openid-connect	0	f	f	${client_admin-cli}	f	client-secret	\N	\N	\N	f	f	t	f
ccedade4-74d9-4315-9131-8c4f6a9b966f	t	f	fiware_service-realm	0	f	\N	\N	t	\N	f	master	\N	0	f	f	fiware_service Realm	f	client-secret	\N	\N	\N	t	f	f	f
3cea1058-358e-4b9c-9d83-c1ffded25b90	t	f	realm-management	0	f	\N	\N	t	\N	f	fiware_service	openid-connect	0	f	f	${client_realm-management}	f	client-secret	\N	\N	\N	t	f	f	f
ae0a3deb-9d51-45a1-9fde-ac887ac98178	t	f	account	0	t	\N	/realms/fiware_service/account/	f	\N	f	fiware_service	openid-connect	0	f	f	${client_account}	f	client-secret	${authBaseUrl}	\N	\N	t	f	f	f
b864547a-1317-4451-958b-b56a7fef9265	t	f	account-console	0	t	\N	/realms/fiware_service/account/	f	\N	f	fiware_service	openid-connect	0	f	f	${client_account-console}	f	client-secret	${authBaseUrl}	\N	\N	t	f	f	f
89af4714-83b6-49d7-a06a-c7f1619d3be1	t	f	broker	0	f	\N	\N	t	\N	f	fiware_service	openid-connect	0	f	f	${client_broker}	f	client-secret	\N	\N	\N	t	f	f	f
6e12da5c-e596-4d59-a3af-c52dfc906e1d	t	f	security-admin-console	0	t	\N	/admin/fiware_service/console/	f	\N	f	fiware_service	openid-connect	0	f	f	${client_security-admin-console}	f	client-secret	${authAdminUrl}	\N	\N	t	f	f	f
713b01e3-b893-4a01-a713-b755082711e8	t	f	admin-cli	0	t	\N	\N	f	\N	f	fiware_service	openid-connect	0	f	f	${client_admin-cli}	f	client-secret	\N	\N	\N	f	f	t	f
2c3c1eec-9294-4ead-84b4-ad87622f3d08	t	t	ngsi_api	0	f	8eb5d01d-d155-4b73-9414-a3c28ee4aba6	\N	f	\N	f	fiware_service	openid-connect	-1	f	f	\N	f	client-secret	\N	\N	\N	f	f	t	f
\.


--
-- Data for Name: client_attributes; Type: TABLE DATA; Schema: public; Owner: keycloak
--

COPY public.client_attributes (client_id, value, name) FROM stdin;
3ac10acb-7ef8-4489-9077-16a81264dd18	S256	pkce.code.challenge.method
eaa78be2-e4bb-47af-8f6b-5aa43b433ab5	S256	pkce.code.challenge.method
b864547a-1317-4451-958b-b56a7fef9265	S256	pkce.code.challenge.method
6e12da5c-e596-4d59-a3af-c52dfc906e1d	S256	pkce.code.challenge.method
2c3c1eec-9294-4ead-84b4-ad87622f3d08	true	backchannel.logout.session.required
2c3c1eec-9294-4ead-84b4-ad87622f3d08	false	backchannel.logout.revoke.offline.tokens
2c3c1eec-9294-4ead-84b4-ad87622f3d08	false	saml.artifact.binding
2c3c1eec-9294-4ead-84b4-ad87622f3d08	false	saml.server.signature
2c3c1eec-9294-4ead-84b4-ad87622f3d08	false	saml.server.signature.keyinfo.ext
2c3c1eec-9294-4ead-84b4-ad87622f3d08	false	saml.assertion.signature
2c3c1eec-9294-4ead-84b4-ad87622f3d08	false	saml.client.signature
2c3c1eec-9294-4ead-84b4-ad87622f3d08	false	saml.encrypt
2c3c1eec-9294-4ead-84b4-ad87622f3d08	false	saml.authnstatement
2c3c1eec-9294-4ead-84b4-ad87622f3d08	false	saml.onetimeuse.condition
2c3c1eec-9294-4ead-84b4-ad87622f3d08	false	saml_force_name_id_format
2c3c1eec-9294-4ead-84b4-ad87622f3d08	false	saml.multivalued.roles
2c3c1eec-9294-4ead-84b4-ad87622f3d08	false	saml.force.post.binding
2c3c1eec-9294-4ead-84b4-ad87622f3d08	false	exclude.session.state.from.auth.response
2c3c1eec-9294-4ead-84b4-ad87622f3d08	false	oidc.ciba.grant.enabled
2c3c1eec-9294-4ead-84b4-ad87622f3d08	true	use.refresh.tokens
2c3c1eec-9294-4ead-84b4-ad87622f3d08	false	id.token.as.detached.signature
2c3c1eec-9294-4ead-84b4-ad87622f3d08	false	tls.client.certificate.bound.access.tokens
2c3c1eec-9294-4ead-84b4-ad87622f3d08	false	client_credentials.use_refresh_token
2c3c1eec-9294-4ead-84b4-ad87622f3d08	false	display.on.consent.screen
2c3c1eec-9294-4ead-84b4-ad87622f3d08	true	oauth2.device.authorization.grant.enabled
\.


--
-- Data for Name: client_auth_flow_bindings; Type: TABLE DATA; Schema: public; Owner: keycloak
--

COPY public.client_auth_flow_bindings (client_id, flow_id, binding_name) FROM stdin;
\.


--
-- Data for Name: client_initial_access; Type: TABLE DATA; Schema: public; Owner: keycloak
--

COPY public.client_initial_access (id, realm_id, "timestamp", expiration, count, remaining_count) FROM stdin;
\.


--
-- Data for Name: client_node_registrations; Type: TABLE DATA; Schema: public; Owner: keycloak
--

COPY public.client_node_registrations (client_id, value, name) FROM stdin;
\.


--
-- Data for Name: client_scope; Type: TABLE DATA; Schema: public; Owner: keycloak
--

COPY public.client_scope (id, name, realm_id, description, protocol) FROM stdin;
40dede99-d0c8-4723-b60e-716e9e82e85f	offline_access	master	OpenID Connect built-in scope: offline_access	openid-connect
35c7d452-01e3-49e7-bb27-be0e7177cbc0	role_list	master	SAML role list	saml
c243f89b-c6d0-4fc4-9392-a4eaaacb9b3e	profile	master	OpenID Connect built-in scope: profile	openid-connect
373bdcaf-2669-4cd5-b2b0-cfaee6acba99	email	master	OpenID Connect built-in scope: email	openid-connect
a62152f2-4d17-48f6-bd80-0ec85f4be131	address	master	OpenID Connect built-in scope: address	openid-connect
f6fbfb19-4a16-4178-89d0-2e7e8579c022	phone	master	OpenID Connect built-in scope: phone	openid-connect
baea9655-0cce-403a-af40-14c343d7b97d	roles	master	OpenID Connect scope for add user roles to the access token	openid-connect
86007ce1-cb1c-4a3b-aed9-5030a7e42acc	web-origins	master	OpenID Connect scope for add allowed web origins to the access token	openid-connect
f25eafa6-89a3-4734-9ca7-11329dc181d3	microprofile-jwt	master	Microprofile - JWT built-in scope	openid-connect
bb65f812-e812-4bf1-aee8-0776c436b711	offline_access	fiware_service	OpenID Connect built-in scope: offline_access	openid-connect
6ab21a08-f270-4c47-baec-9ecaa075a492	role_list	fiware_service	SAML role list	saml
edc90a1e-e346-4d1f-8cb7-8a2ecfbb3189	profile	fiware_service	OpenID Connect built-in scope: profile	openid-connect
1e90b592-874e-44de-86a2-fc0f6b070e42	email	fiware_service	OpenID Connect built-in scope: email	openid-connect
bedb72d4-f331-4238-9db7-33295a37136c	address	fiware_service	OpenID Connect built-in scope: address	openid-connect
f5922278-676a-4e9f-bde4-7a1f9d98aeaf	phone	fiware_service	OpenID Connect built-in scope: phone	openid-connect
9f5243a8-bf2e-4f55-bef5-53d9bc0e4752	roles	fiware_service	OpenID Connect scope for add user roles to the access token	openid-connect
f124c487-b123-41d2-9b56-380cf6d7f42b	web-origins	fiware_service	OpenID Connect scope for add allowed web origins to the access token	openid-connect
1430b17c-e711-4114-8f9c-900cfda97dd5	microprofile-jwt	fiware_service	Microprofile - JWT built-in scope	openid-connect
\.


--
-- Data for Name: client_scope_attributes; Type: TABLE DATA; Schema: public; Owner: keycloak
--

COPY public.client_scope_attributes (scope_id, value, name) FROM stdin;
40dede99-d0c8-4723-b60e-716e9e82e85f	true	display.on.consent.screen
40dede99-d0c8-4723-b60e-716e9e82e85f	${offlineAccessScopeConsentText}	consent.screen.text
35c7d452-01e3-49e7-bb27-be0e7177cbc0	true	display.on.consent.screen
35c7d452-01e3-49e7-bb27-be0e7177cbc0	${samlRoleListScopeConsentText}	consent.screen.text
c243f89b-c6d0-4fc4-9392-a4eaaacb9b3e	true	display.on.consent.screen
c243f89b-c6d0-4fc4-9392-a4eaaacb9b3e	${profileScopeConsentText}	consent.screen.text
c243f89b-c6d0-4fc4-9392-a4eaaacb9b3e	true	include.in.token.scope
373bdcaf-2669-4cd5-b2b0-cfaee6acba99	true	display.on.consent.screen
373bdcaf-2669-4cd5-b2b0-cfaee6acba99	${emailScopeConsentText}	consent.screen.text
373bdcaf-2669-4cd5-b2b0-cfaee6acba99	true	include.in.token.scope
a62152f2-4d17-48f6-bd80-0ec85f4be131	true	display.on.consent.screen
a62152f2-4d17-48f6-bd80-0ec85f4be131	${addressScopeConsentText}	consent.screen.text
a62152f2-4d17-48f6-bd80-0ec85f4be131	true	include.in.token.scope
f6fbfb19-4a16-4178-89d0-2e7e8579c022	true	display.on.consent.screen
f6fbfb19-4a16-4178-89d0-2e7e8579c022	${phoneScopeConsentText}	consent.screen.text
f6fbfb19-4a16-4178-89d0-2e7e8579c022	true	include.in.token.scope
baea9655-0cce-403a-af40-14c343d7b97d	true	display.on.consent.screen
baea9655-0cce-403a-af40-14c343d7b97d	${rolesScopeConsentText}	consent.screen.text
baea9655-0cce-403a-af40-14c343d7b97d	false	include.in.token.scope
86007ce1-cb1c-4a3b-aed9-5030a7e42acc	false	display.on.consent.screen
86007ce1-cb1c-4a3b-aed9-5030a7e42acc		consent.screen.text
86007ce1-cb1c-4a3b-aed9-5030a7e42acc	false	include.in.token.scope
f25eafa6-89a3-4734-9ca7-11329dc181d3	false	display.on.consent.screen
f25eafa6-89a3-4734-9ca7-11329dc181d3	true	include.in.token.scope
bb65f812-e812-4bf1-aee8-0776c436b711	true	display.on.consent.screen
bb65f812-e812-4bf1-aee8-0776c436b711	${offlineAccessScopeConsentText}	consent.screen.text
6ab21a08-f270-4c47-baec-9ecaa075a492	true	display.on.consent.screen
6ab21a08-f270-4c47-baec-9ecaa075a492	${samlRoleListScopeConsentText}	consent.screen.text
edc90a1e-e346-4d1f-8cb7-8a2ecfbb3189	true	display.on.consent.screen
edc90a1e-e346-4d1f-8cb7-8a2ecfbb3189	${profileScopeConsentText}	consent.screen.text
edc90a1e-e346-4d1f-8cb7-8a2ecfbb3189	true	include.in.token.scope
1e90b592-874e-44de-86a2-fc0f6b070e42	true	display.on.consent.screen
1e90b592-874e-44de-86a2-fc0f6b070e42	${emailScopeConsentText}	consent.screen.text
1e90b592-874e-44de-86a2-fc0f6b070e42	true	include.in.token.scope
bedb72d4-f331-4238-9db7-33295a37136c	true	display.on.consent.screen
bedb72d4-f331-4238-9db7-33295a37136c	${addressScopeConsentText}	consent.screen.text
bedb72d4-f331-4238-9db7-33295a37136c	true	include.in.token.scope
f5922278-676a-4e9f-bde4-7a1f9d98aeaf	true	display.on.consent.screen
f5922278-676a-4e9f-bde4-7a1f9d98aeaf	${phoneScopeConsentText}	consent.screen.text
f5922278-676a-4e9f-bde4-7a1f9d98aeaf	true	include.in.token.scope
9f5243a8-bf2e-4f55-bef5-53d9bc0e4752	true	display.on.consent.screen
9f5243a8-bf2e-4f55-bef5-53d9bc0e4752	${rolesScopeConsentText}	consent.screen.text
9f5243a8-bf2e-4f55-bef5-53d9bc0e4752	false	include.in.token.scope
f124c487-b123-41d2-9b56-380cf6d7f42b	false	display.on.consent.screen
f124c487-b123-41d2-9b56-380cf6d7f42b		consent.screen.text
f124c487-b123-41d2-9b56-380cf6d7f42b	false	include.in.token.scope
1430b17c-e711-4114-8f9c-900cfda97dd5	false	display.on.consent.screen
1430b17c-e711-4114-8f9c-900cfda97dd5	true	include.in.token.scope
\.


--
-- Data for Name: client_scope_client; Type: TABLE DATA; Schema: public; Owner: keycloak
--

COPY public.client_scope_client (client_id, scope_id, default_scope) FROM stdin;
e3222dd4-baa4-4f42-9042-e0190fb22ef8	373bdcaf-2669-4cd5-b2b0-cfaee6acba99	t
e3222dd4-baa4-4f42-9042-e0190fb22ef8	86007ce1-cb1c-4a3b-aed9-5030a7e42acc	t
e3222dd4-baa4-4f42-9042-e0190fb22ef8	c243f89b-c6d0-4fc4-9392-a4eaaacb9b3e	t
e3222dd4-baa4-4f42-9042-e0190fb22ef8	baea9655-0cce-403a-af40-14c343d7b97d	t
e3222dd4-baa4-4f42-9042-e0190fb22ef8	40dede99-d0c8-4723-b60e-716e9e82e85f	f
e3222dd4-baa4-4f42-9042-e0190fb22ef8	f6fbfb19-4a16-4178-89d0-2e7e8579c022	f
e3222dd4-baa4-4f42-9042-e0190fb22ef8	f25eafa6-89a3-4734-9ca7-11329dc181d3	f
e3222dd4-baa4-4f42-9042-e0190fb22ef8	a62152f2-4d17-48f6-bd80-0ec85f4be131	f
3ac10acb-7ef8-4489-9077-16a81264dd18	373bdcaf-2669-4cd5-b2b0-cfaee6acba99	t
3ac10acb-7ef8-4489-9077-16a81264dd18	86007ce1-cb1c-4a3b-aed9-5030a7e42acc	t
3ac10acb-7ef8-4489-9077-16a81264dd18	c243f89b-c6d0-4fc4-9392-a4eaaacb9b3e	t
3ac10acb-7ef8-4489-9077-16a81264dd18	baea9655-0cce-403a-af40-14c343d7b97d	t
3ac10acb-7ef8-4489-9077-16a81264dd18	40dede99-d0c8-4723-b60e-716e9e82e85f	f
3ac10acb-7ef8-4489-9077-16a81264dd18	f6fbfb19-4a16-4178-89d0-2e7e8579c022	f
3ac10acb-7ef8-4489-9077-16a81264dd18	f25eafa6-89a3-4734-9ca7-11329dc181d3	f
3ac10acb-7ef8-4489-9077-16a81264dd18	a62152f2-4d17-48f6-bd80-0ec85f4be131	f
0a1f9cfc-c2e8-485c-9029-fa5e2154726a	373bdcaf-2669-4cd5-b2b0-cfaee6acba99	t
0a1f9cfc-c2e8-485c-9029-fa5e2154726a	86007ce1-cb1c-4a3b-aed9-5030a7e42acc	t
0a1f9cfc-c2e8-485c-9029-fa5e2154726a	c243f89b-c6d0-4fc4-9392-a4eaaacb9b3e	t
0a1f9cfc-c2e8-485c-9029-fa5e2154726a	baea9655-0cce-403a-af40-14c343d7b97d	t
0a1f9cfc-c2e8-485c-9029-fa5e2154726a	40dede99-d0c8-4723-b60e-716e9e82e85f	f
0a1f9cfc-c2e8-485c-9029-fa5e2154726a	f6fbfb19-4a16-4178-89d0-2e7e8579c022	f
0a1f9cfc-c2e8-485c-9029-fa5e2154726a	f25eafa6-89a3-4734-9ca7-11329dc181d3	f
0a1f9cfc-c2e8-485c-9029-fa5e2154726a	a62152f2-4d17-48f6-bd80-0ec85f4be131	f
45c60e97-84b5-4742-97d8-c57fa691d587	373bdcaf-2669-4cd5-b2b0-cfaee6acba99	t
45c60e97-84b5-4742-97d8-c57fa691d587	86007ce1-cb1c-4a3b-aed9-5030a7e42acc	t
45c60e97-84b5-4742-97d8-c57fa691d587	c243f89b-c6d0-4fc4-9392-a4eaaacb9b3e	t
45c60e97-84b5-4742-97d8-c57fa691d587	baea9655-0cce-403a-af40-14c343d7b97d	t
45c60e97-84b5-4742-97d8-c57fa691d587	40dede99-d0c8-4723-b60e-716e9e82e85f	f
45c60e97-84b5-4742-97d8-c57fa691d587	f6fbfb19-4a16-4178-89d0-2e7e8579c022	f
45c60e97-84b5-4742-97d8-c57fa691d587	f25eafa6-89a3-4734-9ca7-11329dc181d3	f
45c60e97-84b5-4742-97d8-c57fa691d587	a62152f2-4d17-48f6-bd80-0ec85f4be131	f
3f8f0ad2-a399-4b08-969d-cff26f73eb7d	373bdcaf-2669-4cd5-b2b0-cfaee6acba99	t
3f8f0ad2-a399-4b08-969d-cff26f73eb7d	86007ce1-cb1c-4a3b-aed9-5030a7e42acc	t
3f8f0ad2-a399-4b08-969d-cff26f73eb7d	c243f89b-c6d0-4fc4-9392-a4eaaacb9b3e	t
3f8f0ad2-a399-4b08-969d-cff26f73eb7d	baea9655-0cce-403a-af40-14c343d7b97d	t
3f8f0ad2-a399-4b08-969d-cff26f73eb7d	40dede99-d0c8-4723-b60e-716e9e82e85f	f
3f8f0ad2-a399-4b08-969d-cff26f73eb7d	f6fbfb19-4a16-4178-89d0-2e7e8579c022	f
3f8f0ad2-a399-4b08-969d-cff26f73eb7d	f25eafa6-89a3-4734-9ca7-11329dc181d3	f
3f8f0ad2-a399-4b08-969d-cff26f73eb7d	a62152f2-4d17-48f6-bd80-0ec85f4be131	f
eaa78be2-e4bb-47af-8f6b-5aa43b433ab5	373bdcaf-2669-4cd5-b2b0-cfaee6acba99	t
eaa78be2-e4bb-47af-8f6b-5aa43b433ab5	86007ce1-cb1c-4a3b-aed9-5030a7e42acc	t
eaa78be2-e4bb-47af-8f6b-5aa43b433ab5	c243f89b-c6d0-4fc4-9392-a4eaaacb9b3e	t
eaa78be2-e4bb-47af-8f6b-5aa43b433ab5	baea9655-0cce-403a-af40-14c343d7b97d	t
eaa78be2-e4bb-47af-8f6b-5aa43b433ab5	40dede99-d0c8-4723-b60e-716e9e82e85f	f
eaa78be2-e4bb-47af-8f6b-5aa43b433ab5	f6fbfb19-4a16-4178-89d0-2e7e8579c022	f
eaa78be2-e4bb-47af-8f6b-5aa43b433ab5	f25eafa6-89a3-4734-9ca7-11329dc181d3	f
eaa78be2-e4bb-47af-8f6b-5aa43b433ab5	a62152f2-4d17-48f6-bd80-0ec85f4be131	f
ae0a3deb-9d51-45a1-9fde-ac887ac98178	1e90b592-874e-44de-86a2-fc0f6b070e42	t
ae0a3deb-9d51-45a1-9fde-ac887ac98178	edc90a1e-e346-4d1f-8cb7-8a2ecfbb3189	t
ae0a3deb-9d51-45a1-9fde-ac887ac98178	9f5243a8-bf2e-4f55-bef5-53d9bc0e4752	t
ae0a3deb-9d51-45a1-9fde-ac887ac98178	f124c487-b123-41d2-9b56-380cf6d7f42b	t
ae0a3deb-9d51-45a1-9fde-ac887ac98178	f5922278-676a-4e9f-bde4-7a1f9d98aeaf	f
ae0a3deb-9d51-45a1-9fde-ac887ac98178	1430b17c-e711-4114-8f9c-900cfda97dd5	f
ae0a3deb-9d51-45a1-9fde-ac887ac98178	bb65f812-e812-4bf1-aee8-0776c436b711	f
ae0a3deb-9d51-45a1-9fde-ac887ac98178	bedb72d4-f331-4238-9db7-33295a37136c	f
b864547a-1317-4451-958b-b56a7fef9265	1e90b592-874e-44de-86a2-fc0f6b070e42	t
b864547a-1317-4451-958b-b56a7fef9265	edc90a1e-e346-4d1f-8cb7-8a2ecfbb3189	t
b864547a-1317-4451-958b-b56a7fef9265	9f5243a8-bf2e-4f55-bef5-53d9bc0e4752	t
b864547a-1317-4451-958b-b56a7fef9265	f124c487-b123-41d2-9b56-380cf6d7f42b	t
b864547a-1317-4451-958b-b56a7fef9265	f5922278-676a-4e9f-bde4-7a1f9d98aeaf	f
b864547a-1317-4451-958b-b56a7fef9265	1430b17c-e711-4114-8f9c-900cfda97dd5	f
b864547a-1317-4451-958b-b56a7fef9265	bb65f812-e812-4bf1-aee8-0776c436b711	f
b864547a-1317-4451-958b-b56a7fef9265	bedb72d4-f331-4238-9db7-33295a37136c	f
713b01e3-b893-4a01-a713-b755082711e8	1e90b592-874e-44de-86a2-fc0f6b070e42	t
713b01e3-b893-4a01-a713-b755082711e8	edc90a1e-e346-4d1f-8cb7-8a2ecfbb3189	t
713b01e3-b893-4a01-a713-b755082711e8	9f5243a8-bf2e-4f55-bef5-53d9bc0e4752	t
713b01e3-b893-4a01-a713-b755082711e8	f124c487-b123-41d2-9b56-380cf6d7f42b	t
713b01e3-b893-4a01-a713-b755082711e8	f5922278-676a-4e9f-bde4-7a1f9d98aeaf	f
713b01e3-b893-4a01-a713-b755082711e8	1430b17c-e711-4114-8f9c-900cfda97dd5	f
713b01e3-b893-4a01-a713-b755082711e8	bb65f812-e812-4bf1-aee8-0776c436b711	f
713b01e3-b893-4a01-a713-b755082711e8	bedb72d4-f331-4238-9db7-33295a37136c	f
89af4714-83b6-49d7-a06a-c7f1619d3be1	1e90b592-874e-44de-86a2-fc0f6b070e42	t
89af4714-83b6-49d7-a06a-c7f1619d3be1	edc90a1e-e346-4d1f-8cb7-8a2ecfbb3189	t
89af4714-83b6-49d7-a06a-c7f1619d3be1	9f5243a8-bf2e-4f55-bef5-53d9bc0e4752	t
89af4714-83b6-49d7-a06a-c7f1619d3be1	f124c487-b123-41d2-9b56-380cf6d7f42b	t
89af4714-83b6-49d7-a06a-c7f1619d3be1	f5922278-676a-4e9f-bde4-7a1f9d98aeaf	f
89af4714-83b6-49d7-a06a-c7f1619d3be1	1430b17c-e711-4114-8f9c-900cfda97dd5	f
89af4714-83b6-49d7-a06a-c7f1619d3be1	bb65f812-e812-4bf1-aee8-0776c436b711	f
89af4714-83b6-49d7-a06a-c7f1619d3be1	bedb72d4-f331-4238-9db7-33295a37136c	f
3cea1058-358e-4b9c-9d83-c1ffded25b90	1e90b592-874e-44de-86a2-fc0f6b070e42	t
3cea1058-358e-4b9c-9d83-c1ffded25b90	edc90a1e-e346-4d1f-8cb7-8a2ecfbb3189	t
3cea1058-358e-4b9c-9d83-c1ffded25b90	9f5243a8-bf2e-4f55-bef5-53d9bc0e4752	t
3cea1058-358e-4b9c-9d83-c1ffded25b90	f124c487-b123-41d2-9b56-380cf6d7f42b	t
3cea1058-358e-4b9c-9d83-c1ffded25b90	f5922278-676a-4e9f-bde4-7a1f9d98aeaf	f
3cea1058-358e-4b9c-9d83-c1ffded25b90	1430b17c-e711-4114-8f9c-900cfda97dd5	f
3cea1058-358e-4b9c-9d83-c1ffded25b90	bb65f812-e812-4bf1-aee8-0776c436b711	f
3cea1058-358e-4b9c-9d83-c1ffded25b90	bedb72d4-f331-4238-9db7-33295a37136c	f
6e12da5c-e596-4d59-a3af-c52dfc906e1d	1e90b592-874e-44de-86a2-fc0f6b070e42	t
6e12da5c-e596-4d59-a3af-c52dfc906e1d	edc90a1e-e346-4d1f-8cb7-8a2ecfbb3189	t
6e12da5c-e596-4d59-a3af-c52dfc906e1d	9f5243a8-bf2e-4f55-bef5-53d9bc0e4752	t
6e12da5c-e596-4d59-a3af-c52dfc906e1d	f124c487-b123-41d2-9b56-380cf6d7f42b	t
6e12da5c-e596-4d59-a3af-c52dfc906e1d	f5922278-676a-4e9f-bde4-7a1f9d98aeaf	f
6e12da5c-e596-4d59-a3af-c52dfc906e1d	1430b17c-e711-4114-8f9c-900cfda97dd5	f
6e12da5c-e596-4d59-a3af-c52dfc906e1d	bb65f812-e812-4bf1-aee8-0776c436b711	f
6e12da5c-e596-4d59-a3af-c52dfc906e1d	bedb72d4-f331-4238-9db7-33295a37136c	f
2c3c1eec-9294-4ead-84b4-ad87622f3d08	1e90b592-874e-44de-86a2-fc0f6b070e42	t
2c3c1eec-9294-4ead-84b4-ad87622f3d08	edc90a1e-e346-4d1f-8cb7-8a2ecfbb3189	t
2c3c1eec-9294-4ead-84b4-ad87622f3d08	9f5243a8-bf2e-4f55-bef5-53d9bc0e4752	t
2c3c1eec-9294-4ead-84b4-ad87622f3d08	f124c487-b123-41d2-9b56-380cf6d7f42b	t
2c3c1eec-9294-4ead-84b4-ad87622f3d08	f5922278-676a-4e9f-bde4-7a1f9d98aeaf	f
2c3c1eec-9294-4ead-84b4-ad87622f3d08	1430b17c-e711-4114-8f9c-900cfda97dd5	f
2c3c1eec-9294-4ead-84b4-ad87622f3d08	bb65f812-e812-4bf1-aee8-0776c436b711	f
2c3c1eec-9294-4ead-84b4-ad87622f3d08	bedb72d4-f331-4238-9db7-33295a37136c	f
\.


--
-- Data for Name: client_scope_role_mapping; Type: TABLE DATA; Schema: public; Owner: keycloak
--

COPY public.client_scope_role_mapping (scope_id, role_id) FROM stdin;
40dede99-d0c8-4723-b60e-716e9e82e85f	aa4bdbb6-6fa2-44b4-980c-12aa927819ab
bb65f812-e812-4bf1-aee8-0776c436b711	5f9f401f-2d60-4641-a1a2-83bc0971f864
\.


--
-- Data for Name: client_session; Type: TABLE DATA; Schema: public; Owner: keycloak
--

COPY public.client_session (id, client_id, redirect_uri, state, "timestamp", session_id, auth_method, realm_id, auth_user_id, current_action) FROM stdin;
\.


--
-- Data for Name: client_session_auth_status; Type: TABLE DATA; Schema: public; Owner: keycloak
--

COPY public.client_session_auth_status (authenticator, status, client_session) FROM stdin;
\.


--
-- Data for Name: client_session_note; Type: TABLE DATA; Schema: public; Owner: keycloak
--

COPY public.client_session_note (name, value, client_session) FROM stdin;
\.


--
-- Data for Name: client_session_prot_mapper; Type: TABLE DATA; Schema: public; Owner: keycloak
--

COPY public.client_session_prot_mapper (protocol_mapper_id, client_session) FROM stdin;
\.


--
-- Data for Name: client_session_role; Type: TABLE DATA; Schema: public; Owner: keycloak
--

COPY public.client_session_role (role_id, client_session) FROM stdin;
\.


--
-- Data for Name: client_user_session_note; Type: TABLE DATA; Schema: public; Owner: keycloak
--

COPY public.client_user_session_note (name, value, client_session) FROM stdin;
\.


--
-- Data for Name: component; Type: TABLE DATA; Schema: public; Owner: keycloak
--

COPY public.component (id, name, parent_id, provider_id, provider_type, realm_id, sub_type) FROM stdin;
af8460bf-ac19-4813-956a-7c4748b05cde	Trusted Hosts	master	trusted-hosts	org.keycloak.services.clientregistration.policy.ClientRegistrationPolicy	master	anonymous
ebf4e308-7908-438e-aee3-5f6715236a4f	Consent Required	master	consent-required	org.keycloak.services.clientregistration.policy.ClientRegistrationPolicy	master	anonymous
cecb2415-3736-4079-8d41-d5992adb4246	Full Scope Disabled	master	scope	org.keycloak.services.clientregistration.policy.ClientRegistrationPolicy	master	anonymous
2aa77088-688e-4a42-b2e8-908559e1cb2d	Max Clients Limit	master	max-clients	org.keycloak.services.clientregistration.policy.ClientRegistrationPolicy	master	anonymous
da5a8947-16d3-47c1-889b-e89782b096e2	Allowed Protocol Mapper Types	master	allowed-protocol-mappers	org.keycloak.services.clientregistration.policy.ClientRegistrationPolicy	master	anonymous
c7ef3dcd-e258-4664-b2c2-d8620154fa5b	Allowed Client Scopes	master	allowed-client-templates	org.keycloak.services.clientregistration.policy.ClientRegistrationPolicy	master	anonymous
dd82cb31-75c7-4fd2-a441-e21613bd7aea	Allowed Protocol Mapper Types	master	allowed-protocol-mappers	org.keycloak.services.clientregistration.policy.ClientRegistrationPolicy	master	authenticated
3baff968-453a-451a-9bd6-15d401fda88a	Allowed Client Scopes	master	allowed-client-templates	org.keycloak.services.clientregistration.policy.ClientRegistrationPolicy	master	authenticated
4a66dc67-fb5e-4a4e-a3b7-e536ea05241b	rsa-generated	master	rsa-generated	org.keycloak.keys.KeyProvider	master	\N
310a5a08-be2a-4b15-81de-9be97175a30e	hmac-generated	master	hmac-generated	org.keycloak.keys.KeyProvider	master	\N
ce6ba97d-cdf4-4043-9f21-22ee1e1842ee	aes-generated	master	aes-generated	org.keycloak.keys.KeyProvider	master	\N
39012e4e-03d5-45ab-a538-5426c5a1fcdc	rsa-generated	fiware_service	rsa-generated	org.keycloak.keys.KeyProvider	fiware_service	\N
829a9197-8e1a-4b00-991d-ba0c35bffa40	hmac-generated	fiware_service	hmac-generated	org.keycloak.keys.KeyProvider	fiware_service	\N
a5d33985-9200-4df6-bd97-9ef4ca007883	aes-generated	fiware_service	aes-generated	org.keycloak.keys.KeyProvider	fiware_service	\N
2feefbe8-face-475e-8881-06428a6bb418	Trusted Hosts	fiware_service	trusted-hosts	org.keycloak.services.clientregistration.policy.ClientRegistrationPolicy	fiware_service	anonymous
628c016d-df51-4917-95e0-c3646c416cf6	Consent Required	fiware_service	consent-required	org.keycloak.services.clientregistration.policy.ClientRegistrationPolicy	fiware_service	anonymous
60ef7a19-0333-456e-9db9-0e1ccf9cc7d8	Full Scope Disabled	fiware_service	scope	org.keycloak.services.clientregistration.policy.ClientRegistrationPolicy	fiware_service	anonymous
022c5475-4fe3-458c-89df-8acc98812793	Max Clients Limit	fiware_service	max-clients	org.keycloak.services.clientregistration.policy.ClientRegistrationPolicy	fiware_service	anonymous
26c91b6d-fbdf-4832-9f1c-041343a242c6	Allowed Protocol Mapper Types	fiware_service	allowed-protocol-mappers	org.keycloak.services.clientregistration.policy.ClientRegistrationPolicy	fiware_service	anonymous
75465cfc-aea2-4952-b060-24e7f3fe322d	Allowed Client Scopes	fiware_service	allowed-client-templates	org.keycloak.services.clientregistration.policy.ClientRegistrationPolicy	fiware_service	anonymous
ed8a09a5-992c-4aee-9e69-718755d08b47	Allowed Protocol Mapper Types	fiware_service	allowed-protocol-mappers	org.keycloak.services.clientregistration.policy.ClientRegistrationPolicy	fiware_service	authenticated
12d6e092-3fb2-4f7a-a549-dfa9a5fd20f7	Allowed Client Scopes	fiware_service	allowed-client-templates	org.keycloak.services.clientregistration.policy.ClientRegistrationPolicy	fiware_service	authenticated
\.


--
-- Data for Name: component_config; Type: TABLE DATA; Schema: public; Owner: keycloak
--

COPY public.component_config (id, component_id, name, value) FROM stdin;
87ffbe62-b5cf-49af-ae6c-88c5d74aac4b	af8460bf-ac19-4813-956a-7c4748b05cde	client-uris-must-match	true
2ad66b1a-8b02-47a7-a875-bb9fdb59d0d6	af8460bf-ac19-4813-956a-7c4748b05cde	host-sending-registration-request-must-match	true
75160555-0907-4d19-9c26-733f2dd52d85	dd82cb31-75c7-4fd2-a441-e21613bd7aea	allowed-protocol-mapper-types	oidc-full-name-mapper
8a4b38f6-52dd-48e6-9ec2-f86b5a94bff6	dd82cb31-75c7-4fd2-a441-e21613bd7aea	allowed-protocol-mapper-types	oidc-sha256-pairwise-sub-mapper
afb72192-f3cd-442d-be39-e3c9e3a89633	dd82cb31-75c7-4fd2-a441-e21613bd7aea	allowed-protocol-mapper-types	saml-role-list-mapper
8ba51173-4758-4804-b6c7-69da9308a25d	dd82cb31-75c7-4fd2-a441-e21613bd7aea	allowed-protocol-mapper-types	oidc-address-mapper
7c011a8e-a441-4db4-98cc-30634c211927	dd82cb31-75c7-4fd2-a441-e21613bd7aea	allowed-protocol-mapper-types	saml-user-attribute-mapper
43e5d354-47df-48b0-94e9-e9bf59f0b891	dd82cb31-75c7-4fd2-a441-e21613bd7aea	allowed-protocol-mapper-types	oidc-usermodel-attribute-mapper
f0462d7c-2717-49d9-a6b6-cd6cc7fb8471	dd82cb31-75c7-4fd2-a441-e21613bd7aea	allowed-protocol-mapper-types	oidc-usermodel-property-mapper
9ee5e382-5dff-4bfc-888c-aee3fe43e8e1	dd82cb31-75c7-4fd2-a441-e21613bd7aea	allowed-protocol-mapper-types	saml-user-property-mapper
75441391-16e0-42b4-bd4f-f671c9f2e650	2aa77088-688e-4a42-b2e8-908559e1cb2d	max-clients	200
de6fffa2-9012-4169-957b-d17c6f7bce4b	c7ef3dcd-e258-4664-b2c2-d8620154fa5b	allow-default-scopes	true
66603f8f-b044-44c8-83f6-fcf4c23d744d	3baff968-453a-451a-9bd6-15d401fda88a	allow-default-scopes	true
7641d0ab-e3ba-4f35-91d7-6b82ffd3a4fb	da5a8947-16d3-47c1-889b-e89782b096e2	allowed-protocol-mapper-types	oidc-sha256-pairwise-sub-mapper
3e4d22b0-b33f-42ee-bda4-1349981295da	da5a8947-16d3-47c1-889b-e89782b096e2	allowed-protocol-mapper-types	saml-role-list-mapper
0f8da72b-f337-4999-97c2-52e8fa2897bc	da5a8947-16d3-47c1-889b-e89782b096e2	allowed-protocol-mapper-types	oidc-usermodel-attribute-mapper
719d549b-1455-416f-ba72-936a39a74cc0	da5a8947-16d3-47c1-889b-e89782b096e2	allowed-protocol-mapper-types	saml-user-property-mapper
d0b02743-7275-4ca9-9029-5dfbb6c42993	da5a8947-16d3-47c1-889b-e89782b096e2	allowed-protocol-mapper-types	oidc-full-name-mapper
d704c7aa-cacb-47a9-836a-0de72428bff6	da5a8947-16d3-47c1-889b-e89782b096e2	allowed-protocol-mapper-types	oidc-usermodel-property-mapper
831316ca-a6b2-4a95-9cfd-8d98ee620faa	da5a8947-16d3-47c1-889b-e89782b096e2	allowed-protocol-mapper-types	saml-user-attribute-mapper
ec62df8e-3894-4562-a4c7-040b4d9ae721	da5a8947-16d3-47c1-889b-e89782b096e2	allowed-protocol-mapper-types	oidc-address-mapper
1b83d61a-3dce-4a76-afa0-0edb1cd75741	4a66dc67-fb5e-4a4e-a3b7-e536ea05241b	priority	100
e3ad32e6-d470-4657-9a07-028373e91fb0	4a66dc67-fb5e-4a4e-a3b7-e536ea05241b	privateKey	MIIEowIBAAKCAQEAo0PC3y74SkoktSxa5Kl3oCLCuQ/N0IMl1mt6jdo6n+EqhKDbAzvGmQevQ82QEjfQOvGOSAASIjqK4ihrHiP94Zi50XrHHDYZbQyG9ZvrwxQtULbEieC6eTQtz4jEmQLmNecsMPjM/kMCLp37gHD2HY5MlpgBF1eqLGGtVb/OQ3WyEamW06Cdx0mByG2gs/rJWgUBvWWAoUm0NtHPjE5lWuaJBkUdkOGYs3Z81S0uCB2ZFrOBuAsJaPPSGtYrpEfgFmHUDe9fGfB7eqhDLYUg5MD38J9B5gcyNB1XcZv2YI6LXs68nknZJlR7iKbZVBGcN+txRNPnQG4d+BdbiuS/vQIDAQABAoIBABU8wkOf64JWZLIAhA5MkRgOjX/fM2mVNb3Pm1CKe6fCdXJtLjAcfXf4jO7n9X65LegM9fIduD4lmV1T3qM8EVFgOYOrUe00iFgsEf4u+xsUK9TdAXHh/r+3buIZK2GwA9wtJw1zv86vTsBbopSRnSI5GXNZcILlz2gYiKCn45/YoAMLhPM8SFlewDDiu/rnMh/BbIdEjeSYFwCMZCHfBCx7Ntn/CCx1EgbxW4WQTUKe7Ug2063LcprZqOLGISonKEAdSjo1I5FX1MegZswx9dITG4l2NjtNBv9dsysJTZ+J43ADIKkaarXOmOMdY/MoRXXSQYW/PGnW6LM38w8OI0ECgYEA/xwNeNRNZ0mmRAG20vCukbDP5vyXj4709hbtaY8mVXGgJai0gIHIzGW+N6nr+QiXKnBP+NaYng4ieohJoyRorWk+4N2pgnzZn7LFjK1s+mZBdG7LCtGFbHjYBD3e0mxlBiBT9FPzZiGT5Ya+XsYj/hmHK3HPlVVKLieJhbZw780CgYEAo9WkholsRRC/knhHm/SCsJcsYzFxJXA0Bdhwy4pKNEMFXVpyAi7cTfCWWmbtpATVrrpx87TRz35dURK2sjtV1Oqmf4fbgTCcg+5oZAWcq1fDLnJudHmEjmArwQb7IZYQoHvQA/OkBUjhLU3IrPy60cvhLzZNE4Prftcrx/x5v7ECgYBeKH98cnejQNbCUROmpbj5AxapPd++19foIKw+Atz2OnsOi0ccC0sOzhq4Ntpmz1nkCxIpWSN5auQk77qmIWEVaDwSCR5wkB5OyFALzVLk1Oshy2bbtluVnsC0SBW++s0KxtHV40p6Drikxefr2RwdxFRUn6wrhRBdGrCyjpT+nQKBgBbyRk/dkX9+4AYIuKbcMS3AjqP5+cnvlCm5bdrkLI5zUJ4Jm+w4WfzElJpmziPp1W/ahzlF+xjfrvw67cG608O1dcpo4dKPV2yXCKHxs0bATQMFXfkMSAeU6qvnaWcD2KJRlQnopvFiir9IpLGt2BCoSIrPRS5VjLdANc6VywuRAoGBALdfF81ueMJrFl/Nffi/trlKrZlZZIwebE3Au/JMDH7POVc6umRABQ4cWoUpA1VzAR0grfmPiLqBkRkKvUu4rlQhpz8q+eX78EXznTYaj/675Akfh4PG0JxWQ4nm9RkZYuxcFbZpun78aQxSP2wyXZQ/P45qnVHRcCU7j6P+HTZG
f3116575-ca24-4629-9116-04150028fa01	4a66dc67-fb5e-4a4e-a3b7-e536ea05241b	certificate	MIICmzCCAYMCBgF6j78NADANBgkqhkiG9w0BAQsFADARMQ8wDQYDVQQDDAZtYXN0ZXIwHhcNMjEwNzEwMDkyNjQwWhcNMzEwNzEwMDkyODIwWjARMQ8wDQYDVQQDDAZtYXN0ZXIwggEiMA0GCSqGSIb3DQEBAQUAA4IBDwAwggEKAoIBAQCjQ8LfLvhKSiS1LFrkqXegIsK5D83QgyXWa3qN2jqf4SqEoNsDO8aZB69DzZASN9A68Y5IABIiOoriKGseI/3hmLnResccNhltDIb1m+vDFC1QtsSJ4Lp5NC3PiMSZAuY15yww+Mz+QwIunfuAcPYdjkyWmAEXV6osYa1Vv85DdbIRqZbToJ3HSYHIbaCz+slaBQG9ZYChSbQ20c+MTmVa5okGRR2Q4ZizdnzVLS4IHZkWs4G4Cwlo89Ia1iukR+AWYdQN718Z8Ht6qEMthSDkwPfwn0HmBzI0HVdxm/ZgjotezryeSdkmVHuIptlUEZw363FE0+dAbh34F1uK5L+9AgMBAAEwDQYJKoZIhvcNAQELBQADggEBAIXX9S1lmGomjewuR2iQ7RMsosIDPFviop95vpGAmT3DrLpeThTeOQw67zY2yTx1zmS+JLw29/j3uGGrPKP5/sdKMPXvEL5rD4xUIhe2A3pbQfsZXbbBD9HfBbTmaRVvr4J4SOuLZid+1b0h+x9lKgN1yO6xeLUN+5eQULz0kKBHXEUnJFwEC7NC/VcOPBkHGQdvi+RueawxhM3xZEyEfYVZcaS8nTl4zjlNooEnutJDQY46wnEu6v1+mkD5DE5TqZfcNvicgBWyuNsN48WX4J7KCbtBUSV2TEzrkaKojcQbS/36vgUSu5fbk5bUenG1aZLpXLnQgDEyvjcAkxtdzxI=
25563537-ef89-4baa-8ae6-9cb84dd101d3	ce6ba97d-cdf4-4043-9f21-22ee1e1842ee	priority	100
e5b3bba6-3da2-403a-89f1-a04bd522a49a	ce6ba97d-cdf4-4043-9f21-22ee1e1842ee	kid	a7be16b2-34e0-4c49-ba11-9eca1baec91a
9141fa29-6e02-4053-a1b4-994df9ba11ab	ce6ba97d-cdf4-4043-9f21-22ee1e1842ee	secret	DufqlmcyjBbrXM4iP_GlFw
4f2b008f-439f-4ed2-be6b-c707b953ff15	310a5a08-be2a-4b15-81de-9be97175a30e	priority	100
551c92fd-e6fa-4b96-a90c-66db26d52903	310a5a08-be2a-4b15-81de-9be97175a30e	kid	98875240-3bef-45fb-9187-9df8a9f32ff2
055d6398-d11e-474d-9143-fab593746274	310a5a08-be2a-4b15-81de-9be97175a30e	secret	DLl32NrznBBKx5TLgIYZW7XD0shc4MhUI0xOpkQvH3ifmodSf0xfwounuCkqB7EdlhDzZ2CMvk47Ev4gLWZxwA
10c0b5bf-bbe1-43a2-9878-6f3e924f04db	310a5a08-be2a-4b15-81de-9be97175a30e	algorithm	HS256
a187349f-c5b4-436e-bed1-79360e35be5c	a5d33985-9200-4df6-bd97-9ef4ca007883	kid	bcc7e547-e3aa-4bed-b479-32488907dafc
59138efd-c204-4987-aba9-e5e0034bbdde	a5d33985-9200-4df6-bd97-9ef4ca007883	priority	100
d3a01195-c81e-4d74-bda8-f9bea0a0e2a9	a5d33985-9200-4df6-bd97-9ef4ca007883	secret	RSGXKfTcEbiI0DPdQ7_XNw
9dab3976-6c3d-47c6-bc45-063f4ea8c51a	39012e4e-03d5-45ab-a538-5426c5a1fcdc	certificate	MIICqzCCAZMCBgF6j7+ASDANBgkqhkiG9w0BAQsFADAZMRcwFQYDVQQDDA5maXdhcmVfc2VydmljZTAeFw0yMTA3MTAwOTI3MDlaFw0zMTA3MTAwOTI4NDlaMBkxFzAVBgNVBAMMDmZpd2FyZV9zZXJ2aWNlMIIBIjANBgkqhkiG9w0BAQEFAAOCAQ8AMIIBCgKCAQEAqz/NHT2d1HkdkTr/jCIgin19MpuwMoWRMKY17qps1LXF4w1RBEcoeLyJH0POH3QipLC0sSXYGqUTaSRMxollxngxJQCQv89tdVDwHzidDEUHM5AdYC3FCNNtGW65teZ1YH/GNk+qYSg3I6q4cjNEEFDQ18DVoieBNv7oDymkcQB4KvAliABCvSQVzddAHS3ByrvNO7Ac5756alJIgwEIVf0uQ87durmGDxOV3pCnCGvEVxpJI5VkiA1cB9Y/PkN0ojLdQBas4xjNh8Kn5tmPXKPcxkjqqhPfpTuoUEH+oAhdq2AoVg+ptghryIor76HZb8FY1+JhFMtIuT8M0xqwkwIDAQABMA0GCSqGSIb3DQEBCwUAA4IBAQB1jqgeJ2s/qZDW5+wkEtaZ6Fznd61Jd/veoddJoQ8+JTf4qgMX+FoF7RpJsXurOZIWy4XfWmy514TKESNqGTGKH+FIYfTN0ENJ9L8IW9u8xqvl4M/I1mnZyXOQZ7ra1Vycl2vnIfhHIbL6gU10eHxbrhKe3B1BfllO5dFaGSXOFwrzMMuWYXclnF8ATGj++OJ9p7Y1jrssg0z43lVdK/4siOmAdvKkb6X7AO1sDVkHfhitngeBfREhibSFYE4ZG1tnYaXsqlJ6oMKI/rUv4wsAuQrVXW3CYSxTIevSabUebrLj7wnyKtPColT2ceLZ0VpkKfKYALuUeCusLoyxAKN3
f6ab25a0-d3e8-42a1-a261-3a9140d87ac8	39012e4e-03d5-45ab-a538-5426c5a1fcdc	privateKey	MIIEowIBAAKCAQEAqz/NHT2d1HkdkTr/jCIgin19MpuwMoWRMKY17qps1LXF4w1RBEcoeLyJH0POH3QipLC0sSXYGqUTaSRMxollxngxJQCQv89tdVDwHzidDEUHM5AdYC3FCNNtGW65teZ1YH/GNk+qYSg3I6q4cjNEEFDQ18DVoieBNv7oDymkcQB4KvAliABCvSQVzddAHS3ByrvNO7Ac5756alJIgwEIVf0uQ87durmGDxOV3pCnCGvEVxpJI5VkiA1cB9Y/PkN0ojLdQBas4xjNh8Kn5tmPXKPcxkjqqhPfpTuoUEH+oAhdq2AoVg+ptghryIor76HZb8FY1+JhFMtIuT8M0xqwkwIDAQABAoIBADjjUfUzwdmSfnL/YWMg9yRqeYu1UnwGCOxbWrE1JkAnPlyl0NMV/GjXYMnlEXU7dEK3fN8YTkjTq7YS2/pcLFYZGWJMZMmDU75UK+CDQxCPYcwMROXtbnX3HlgDg2fc7gMnjyX9owDxhhewH+O4ChVNc4MoyQ88Bl3JojdfQwRScU7HQPKHylT9HakveR9HZubMYJ/A990AAkEhd9/77QXIzwZ7KFOpyO+37v85FhLfkJboi8gr5OB6QFQvXQ1ZuLtIHIk47vX+W6eNrMrXngRfNrhMyWpqwGBHAg/W7SBB1Z+viJTd3PxSiklzE8AAk70crgJ5MmJBfxouygY9PDkCgYEA+duNBKz0gtXqG1zFaOeMlGL5pLtawtATwszFA2ZUomLFKs9tUY5yEVUPIKe55WXgqslQ3tlKl0MwBiOaHytMORzCqaPKYDTr1GdxXdwi+DBHXPD1PgDi6o4cLrWu7ppAKScGSPhwrrZ/tFPktw+j2FDZ9jzkjG7jJNAvDLt+UT8CgYEAr3WJrUH/N2X7DK0Mr8wKoLibv8a24jNTMZxnGdiguMI41r6QnsEArETj0aLgnlXqbzX7hd4plS/lr78yyTosEEvGcUgEeZB+KOczjBizi/GcoWwLcZggl3R4o0FQWAHv+YRlcKP37Ou239XaChS59Z/SbfxyGlxGW+jOGhEm960CgYASQv+9lb6RSX1A3rj2/+WAevNwHNl3X6nyFPFZXENXUwzCIkMFMPoZVjQy2M93esi+8tPcVdlj0N9Ts4pyOMHrcrSvnW8PNQ7/iUf56jsMFMtCecIS9BGhvx1ENLdCbTe/SkDlWHMz8dbHoVIYJyZ8ivxDSRQTR4+Gg0jND28eFQKBgF74XtIB4/OHZpCg5joNVj9STTNLitf68e/reT7bK3t13TAXK85SJ1wXWbyxzaTGWkNh08fMzXMr3sX21rVmoE0dxsawNYPbOv5GznbpM93upFoXUkZlElcIOvgatTM9sTe8eu+yQNLjbzPO29sTBui1XkAcIWK1SXwcEdq4KABtAoGBAJPtZbRplBBn+XRXxZ7KfYMQcqlbr/OFCBKMVoebLQfHj9B+Cy4goGjTBYeGZNAcOKJZyYMrzC9owXYiFJEJaghzyf7kFSv65X9e64nB46wWkXTT+ZsdLk74e3cjzKPDwMnWXbIdBMwa/m6QUScxvzYNyGViCWhgEfxOG+EqsdeJ
806bc87d-01ea-48a0-a37b-2b2695eb1524	39012e4e-03d5-45ab-a538-5426c5a1fcdc	priority	100
46868702-a72a-4030-ad17-0b9f8bd09e5b	829a9197-8e1a-4b00-991d-ba0c35bffa40	secret	C4uWJDDyWvRCCTCRjltwO1HAguEYSd6sV1VHiRgyu919OP5vaZ-BGbs4lBydVz6ZZOJodsVLpKp1Ct4xqcb_Zg
f7168c78-926d-4353-875d-841158fc2413	829a9197-8e1a-4b00-991d-ba0c35bffa40	kid	c953160c-20a2-4b44-bb94-5d8264686f35
5d9b04fd-6e48-4b99-a1a8-e4e317f746da	829a9197-8e1a-4b00-991d-ba0c35bffa40	priority	100
45b745c8-572c-4870-a48d-f49d79f480a1	829a9197-8e1a-4b00-991d-ba0c35bffa40	algorithm	HS256
913b0f6a-065e-42bf-8455-fc365f733293	75465cfc-aea2-4952-b060-24e7f3fe322d	allow-default-scopes	true
f5f1aac8-e48d-4a2a-8e6d-58e8ce7e70f6	022c5475-4fe3-458c-89df-8acc98812793	max-clients	200
99ceb83d-5e8f-4092-8aff-3f1488f0dd06	26c91b6d-fbdf-4832-9f1c-041343a242c6	allowed-protocol-mapper-types	saml-role-list-mapper
fbe21bc4-0c93-4057-a27f-54820af7ea48	26c91b6d-fbdf-4832-9f1c-041343a242c6	allowed-protocol-mapper-types	oidc-usermodel-property-mapper
341bb43f-f71f-430c-9a49-6eb79868a1ca	26c91b6d-fbdf-4832-9f1c-041343a242c6	allowed-protocol-mapper-types	oidc-full-name-mapper
e9c24cb6-044d-4b8e-be8d-3a75e7cfe506	26c91b6d-fbdf-4832-9f1c-041343a242c6	allowed-protocol-mapper-types	oidc-sha256-pairwise-sub-mapper
3aaf08fc-224a-4f4b-8603-1d5325b6d2d0	26c91b6d-fbdf-4832-9f1c-041343a242c6	allowed-protocol-mapper-types	oidc-address-mapper
75b4b6bb-eef7-4462-a917-1409d524c444	26c91b6d-fbdf-4832-9f1c-041343a242c6	allowed-protocol-mapper-types	saml-user-attribute-mapper
ce2c69d9-b275-49de-b384-44afdc2d8fff	26c91b6d-fbdf-4832-9f1c-041343a242c6	allowed-protocol-mapper-types	oidc-usermodel-attribute-mapper
4d87d383-e41b-470e-823c-b880fd7e6631	26c91b6d-fbdf-4832-9f1c-041343a242c6	allowed-protocol-mapper-types	saml-user-property-mapper
a31b64d5-2e5e-4afa-97e1-bdcbde9b6af2	ed8a09a5-992c-4aee-9e69-718755d08b47	allowed-protocol-mapper-types	saml-user-property-mapper
53b1103c-f759-45af-ac9c-13fd14c4dbf1	ed8a09a5-992c-4aee-9e69-718755d08b47	allowed-protocol-mapper-types	saml-user-attribute-mapper
38b1b688-cb44-47c3-b45d-6e28e96202c0	ed8a09a5-992c-4aee-9e69-718755d08b47	allowed-protocol-mapper-types	oidc-address-mapper
ddb62932-484e-4db7-ad09-67905e29ed2d	ed8a09a5-992c-4aee-9e69-718755d08b47	allowed-protocol-mapper-types	oidc-usermodel-property-mapper
4981808a-ecc4-4f9f-b780-44be6d1d3787	ed8a09a5-992c-4aee-9e69-718755d08b47	allowed-protocol-mapper-types	oidc-usermodel-attribute-mapper
f7b4d834-4102-494c-8458-872a73272896	ed8a09a5-992c-4aee-9e69-718755d08b47	allowed-protocol-mapper-types	saml-role-list-mapper
43b7c265-fa2e-4538-8ac7-f6bb8021f2bc	ed8a09a5-992c-4aee-9e69-718755d08b47	allowed-protocol-mapper-types	oidc-full-name-mapper
ffa1cb75-d0cc-491e-a829-dc8a9779e6b5	ed8a09a5-992c-4aee-9e69-718755d08b47	allowed-protocol-mapper-types	oidc-sha256-pairwise-sub-mapper
ae5035b7-d8a4-4a92-b5eb-fe92d27762ce	2feefbe8-face-475e-8881-06428a6bb418	host-sending-registration-request-must-match	true
95368a44-abb7-4651-ae3c-5d15b2b3a7b9	2feefbe8-face-475e-8881-06428a6bb418	client-uris-must-match	true
cba1d0a6-18f3-4c35-aabb-f34ceb49317c	12d6e092-3fb2-4f7a-a549-dfa9a5fd20f7	allow-default-scopes	true
\.


--
-- Data for Name: composite_role; Type: TABLE DATA; Schema: public; Owner: keycloak
--

COPY public.composite_role (composite, child_role) FROM stdin;
ef0cd6e4-9f1d-46f9-afc7-13ac35305d2a	f665eb74-b984-45af-8470-7b86826de9b8
ef0cd6e4-9f1d-46f9-afc7-13ac35305d2a	8086569b-aa21-4e5b-8a36-e20e27045bd6
ef0cd6e4-9f1d-46f9-afc7-13ac35305d2a	634122ef-9a08-4c96-a835-6304b9af6ddd
ef0cd6e4-9f1d-46f9-afc7-13ac35305d2a	7880de73-b0cb-4ed9-847e-6cd7aa4f30f1
ef0cd6e4-9f1d-46f9-afc7-13ac35305d2a	979459bc-d365-497f-ad07-acb94552c055
ef0cd6e4-9f1d-46f9-afc7-13ac35305d2a	56916e64-ae52-4e09-88c3-220855f2aaff
ef0cd6e4-9f1d-46f9-afc7-13ac35305d2a	5ff29db4-3882-4a29-9228-7d8c899424ac
ef0cd6e4-9f1d-46f9-afc7-13ac35305d2a	9beaca23-6a0c-4c5d-8792-f4c8dd8a79b3
ef0cd6e4-9f1d-46f9-afc7-13ac35305d2a	1cb33ca7-16b3-4eff-a829-adbe42ddfb47
ef0cd6e4-9f1d-46f9-afc7-13ac35305d2a	7be18d57-e82c-47cb-9059-3697e3d4d1eb
ef0cd6e4-9f1d-46f9-afc7-13ac35305d2a	af302ee6-90ab-49db-beea-c380eafc44fb
ef0cd6e4-9f1d-46f9-afc7-13ac35305d2a	231f7859-f54d-4a72-996c-859e87760b82
ef0cd6e4-9f1d-46f9-afc7-13ac35305d2a	73d55283-ed17-4e61-aea2-1f04f8f16c7b
ef0cd6e4-9f1d-46f9-afc7-13ac35305d2a	1d579813-ca3f-49b0-8e7d-36208c88a43c
ef0cd6e4-9f1d-46f9-afc7-13ac35305d2a	f4f9c91f-a819-4606-a827-6912c8d0836f
ef0cd6e4-9f1d-46f9-afc7-13ac35305d2a	e536f537-160b-4274-8daf-4dd23bdd7c7d
ef0cd6e4-9f1d-46f9-afc7-13ac35305d2a	b0b7e6fe-19d4-414c-af0a-5108c0184682
ef0cd6e4-9f1d-46f9-afc7-13ac35305d2a	19f19937-59ea-495f-9b91-923513b80ecd
979459bc-d365-497f-ad07-acb94552c055	e536f537-160b-4274-8daf-4dd23bdd7c7d
7880de73-b0cb-4ed9-847e-6cd7aa4f30f1	19f19937-59ea-495f-9b91-923513b80ecd
7880de73-b0cb-4ed9-847e-6cd7aa4f30f1	f4f9c91f-a819-4606-a827-6912c8d0836f
6db63c36-52fd-4a03-88ca-6dfa9538386f	feaf2529-cc90-4660-b07a-748e333528b9
6db63c36-52fd-4a03-88ca-6dfa9538386f	f448399b-6e3b-415d-88a4-817fc76b1bc5
f448399b-6e3b-415d-88a4-817fc76b1bc5	4b3a2a56-45eb-4b53-9657-84cf83c80990
82d6b41f-1bf4-4054-b93a-9f9f824bd105	6efe4b7b-d3b3-449a-bccf-9edcc6f38761
ef0cd6e4-9f1d-46f9-afc7-13ac35305d2a	c1c378c7-511a-4ab7-b4d6-83efedc1c6c5
6db63c36-52fd-4a03-88ca-6dfa9538386f	aa4bdbb6-6fa2-44b4-980c-12aa927819ab
6db63c36-52fd-4a03-88ca-6dfa9538386f	75c06f1b-84a6-42d1-82e9-e40ab3271c5c
ef0cd6e4-9f1d-46f9-afc7-13ac35305d2a	468ebd44-b3a0-414a-8d26-cedcc2619412
ef0cd6e4-9f1d-46f9-afc7-13ac35305d2a	d078f83a-827f-4ca5-bfc5-233c6862c9fb
ef0cd6e4-9f1d-46f9-afc7-13ac35305d2a	604a0e2c-eadc-41b8-82f9-74ed680eb156
ef0cd6e4-9f1d-46f9-afc7-13ac35305d2a	1414c86f-3ade-4118-ad2b-4c9efc42080c
ef0cd6e4-9f1d-46f9-afc7-13ac35305d2a	f83908a8-ee72-4e4a-94f9-a53a6c0b5e63
ef0cd6e4-9f1d-46f9-afc7-13ac35305d2a	e7ff4f32-0db3-430a-a06e-14fec2c356df
ef0cd6e4-9f1d-46f9-afc7-13ac35305d2a	c39cd10c-ba84-4b06-b97a-863ed8666567
ef0cd6e4-9f1d-46f9-afc7-13ac35305d2a	f1f47718-61ff-46fd-9fe4-9b2061cdd4b3
ef0cd6e4-9f1d-46f9-afc7-13ac35305d2a	731954a7-fa21-4ecd-8d32-ae090b0ef0fd
ef0cd6e4-9f1d-46f9-afc7-13ac35305d2a	439782e6-471e-47bd-9aa9-89d3c4a7bb3c
ef0cd6e4-9f1d-46f9-afc7-13ac35305d2a	2cbe30ff-d816-46d9-bb73-46b936fcdb52
ef0cd6e4-9f1d-46f9-afc7-13ac35305d2a	e2f3bb82-fbcb-45f9-9bad-68c0fcb4854d
ef0cd6e4-9f1d-46f9-afc7-13ac35305d2a	5dbb5537-2f1d-4f35-a04e-77f6e1cdc3a4
ef0cd6e4-9f1d-46f9-afc7-13ac35305d2a	6482da18-271a-48e1-8b55-062bfbe4a2d0
ef0cd6e4-9f1d-46f9-afc7-13ac35305d2a	6fb3268a-3ca6-43d9-85d8-c6d8ba580fb3
ef0cd6e4-9f1d-46f9-afc7-13ac35305d2a	fb8df4e4-4d93-4b95-8397-ace1c7a586fc
ef0cd6e4-9f1d-46f9-afc7-13ac35305d2a	d4de3d6a-2d9c-4c0c-87f2-874df57a0650
1414c86f-3ade-4118-ad2b-4c9efc42080c	6fb3268a-3ca6-43d9-85d8-c6d8ba580fb3
604a0e2c-eadc-41b8-82f9-74ed680eb156	6482da18-271a-48e1-8b55-062bfbe4a2d0
604a0e2c-eadc-41b8-82f9-74ed680eb156	d4de3d6a-2d9c-4c0c-87f2-874df57a0650
6dc0c70e-e458-4132-9c6b-e353057ef114	b55127fa-ed5c-4f10-9a8d-6f35c77006bd
6dc0c70e-e458-4132-9c6b-e353057ef114	590185cb-d4ad-481d-902c-a6ca17b46c63
6dc0c70e-e458-4132-9c6b-e353057ef114	bfde42a4-21ef-4292-af9b-da6ac9a45030
6dc0c70e-e458-4132-9c6b-e353057ef114	2b7cbdf7-3bc0-4133-9e03-1c134e08c119
6dc0c70e-e458-4132-9c6b-e353057ef114	5c8a5b83-4119-4d8e-aa99-6264327f38f3
6dc0c70e-e458-4132-9c6b-e353057ef114	4c572214-7f42-4c24-92f7-f8dd0114d761
6dc0c70e-e458-4132-9c6b-e353057ef114	2671b949-ab23-4c28-b208-75b6b10be914
6dc0c70e-e458-4132-9c6b-e353057ef114	1bb1e489-1b6c-4ce3-b7d6-ed66238b07eb
6dc0c70e-e458-4132-9c6b-e353057ef114	fb9eaccf-63a5-4130-bc96-228bd8196fb7
6dc0c70e-e458-4132-9c6b-e353057ef114	c5890f9a-65b2-415e-906f-efc3e326e02e
6dc0c70e-e458-4132-9c6b-e353057ef114	895377e9-fe42-4289-bb76-0fc63539bd45
6dc0c70e-e458-4132-9c6b-e353057ef114	105521cc-1a55-4864-958b-c35b7a604e88
6dc0c70e-e458-4132-9c6b-e353057ef114	260c68fe-5481-4d2f-bfa6-fc676733efb4
6dc0c70e-e458-4132-9c6b-e353057ef114	3eee919d-98ca-4b42-a722-c8de4a14b258
6dc0c70e-e458-4132-9c6b-e353057ef114	1136e5a8-ae4a-4f6a-8864-928a1db57ad3
6dc0c70e-e458-4132-9c6b-e353057ef114	68d35cad-b5e7-4b94-8208-dd9efd9c4402
6dc0c70e-e458-4132-9c6b-e353057ef114	4bbc68e0-6085-4665-978b-23f7ac01fce5
2b7cbdf7-3bc0-4133-9e03-1c134e08c119	1136e5a8-ae4a-4f6a-8864-928a1db57ad3
bfde42a4-21ef-4292-af9b-da6ac9a45030	4bbc68e0-6085-4665-978b-23f7ac01fce5
bfde42a4-21ef-4292-af9b-da6ac9a45030	3eee919d-98ca-4b42-a722-c8de4a14b258
f158f973-07e3-49d6-9d78-4b4c4c12d04b	7c8f3edb-893e-4777-b87a-7610f76f016c
f158f973-07e3-49d6-9d78-4b4c4c12d04b	fa8ede85-4362-4d1b-a84e-9ad7c666a558
fa8ede85-4362-4d1b-a84e-9ad7c666a558	c3824089-15df-49c6-9530-6d9404c4b0a6
5da9f919-4bcc-4f14-bb23-dbfdec3f702a	1650f8dd-8c7c-4d14-89fa-488febbe0985
ef0cd6e4-9f1d-46f9-afc7-13ac35305d2a	2c8c91ab-dfa4-4773-93fa-43a0715d61e7
6dc0c70e-e458-4132-9c6b-e353057ef114	e243ba60-2b76-42c6-a259-4f3126cdf550
f158f973-07e3-49d6-9d78-4b4c4c12d04b	5f9f401f-2d60-4641-a1a2-83bc0971f864
f158f973-07e3-49d6-9d78-4b4c4c12d04b	5d3f889a-a494-4673-beb0-af59964ad544
\.


--
-- Data for Name: credential; Type: TABLE DATA; Schema: public; Owner: keycloak
--

COPY public.credential (id, salt, type, user_id, created_date, user_label, secret_data, credential_data, priority) FROM stdin;
b3c5c6b8-ea01-445b-9ff7-b4fdd35bc881	\N	password	6229de20-bfed-49ed-8f3f-41bd0b5a6565	1625909300974	\N	{"value":"NWFo7i/jGqDmnVotRzONJQDc+rveNqQDL8II+Oe+YIZbv5L97ybHnv4OWJwik1WLXw+0YLEpy4JLiKpy/hD+UQ==","salt":"CZhBZLYeglSfaKmfxOyG2Q==","additionalParameters":{}}	{"hashIterations":27500,"algorithm":"pbkdf2-sha256","additionalParameters":{}}	10
d1dcb7dd-7077-4f6a-b631-d4d6c5fc981e	\N	password	a4883bb9-630f-40b9-867b-bfbe3d78e963	1625909842681		{"value":"NHYMPwB0zjTXv6sqq5v7f+lDPWDVJ6UaMV3FQnKC100JJoajYKlyCYoxibj8oRQaPuitIurmLokGhNleAGeR0Q==","salt":"utVYEHjjVfNRZF2eMXSWVw==","additionalParameters":{}}	{"hashIterations":27500,"algorithm":"pbkdf2-sha256","additionalParameters":{}}	10
\.


--
-- Data for Name: databasechangelog; Type: TABLE DATA; Schema: public; Owner: keycloak
--

COPY public.databasechangelog (id, author, filename, dateexecuted, orderexecuted, exectype, md5sum, description, comments, tag, liquibase, contexts, labels, deployment_id) FROM stdin;
1.0.0.Final-KEYCLOAK-5461	sthorger@redhat.com	META-INF/jpa-changelog-1.0.0.Final.xml	2021-07-10 09:28:13.715151	1	EXECUTED	7:4e70412f24a3f382c82183742ec79317	createTable tableName=APPLICATION_DEFAULT_ROLES; createTable tableName=CLIENT; createTable tableName=CLIENT_SESSION; createTable tableName=CLIENT_SESSION_ROLE; createTable tableName=COMPOSITE_ROLE; createTable tableName=CREDENTIAL; createTable tab...		\N	3.5.4	\N	\N	5909293335
1.0.0.Final-KEYCLOAK-5461	sthorger@redhat.com	META-INF/db2-jpa-changelog-1.0.0.Final.xml	2021-07-10 09:28:13.727397	2	MARK_RAN	7:cb16724583e9675711801c6875114f28	createTable tableName=APPLICATION_DEFAULT_ROLES; createTable tableName=CLIENT; createTable tableName=CLIENT_SESSION; createTable tableName=CLIENT_SESSION_ROLE; createTable tableName=COMPOSITE_ROLE; createTable tableName=CREDENTIAL; createTable tab...		\N	3.5.4	\N	\N	5909293335
1.1.0.Beta1	sthorger@redhat.com	META-INF/jpa-changelog-1.1.0.Beta1.xml	2021-07-10 09:28:13.771994	3	EXECUTED	7:0310eb8ba07cec616460794d42ade0fa	delete tableName=CLIENT_SESSION_ROLE; delete tableName=CLIENT_SESSION; delete tableName=USER_SESSION; createTable tableName=CLIENT_ATTRIBUTES; createTable tableName=CLIENT_SESSION_NOTE; createTable tableName=APP_NODE_REGISTRATIONS; addColumn table...		\N	3.5.4	\N	\N	5909293335
1.1.0.Final	sthorger@redhat.com	META-INF/jpa-changelog-1.1.0.Final.xml	2021-07-10 09:28:13.778166	4	EXECUTED	7:5d25857e708c3233ef4439df1f93f012	renameColumn newColumnName=EVENT_TIME, oldColumnName=TIME, tableName=EVENT_ENTITY		\N	3.5.4	\N	\N	5909293335
1.2.0.Beta1	psilva@redhat.com	META-INF/jpa-changelog-1.2.0.Beta1.xml	2021-07-10 09:28:13.883429	5	EXECUTED	7:c7a54a1041d58eb3817a4a883b4d4e84	delete tableName=CLIENT_SESSION_ROLE; delete tableName=CLIENT_SESSION_NOTE; delete tableName=CLIENT_SESSION; delete tableName=USER_SESSION; createTable tableName=PROTOCOL_MAPPER; createTable tableName=PROTOCOL_MAPPER_CONFIG; createTable tableName=...		\N	3.5.4	\N	\N	5909293335
1.2.0.Beta1	psilva@redhat.com	META-INF/db2-jpa-changelog-1.2.0.Beta1.xml	2021-07-10 09:28:13.887786	6	MARK_RAN	7:2e01012df20974c1c2a605ef8afe25b7	delete tableName=CLIENT_SESSION_ROLE; delete tableName=CLIENT_SESSION_NOTE; delete tableName=CLIENT_SESSION; delete tableName=USER_SESSION; createTable tableName=PROTOCOL_MAPPER; createTable tableName=PROTOCOL_MAPPER_CONFIG; createTable tableName=...		\N	3.5.4	\N	\N	5909293335
1.2.0.RC1	bburke@redhat.com	META-INF/jpa-changelog-1.2.0.CR1.xml	2021-07-10 09:28:13.981615	7	EXECUTED	7:0f08df48468428e0f30ee59a8ec01a41	delete tableName=CLIENT_SESSION_ROLE; delete tableName=CLIENT_SESSION_NOTE; delete tableName=CLIENT_SESSION; delete tableName=USER_SESSION_NOTE; delete tableName=USER_SESSION; createTable tableName=MIGRATION_MODEL; createTable tableName=IDENTITY_P...		\N	3.5.4	\N	\N	5909293335
1.2.0.RC1	bburke@redhat.com	META-INF/db2-jpa-changelog-1.2.0.CR1.xml	2021-07-10 09:28:13.986333	8	MARK_RAN	7:a77ea2ad226b345e7d689d366f185c8c	delete tableName=CLIENT_SESSION_ROLE; delete tableName=CLIENT_SESSION_NOTE; delete tableName=CLIENT_SESSION; delete tableName=USER_SESSION_NOTE; delete tableName=USER_SESSION; createTable tableName=MIGRATION_MODEL; createTable tableName=IDENTITY_P...		\N	3.5.4	\N	\N	5909293335
1.2.0.Final	keycloak	META-INF/jpa-changelog-1.2.0.Final.xml	2021-07-10 09:28:13.992192	9	EXECUTED	7:a3377a2059aefbf3b90ebb4c4cc8e2ab	update tableName=CLIENT; update tableName=CLIENT; update tableName=CLIENT		\N	3.5.4	\N	\N	5909293335
1.3.0	bburke@redhat.com	META-INF/jpa-changelog-1.3.0.xml	2021-07-10 09:28:14.113165	10	EXECUTED	7:04c1dbedc2aa3e9756d1a1668e003451	delete tableName=CLIENT_SESSION_ROLE; delete tableName=CLIENT_SESSION_PROT_MAPPER; delete tableName=CLIENT_SESSION_NOTE; delete tableName=CLIENT_SESSION; delete tableName=USER_SESSION_NOTE; delete tableName=USER_SESSION; createTable tableName=ADMI...		\N	3.5.4	\N	\N	5909293335
1.4.0	bburke@redhat.com	META-INF/jpa-changelog-1.4.0.xml	2021-07-10 09:28:14.172217	11	EXECUTED	7:36ef39ed560ad07062d956db861042ba	delete tableName=CLIENT_SESSION_AUTH_STATUS; delete tableName=CLIENT_SESSION_ROLE; delete tableName=CLIENT_SESSION_PROT_MAPPER; delete tableName=CLIENT_SESSION_NOTE; delete tableName=CLIENT_SESSION; delete tableName=USER_SESSION_NOTE; delete table...		\N	3.5.4	\N	\N	5909293335
1.4.0	bburke@redhat.com	META-INF/db2-jpa-changelog-1.4.0.xml	2021-07-10 09:28:14.176014	12	MARK_RAN	7:d909180b2530479a716d3f9c9eaea3d7	delete tableName=CLIENT_SESSION_AUTH_STATUS; delete tableName=CLIENT_SESSION_ROLE; delete tableName=CLIENT_SESSION_PROT_MAPPER; delete tableName=CLIENT_SESSION_NOTE; delete tableName=CLIENT_SESSION; delete tableName=USER_SESSION_NOTE; delete table...		\N	3.5.4	\N	\N	5909293335
1.5.0	bburke@redhat.com	META-INF/jpa-changelog-1.5.0.xml	2021-07-10 09:28:14.198546	13	EXECUTED	7:cf12b04b79bea5152f165eb41f3955f6	delete tableName=CLIENT_SESSION_AUTH_STATUS; delete tableName=CLIENT_SESSION_ROLE; delete tableName=CLIENT_SESSION_PROT_MAPPER; delete tableName=CLIENT_SESSION_NOTE; delete tableName=CLIENT_SESSION; delete tableName=USER_SESSION_NOTE; delete table...		\N	3.5.4	\N	\N	5909293335
1.6.1_from15	mposolda@redhat.com	META-INF/jpa-changelog-1.6.1.xml	2021-07-10 09:28:14.225633	14	EXECUTED	7:7e32c8f05c755e8675764e7d5f514509	addColumn tableName=REALM; addColumn tableName=KEYCLOAK_ROLE; addColumn tableName=CLIENT; createTable tableName=OFFLINE_USER_SESSION; createTable tableName=OFFLINE_CLIENT_SESSION; addPrimaryKey constraintName=CONSTRAINT_OFFL_US_SES_PK2, tableName=...		\N	3.5.4	\N	\N	5909293335
1.6.1_from16-pre	mposolda@redhat.com	META-INF/jpa-changelog-1.6.1.xml	2021-07-10 09:28:14.228577	15	MARK_RAN	7:980ba23cc0ec39cab731ce903dd01291	delete tableName=OFFLINE_CLIENT_SESSION; delete tableName=OFFLINE_USER_SESSION		\N	3.5.4	\N	\N	5909293335
1.6.1_from16	mposolda@redhat.com	META-INF/jpa-changelog-1.6.1.xml	2021-07-10 09:28:14.231834	16	MARK_RAN	7:2fa220758991285312eb84f3b4ff5336	dropPrimaryKey constraintName=CONSTRAINT_OFFLINE_US_SES_PK, tableName=OFFLINE_USER_SESSION; dropPrimaryKey constraintName=CONSTRAINT_OFFLINE_CL_SES_PK, tableName=OFFLINE_CLIENT_SESSION; addColumn tableName=OFFLINE_USER_SESSION; update tableName=OF...		\N	3.5.4	\N	\N	5909293335
1.6.1	mposolda@redhat.com	META-INF/jpa-changelog-1.6.1.xml	2021-07-10 09:28:14.235108	17	EXECUTED	7:d41d8cd98f00b204e9800998ecf8427e	empty		\N	3.5.4	\N	\N	5909293335
1.7.0	bburke@redhat.com	META-INF/jpa-changelog-1.7.0.xml	2021-07-10 09:28:14.286527	18	EXECUTED	7:91ace540896df890cc00a0490ee52bbc	createTable tableName=KEYCLOAK_GROUP; createTable tableName=GROUP_ROLE_MAPPING; createTable tableName=GROUP_ATTRIBUTE; createTable tableName=USER_GROUP_MEMBERSHIP; createTable tableName=REALM_DEFAULT_GROUPS; addColumn tableName=IDENTITY_PROVIDER; ...		\N	3.5.4	\N	\N	5909293335
1.8.0	mposolda@redhat.com	META-INF/jpa-changelog-1.8.0.xml	2021-07-10 09:28:14.332813	19	EXECUTED	7:c31d1646dfa2618a9335c00e07f89f24	addColumn tableName=IDENTITY_PROVIDER; createTable tableName=CLIENT_TEMPLATE; createTable tableName=CLIENT_TEMPLATE_ATTRIBUTES; createTable tableName=TEMPLATE_SCOPE_MAPPING; dropNotNullConstraint columnName=CLIENT_ID, tableName=PROTOCOL_MAPPER; ad...		\N	3.5.4	\N	\N	5909293335
1.8.0-2	keycloak	META-INF/jpa-changelog-1.8.0.xml	2021-07-10 09:28:14.339016	20	EXECUTED	7:df8bc21027a4f7cbbb01f6344e89ce07	dropDefaultValue columnName=ALGORITHM, tableName=CREDENTIAL; update tableName=CREDENTIAL		\N	3.5.4	\N	\N	5909293335
authz-3.4.0.CR1-resource-server-pk-change-part1	glavoie@gmail.com	META-INF/jpa-changelog-authz-3.4.0.CR1.xml	2021-07-10 09:28:15.660626	45	EXECUTED	7:6a48ce645a3525488a90fbf76adf3bb3	addColumn tableName=RESOURCE_SERVER_POLICY; addColumn tableName=RESOURCE_SERVER_RESOURCE; addColumn tableName=RESOURCE_SERVER_SCOPE		\N	3.5.4	\N	\N	5909293335
1.8.0	mposolda@redhat.com	META-INF/db2-jpa-changelog-1.8.0.xml	2021-07-10 09:28:14.342231	21	MARK_RAN	7:f987971fe6b37d963bc95fee2b27f8df	addColumn tableName=IDENTITY_PROVIDER; createTable tableName=CLIENT_TEMPLATE; createTable tableName=CLIENT_TEMPLATE_ATTRIBUTES; createTable tableName=TEMPLATE_SCOPE_MAPPING; dropNotNullConstraint columnName=CLIENT_ID, tableName=PROTOCOL_MAPPER; ad...		\N	3.5.4	\N	\N	5909293335
1.8.0-2	keycloak	META-INF/db2-jpa-changelog-1.8.0.xml	2021-07-10 09:28:14.345838	22	MARK_RAN	7:df8bc21027a4f7cbbb01f6344e89ce07	dropDefaultValue columnName=ALGORITHM, tableName=CREDENTIAL; update tableName=CREDENTIAL		\N	3.5.4	\N	\N	5909293335
1.9.0	mposolda@redhat.com	META-INF/jpa-changelog-1.9.0.xml	2021-07-10 09:28:14.393428	23	EXECUTED	7:ed2dc7f799d19ac452cbcda56c929e47	update tableName=REALM; update tableName=REALM; update tableName=REALM; update tableName=REALM; update tableName=CREDENTIAL; update tableName=CREDENTIAL; update tableName=CREDENTIAL; update tableName=REALM; update tableName=REALM; customChange; dr...		\N	3.5.4	\N	\N	5909293335
1.9.1	keycloak	META-INF/jpa-changelog-1.9.1.xml	2021-07-10 09:28:14.399587	24	EXECUTED	7:80b5db88a5dda36ece5f235be8757615	modifyDataType columnName=PRIVATE_KEY, tableName=REALM; modifyDataType columnName=PUBLIC_KEY, tableName=REALM; modifyDataType columnName=CERTIFICATE, tableName=REALM		\N	3.5.4	\N	\N	5909293335
1.9.1	keycloak	META-INF/db2-jpa-changelog-1.9.1.xml	2021-07-10 09:28:14.402922	25	MARK_RAN	7:1437310ed1305a9b93f8848f301726ce	modifyDataType columnName=PRIVATE_KEY, tableName=REALM; modifyDataType columnName=CERTIFICATE, tableName=REALM		\N	3.5.4	\N	\N	5909293335
1.9.2	keycloak	META-INF/jpa-changelog-1.9.2.xml	2021-07-10 09:28:14.597783	26	EXECUTED	7:b82ffb34850fa0836be16deefc6a87c4	createIndex indexName=IDX_USER_EMAIL, tableName=USER_ENTITY; createIndex indexName=IDX_USER_ROLE_MAPPING, tableName=USER_ROLE_MAPPING; createIndex indexName=IDX_USER_GROUP_MAPPING, tableName=USER_GROUP_MEMBERSHIP; createIndex indexName=IDX_USER_CO...		\N	3.5.4	\N	\N	5909293335
authz-2.0.0	psilva@redhat.com	META-INF/jpa-changelog-authz-2.0.0.xml	2021-07-10 09:28:14.688501	27	EXECUTED	7:9cc98082921330d8d9266decdd4bd658	createTable tableName=RESOURCE_SERVER; addPrimaryKey constraintName=CONSTRAINT_FARS, tableName=RESOURCE_SERVER; addUniqueConstraint constraintName=UK_AU8TT6T700S9V50BU18WS5HA6, tableName=RESOURCE_SERVER; createTable tableName=RESOURCE_SERVER_RESOU...		\N	3.5.4	\N	\N	5909293335
authz-2.5.1	psilva@redhat.com	META-INF/jpa-changelog-authz-2.5.1.xml	2021-07-10 09:28:14.692365	28	EXECUTED	7:03d64aeed9cb52b969bd30a7ac0db57e	update tableName=RESOURCE_SERVER_POLICY		\N	3.5.4	\N	\N	5909293335
2.1.0-KEYCLOAK-5461	bburke@redhat.com	META-INF/jpa-changelog-2.1.0.xml	2021-07-10 09:28:14.764499	29	EXECUTED	7:f1f9fd8710399d725b780f463c6b21cd	createTable tableName=BROKER_LINK; createTable tableName=FED_USER_ATTRIBUTE; createTable tableName=FED_USER_CONSENT; createTable tableName=FED_USER_CONSENT_ROLE; createTable tableName=FED_USER_CONSENT_PROT_MAPPER; createTable tableName=FED_USER_CR...		\N	3.5.4	\N	\N	5909293335
2.2.0	bburke@redhat.com	META-INF/jpa-changelog-2.2.0.xml	2021-07-10 09:28:14.781105	30	EXECUTED	7:53188c3eb1107546e6f765835705b6c1	addColumn tableName=ADMIN_EVENT_ENTITY; createTable tableName=CREDENTIAL_ATTRIBUTE; createTable tableName=FED_CREDENTIAL_ATTRIBUTE; modifyDataType columnName=VALUE, tableName=CREDENTIAL; addForeignKeyConstraint baseTableName=FED_CREDENTIAL_ATTRIBU...		\N	3.5.4	\N	\N	5909293335
2.3.0	bburke@redhat.com	META-INF/jpa-changelog-2.3.0.xml	2021-07-10 09:28:14.802409	31	EXECUTED	7:d6e6f3bc57a0c5586737d1351725d4d4	createTable tableName=FEDERATED_USER; addPrimaryKey constraintName=CONSTR_FEDERATED_USER, tableName=FEDERATED_USER; dropDefaultValue columnName=TOTP, tableName=USER_ENTITY; dropColumn columnName=TOTP, tableName=USER_ENTITY; addColumn tableName=IDE...		\N	3.5.4	\N	\N	5909293335
2.4.0	bburke@redhat.com	META-INF/jpa-changelog-2.4.0.xml	2021-07-10 09:28:14.807233	32	EXECUTED	7:454d604fbd755d9df3fd9c6329043aa5	customChange		\N	3.5.4	\N	\N	5909293335
2.5.0	bburke@redhat.com	META-INF/jpa-changelog-2.5.0.xml	2021-07-10 09:28:14.813477	33	EXECUTED	7:57e98a3077e29caf562f7dbf80c72600	customChange; modifyDataType columnName=USER_ID, tableName=OFFLINE_USER_SESSION		\N	3.5.4	\N	\N	5909293335
2.5.0-unicode-oracle	hmlnarik@redhat.com	META-INF/jpa-changelog-2.5.0.xml	2021-07-10 09:28:14.816318	34	MARK_RAN	7:e4c7e8f2256210aee71ddc42f538b57a	modifyDataType columnName=DESCRIPTION, tableName=AUTHENTICATION_FLOW; modifyDataType columnName=DESCRIPTION, tableName=CLIENT_TEMPLATE; modifyDataType columnName=DESCRIPTION, tableName=RESOURCE_SERVER_POLICY; modifyDataType columnName=DESCRIPTION,...		\N	3.5.4	\N	\N	5909293335
2.5.0-unicode-other-dbs	hmlnarik@redhat.com	META-INF/jpa-changelog-2.5.0.xml	2021-07-10 09:28:14.846251	35	EXECUTED	7:09a43c97e49bc626460480aa1379b522	modifyDataType columnName=DESCRIPTION, tableName=AUTHENTICATION_FLOW; modifyDataType columnName=DESCRIPTION, tableName=CLIENT_TEMPLATE; modifyDataType columnName=DESCRIPTION, tableName=RESOURCE_SERVER_POLICY; modifyDataType columnName=DESCRIPTION,...		\N	3.5.4	\N	\N	5909293335
2.5.0-duplicate-email-support	slawomir@dabek.name	META-INF/jpa-changelog-2.5.0.xml	2021-07-10 09:28:14.85249	36	EXECUTED	7:26bfc7c74fefa9126f2ce702fb775553	addColumn tableName=REALM		\N	3.5.4	\N	\N	5909293335
2.5.0-unique-group-names	hmlnarik@redhat.com	META-INF/jpa-changelog-2.5.0.xml	2021-07-10 09:28:14.861835	37	EXECUTED	7:a161e2ae671a9020fff61e996a207377	addUniqueConstraint constraintName=SIBLING_NAMES, tableName=KEYCLOAK_GROUP		\N	3.5.4	\N	\N	5909293335
2.5.1	bburke@redhat.com	META-INF/jpa-changelog-2.5.1.xml	2021-07-10 09:28:14.871093	38	EXECUTED	7:37fc1781855ac5388c494f1442b3f717	addColumn tableName=FED_USER_CONSENT		\N	3.5.4	\N	\N	5909293335
3.0.0	bburke@redhat.com	META-INF/jpa-changelog-3.0.0.xml	2021-07-10 09:28:14.880362	39	EXECUTED	7:13a27db0dae6049541136adad7261d27	addColumn tableName=IDENTITY_PROVIDER		\N	3.5.4	\N	\N	5909293335
3.2.0-fix	keycloak	META-INF/jpa-changelog-3.2.0.xml	2021-07-10 09:28:14.885838	40	MARK_RAN	7:550300617e3b59e8af3a6294df8248a3	addNotNullConstraint columnName=REALM_ID, tableName=CLIENT_INITIAL_ACCESS		\N	3.5.4	\N	\N	5909293335
3.2.0-fix-with-keycloak-5416	keycloak	META-INF/jpa-changelog-3.2.0.xml	2021-07-10 09:28:14.891214	41	MARK_RAN	7:e3a9482b8931481dc2772a5c07c44f17	dropIndex indexName=IDX_CLIENT_INIT_ACC_REALM, tableName=CLIENT_INITIAL_ACCESS; addNotNullConstraint columnName=REALM_ID, tableName=CLIENT_INITIAL_ACCESS; createIndex indexName=IDX_CLIENT_INIT_ACC_REALM, tableName=CLIENT_INITIAL_ACCESS		\N	3.5.4	\N	\N	5909293335
3.2.0-fix-offline-sessions	hmlnarik	META-INF/jpa-changelog-3.2.0.xml	2021-07-10 09:28:14.901667	42	EXECUTED	7:72b07d85a2677cb257edb02b408f332d	customChange		\N	3.5.4	\N	\N	5909293335
3.2.0-fixed	keycloak	META-INF/jpa-changelog-3.2.0.xml	2021-07-10 09:28:15.648513	43	EXECUTED	7:a72a7858967bd414835d19e04d880312	addColumn tableName=REALM; dropPrimaryKey constraintName=CONSTRAINT_OFFL_CL_SES_PK2, tableName=OFFLINE_CLIENT_SESSION; dropColumn columnName=CLIENT_SESSION_ID, tableName=OFFLINE_CLIENT_SESSION; addPrimaryKey constraintName=CONSTRAINT_OFFL_CL_SES_P...		\N	3.5.4	\N	\N	5909293335
3.3.0	keycloak	META-INF/jpa-changelog-3.3.0.xml	2021-07-10 09:28:15.654976	44	EXECUTED	7:94edff7cf9ce179e7e85f0cd78a3cf2c	addColumn tableName=USER_ENTITY		\N	3.5.4	\N	\N	5909293335
authz-3.4.0.CR1-resource-server-pk-change-part2-KEYCLOAK-6095	hmlnarik@redhat.com	META-INF/jpa-changelog-authz-3.4.0.CR1.xml	2021-07-10 09:28:15.664517	46	EXECUTED	7:e64b5dcea7db06077c6e57d3b9e5ca14	customChange		\N	3.5.4	\N	\N	5909293335
authz-3.4.0.CR1-resource-server-pk-change-part3-fixed	glavoie@gmail.com	META-INF/jpa-changelog-authz-3.4.0.CR1.xml	2021-07-10 09:28:15.666684	47	MARK_RAN	7:fd8cf02498f8b1e72496a20afc75178c	dropIndex indexName=IDX_RES_SERV_POL_RES_SERV, tableName=RESOURCE_SERVER_POLICY; dropIndex indexName=IDX_RES_SRV_RES_RES_SRV, tableName=RESOURCE_SERVER_RESOURCE; dropIndex indexName=IDX_RES_SRV_SCOPE_RES_SRV, tableName=RESOURCE_SERVER_SCOPE		\N	3.5.4	\N	\N	5909293335
authz-3.4.0.CR1-resource-server-pk-change-part3-fixed-nodropindex	glavoie@gmail.com	META-INF/jpa-changelog-authz-3.4.0.CR1.xml	2021-07-10 09:28:15.741815	48	EXECUTED	7:542794f25aa2b1fbabb7e577d6646319	addNotNullConstraint columnName=RESOURCE_SERVER_CLIENT_ID, tableName=RESOURCE_SERVER_POLICY; addNotNullConstraint columnName=RESOURCE_SERVER_CLIENT_ID, tableName=RESOURCE_SERVER_RESOURCE; addNotNullConstraint columnName=RESOURCE_SERVER_CLIENT_ID, ...		\N	3.5.4	\N	\N	5909293335
authn-3.4.0.CR1-refresh-token-max-reuse	glavoie@gmail.com	META-INF/jpa-changelog-authz-3.4.0.CR1.xml	2021-07-10 09:28:15.74642	49	EXECUTED	7:edad604c882df12f74941dac3cc6d650	addColumn tableName=REALM		\N	3.5.4	\N	\N	5909293335
3.4.0	keycloak	META-INF/jpa-changelog-3.4.0.xml	2021-07-10 09:28:15.809746	50	EXECUTED	7:0f88b78b7b46480eb92690cbf5e44900	addPrimaryKey constraintName=CONSTRAINT_REALM_DEFAULT_ROLES, tableName=REALM_DEFAULT_ROLES; addPrimaryKey constraintName=CONSTRAINT_COMPOSITE_ROLE, tableName=COMPOSITE_ROLE; addPrimaryKey constraintName=CONSTR_REALM_DEFAULT_GROUPS, tableName=REALM...		\N	3.5.4	\N	\N	5909293335
3.4.0-KEYCLOAK-5230	hmlnarik@redhat.com	META-INF/jpa-changelog-3.4.0.xml	2021-07-10 09:28:15.965684	51	EXECUTED	7:d560e43982611d936457c327f872dd59	createIndex indexName=IDX_FU_ATTRIBUTE, tableName=FED_USER_ATTRIBUTE; createIndex indexName=IDX_FU_CONSENT, tableName=FED_USER_CONSENT; createIndex indexName=IDX_FU_CONSENT_RU, tableName=FED_USER_CONSENT; createIndex indexName=IDX_FU_CREDENTIAL, t...		\N	3.5.4	\N	\N	5909293335
3.4.1	psilva@redhat.com	META-INF/jpa-changelog-3.4.1.xml	2021-07-10 09:28:15.970889	52	EXECUTED	7:c155566c42b4d14ef07059ec3b3bbd8e	modifyDataType columnName=VALUE, tableName=CLIENT_ATTRIBUTES		\N	3.5.4	\N	\N	5909293335
3.4.2	keycloak	META-INF/jpa-changelog-3.4.2.xml	2021-07-10 09:28:15.974556	53	EXECUTED	7:b40376581f12d70f3c89ba8ddf5b7dea	update tableName=REALM		\N	3.5.4	\N	\N	5909293335
3.4.2-KEYCLOAK-5172	mkanis@redhat.com	META-INF/jpa-changelog-3.4.2.xml	2021-07-10 09:28:15.977882	54	EXECUTED	7:a1132cc395f7b95b3646146c2e38f168	update tableName=CLIENT		\N	3.5.4	\N	\N	5909293335
4.0.0-KEYCLOAK-6335	bburke@redhat.com	META-INF/jpa-changelog-4.0.0.xml	2021-07-10 09:28:15.986672	55	EXECUTED	7:d8dc5d89c789105cfa7ca0e82cba60af	createTable tableName=CLIENT_AUTH_FLOW_BINDINGS; addPrimaryKey constraintName=C_CLI_FLOW_BIND, tableName=CLIENT_AUTH_FLOW_BINDINGS		\N	3.5.4	\N	\N	5909293335
4.0.0-CLEANUP-UNUSED-TABLE	bburke@redhat.com	META-INF/jpa-changelog-4.0.0.xml	2021-07-10 09:28:15.992262	56	EXECUTED	7:7822e0165097182e8f653c35517656a3	dropTable tableName=CLIENT_IDENTITY_PROV_MAPPING		\N	3.5.4	\N	\N	5909293335
4.0.0-KEYCLOAK-6228	bburke@redhat.com	META-INF/jpa-changelog-4.0.0.xml	2021-07-10 09:28:16.026063	57	EXECUTED	7:c6538c29b9c9a08f9e9ea2de5c2b6375	dropUniqueConstraint constraintName=UK_JKUWUVD56ONTGSUHOGM8UEWRT, tableName=USER_CONSENT; dropNotNullConstraint columnName=CLIENT_ID, tableName=USER_CONSENT; addColumn tableName=USER_CONSENT; addUniqueConstraint constraintName=UK_JKUWUVD56ONTGSUHO...		\N	3.5.4	\N	\N	5909293335
4.0.0-KEYCLOAK-5579-fixed	mposolda@redhat.com	META-INF/jpa-changelog-4.0.0.xml	2021-07-10 09:28:16.240421	58	EXECUTED	7:6d4893e36de22369cf73bcb051ded875	dropForeignKeyConstraint baseTableName=CLIENT_TEMPLATE_ATTRIBUTES, constraintName=FK_CL_TEMPL_ATTR_TEMPL; renameTable newTableName=CLIENT_SCOPE_ATTRIBUTES, oldTableName=CLIENT_TEMPLATE_ATTRIBUTES; renameColumn newColumnName=SCOPE_ID, oldColumnName...		\N	3.5.4	\N	\N	5909293335
authz-4.0.0.CR1	psilva@redhat.com	META-INF/jpa-changelog-authz-4.0.0.CR1.xml	2021-07-10 09:28:16.282962	59	EXECUTED	7:57960fc0b0f0dd0563ea6f8b2e4a1707	createTable tableName=RESOURCE_SERVER_PERM_TICKET; addPrimaryKey constraintName=CONSTRAINT_FAPMT, tableName=RESOURCE_SERVER_PERM_TICKET; addForeignKeyConstraint baseTableName=RESOURCE_SERVER_PERM_TICKET, constraintName=FK_FRSRHO213XCX4WNKOG82SSPMT...		\N	3.5.4	\N	\N	5909293335
authz-4.0.0.Beta3	psilva@redhat.com	META-INF/jpa-changelog-authz-4.0.0.Beta3.xml	2021-07-10 09:28:16.290782	60	EXECUTED	7:2b4b8bff39944c7097977cc18dbceb3b	addColumn tableName=RESOURCE_SERVER_POLICY; addColumn tableName=RESOURCE_SERVER_PERM_TICKET; addForeignKeyConstraint baseTableName=RESOURCE_SERVER_PERM_TICKET, constraintName=FK_FRSRPO2128CX4WNKOG82SSRFY, referencedTableName=RESOURCE_SERVER_POLICY		\N	3.5.4	\N	\N	5909293335
authz-4.2.0.Final	mhajas@redhat.com	META-INF/jpa-changelog-authz-4.2.0.Final.xml	2021-07-10 09:28:16.299321	61	EXECUTED	7:2aa42a964c59cd5b8ca9822340ba33a8	createTable tableName=RESOURCE_URIS; addForeignKeyConstraint baseTableName=RESOURCE_URIS, constraintName=FK_RESOURCE_SERVER_URIS, referencedTableName=RESOURCE_SERVER_RESOURCE; customChange; dropColumn columnName=URI, tableName=RESOURCE_SERVER_RESO...		\N	3.5.4	\N	\N	5909293335
authz-4.2.0.Final-KEYCLOAK-9944	hmlnarik@redhat.com	META-INF/jpa-changelog-authz-4.2.0.Final.xml	2021-07-10 09:28:16.308704	62	EXECUTED	7:9ac9e58545479929ba23f4a3087a0346	addPrimaryKey constraintName=CONSTRAINT_RESOUR_URIS_PK, tableName=RESOURCE_URIS		\N	3.5.4	\N	\N	5909293335
4.2.0-KEYCLOAK-6313	wadahiro@gmail.com	META-INF/jpa-changelog-4.2.0.xml	2021-07-10 09:28:16.313358	63	EXECUTED	7:14d407c35bc4fe1976867756bcea0c36	addColumn tableName=REQUIRED_ACTION_PROVIDER		\N	3.5.4	\N	\N	5909293335
4.3.0-KEYCLOAK-7984	wadahiro@gmail.com	META-INF/jpa-changelog-4.3.0.xml	2021-07-10 09:28:16.316698	64	EXECUTED	7:241a8030c748c8548e346adee548fa93	update tableName=REQUIRED_ACTION_PROVIDER		\N	3.5.4	\N	\N	5909293335
4.6.0-KEYCLOAK-7950	psilva@redhat.com	META-INF/jpa-changelog-4.6.0.xml	2021-07-10 09:28:16.320343	65	EXECUTED	7:7d3182f65a34fcc61e8d23def037dc3f	update tableName=RESOURCE_SERVER_RESOURCE		\N	3.5.4	\N	\N	5909293335
4.6.0-KEYCLOAK-8377	keycloak	META-INF/jpa-changelog-4.6.0.xml	2021-07-10 09:28:16.347871	66	EXECUTED	7:b30039e00a0b9715d430d1b0636728fa	createTable tableName=ROLE_ATTRIBUTE; addPrimaryKey constraintName=CONSTRAINT_ROLE_ATTRIBUTE_PK, tableName=ROLE_ATTRIBUTE; addForeignKeyConstraint baseTableName=ROLE_ATTRIBUTE, constraintName=FK_ROLE_ATTRIBUTE_ID, referencedTableName=KEYCLOAK_ROLE...		\N	3.5.4	\N	\N	5909293335
4.6.0-KEYCLOAK-8555	gideonray@gmail.com	META-INF/jpa-changelog-4.6.0.xml	2021-07-10 09:28:16.3646	67	EXECUTED	7:3797315ca61d531780f8e6f82f258159	createIndex indexName=IDX_COMPONENT_PROVIDER_TYPE, tableName=COMPONENT		\N	3.5.4	\N	\N	5909293335
4.7.0-KEYCLOAK-1267	sguilhen@redhat.com	META-INF/jpa-changelog-4.7.0.xml	2021-07-10 09:28:16.37049	68	EXECUTED	7:c7aa4c8d9573500c2d347c1941ff0301	addColumn tableName=REALM		\N	3.5.4	\N	\N	5909293335
4.7.0-KEYCLOAK-7275	keycloak	META-INF/jpa-changelog-4.7.0.xml	2021-07-10 09:28:16.388955	69	EXECUTED	7:b207faee394fc074a442ecd42185a5dd	renameColumn newColumnName=CREATED_ON, oldColumnName=LAST_SESSION_REFRESH, tableName=OFFLINE_USER_SESSION; addNotNullConstraint columnName=CREATED_ON, tableName=OFFLINE_USER_SESSION; addColumn tableName=OFFLINE_USER_SESSION; customChange; createIn...		\N	3.5.4	\N	\N	5909293335
4.8.0-KEYCLOAK-8835	sguilhen@redhat.com	META-INF/jpa-changelog-4.8.0.xml	2021-07-10 09:28:16.394309	70	EXECUTED	7:ab9a9762faaba4ddfa35514b212c4922	addNotNullConstraint columnName=SSO_MAX_LIFESPAN_REMEMBER_ME, tableName=REALM; addNotNullConstraint columnName=SSO_IDLE_TIMEOUT_REMEMBER_ME, tableName=REALM		\N	3.5.4	\N	\N	5909293335
authz-7.0.0-KEYCLOAK-10443	psilva@redhat.com	META-INF/jpa-changelog-authz-7.0.0.xml	2021-07-10 09:28:16.399082	71	EXECUTED	7:b9710f74515a6ccb51b72dc0d19df8c4	addColumn tableName=RESOURCE_SERVER		\N	3.5.4	\N	\N	5909293335
8.0.0-adding-credential-columns	keycloak	META-INF/jpa-changelog-8.0.0.xml	2021-07-10 09:28:16.406175	72	EXECUTED	7:ec9707ae4d4f0b7452fee20128083879	addColumn tableName=CREDENTIAL; addColumn tableName=FED_USER_CREDENTIAL		\N	3.5.4	\N	\N	5909293335
8.0.0-updating-credential-data-not-oracle-fixed	keycloak	META-INF/jpa-changelog-8.0.0.xml	2021-07-10 09:28:16.411393	73	EXECUTED	7:3979a0ae07ac465e920ca696532fc736	update tableName=CREDENTIAL; update tableName=CREDENTIAL; update tableName=CREDENTIAL; update tableName=FED_USER_CREDENTIAL; update tableName=FED_USER_CREDENTIAL; update tableName=FED_USER_CREDENTIAL		\N	3.5.4	\N	\N	5909293335
8.0.0-updating-credential-data-oracle-fixed	keycloak	META-INF/jpa-changelog-8.0.0.xml	2021-07-10 09:28:16.414001	74	MARK_RAN	7:5abfde4c259119d143bd2fbf49ac2bca	update tableName=CREDENTIAL; update tableName=CREDENTIAL; update tableName=CREDENTIAL; update tableName=FED_USER_CREDENTIAL; update tableName=FED_USER_CREDENTIAL; update tableName=FED_USER_CREDENTIAL		\N	3.5.4	\N	\N	5909293335
8.0.0-credential-cleanup-fixed	keycloak	META-INF/jpa-changelog-8.0.0.xml	2021-07-10 09:28:16.428857	75	EXECUTED	7:b48da8c11a3d83ddd6b7d0c8c2219345	dropDefaultValue columnName=COUNTER, tableName=CREDENTIAL; dropDefaultValue columnName=DIGITS, tableName=CREDENTIAL; dropDefaultValue columnName=PERIOD, tableName=CREDENTIAL; dropDefaultValue columnName=ALGORITHM, tableName=CREDENTIAL; dropColumn ...		\N	3.5.4	\N	\N	5909293335
8.0.0-resource-tag-support	keycloak	META-INF/jpa-changelog-8.0.0.xml	2021-07-10 09:28:16.447815	76	EXECUTED	7:a73379915c23bfad3e8f5c6d5c0aa4bd	addColumn tableName=MIGRATION_MODEL; createIndex indexName=IDX_UPDATE_TIME, tableName=MIGRATION_MODEL		\N	3.5.4	\N	\N	5909293335
9.0.0-always-display-client	keycloak	META-INF/jpa-changelog-9.0.0.xml	2021-07-10 09:28:16.453103	77	EXECUTED	7:39e0073779aba192646291aa2332493d	addColumn tableName=CLIENT		\N	3.5.4	\N	\N	5909293335
9.0.0-drop-constraints-for-column-increase	keycloak	META-INF/jpa-changelog-9.0.0.xml	2021-07-10 09:28:16.455898	78	MARK_RAN	7:81f87368f00450799b4bf42ea0b3ec34	dropUniqueConstraint constraintName=UK_FRSR6T700S9V50BU18WS5PMT, tableName=RESOURCE_SERVER_PERM_TICKET; dropUniqueConstraint constraintName=UK_FRSR6T700S9V50BU18WS5HA6, tableName=RESOURCE_SERVER_RESOURCE; dropPrimaryKey constraintName=CONSTRAINT_O...		\N	3.5.4	\N	\N	5909293335
9.0.0-increase-column-size-federated-fk	keycloak	META-INF/jpa-changelog-9.0.0.xml	2021-07-10 09:28:16.474251	79	EXECUTED	7:20b37422abb9fb6571c618148f013a15	modifyDataType columnName=CLIENT_ID, tableName=FED_USER_CONSENT; modifyDataType columnName=CLIENT_REALM_CONSTRAINT, tableName=KEYCLOAK_ROLE; modifyDataType columnName=OWNER, tableName=RESOURCE_SERVER_POLICY; modifyDataType columnName=CLIENT_ID, ta...		\N	3.5.4	\N	\N	5909293335
9.0.0-recreate-constraints-after-column-increase	keycloak	META-INF/jpa-changelog-9.0.0.xml	2021-07-10 09:28:16.477133	80	MARK_RAN	7:1970bb6cfb5ee800736b95ad3fb3c78a	addNotNullConstraint columnName=CLIENT_ID, tableName=OFFLINE_CLIENT_SESSION; addNotNullConstraint columnName=OWNER, tableName=RESOURCE_SERVER_PERM_TICKET; addNotNullConstraint columnName=REQUESTER, tableName=RESOURCE_SERVER_PERM_TICKET; addNotNull...		\N	3.5.4	\N	\N	5909293335
9.0.1-add-index-to-client.client_id	keycloak	META-INF/jpa-changelog-9.0.1.xml	2021-07-10 09:28:16.495016	81	EXECUTED	7:45d9b25fc3b455d522d8dcc10a0f4c80	createIndex indexName=IDX_CLIENT_ID, tableName=CLIENT		\N	3.5.4	\N	\N	5909293335
9.0.1-KEYCLOAK-12579-drop-constraints	keycloak	META-INF/jpa-changelog-9.0.1.xml	2021-07-10 09:28:16.498025	82	MARK_RAN	7:890ae73712bc187a66c2813a724d037f	dropUniqueConstraint constraintName=SIBLING_NAMES, tableName=KEYCLOAK_GROUP		\N	3.5.4	\N	\N	5909293335
9.0.1-KEYCLOAK-12579-add-not-null-constraint	keycloak	META-INF/jpa-changelog-9.0.1.xml	2021-07-10 09:28:16.503688	83	EXECUTED	7:0a211980d27fafe3ff50d19a3a29b538	addNotNullConstraint columnName=PARENT_GROUP, tableName=KEYCLOAK_GROUP		\N	3.5.4	\N	\N	5909293335
9.0.1-KEYCLOAK-12579-recreate-constraints	keycloak	META-INF/jpa-changelog-9.0.1.xml	2021-07-10 09:28:16.50646	84	MARK_RAN	7:a161e2ae671a9020fff61e996a207377	addUniqueConstraint constraintName=SIBLING_NAMES, tableName=KEYCLOAK_GROUP		\N	3.5.4	\N	\N	5909293335
9.0.1-add-index-to-events	keycloak	META-INF/jpa-changelog-9.0.1.xml	2021-07-10 09:28:16.524355	85	EXECUTED	7:01c49302201bdf815b0a18d1f98a55dc	createIndex indexName=IDX_EVENT_TIME, tableName=EVENT_ENTITY		\N	3.5.4	\N	\N	5909293335
map-remove-ri	keycloak	META-INF/jpa-changelog-11.0.0.xml	2021-07-10 09:28:16.531289	86	EXECUTED	7:3dace6b144c11f53f1ad2c0361279b86	dropForeignKeyConstraint baseTableName=REALM, constraintName=FK_TRAF444KK6QRKMS7N56AIWQ5Y; dropForeignKeyConstraint baseTableName=KEYCLOAK_ROLE, constraintName=FK_KJHO5LE2C0RAL09FL8CM9WFW9		\N	3.5.4	\N	\N	5909293335
map-remove-ri	keycloak	META-INF/jpa-changelog-12.0.0.xml	2021-07-10 09:28:16.539383	87	EXECUTED	7:578d0b92077eaf2ab95ad0ec087aa903	dropForeignKeyConstraint baseTableName=REALM_DEFAULT_GROUPS, constraintName=FK_DEF_GROUPS_GROUP; dropForeignKeyConstraint baseTableName=REALM_DEFAULT_ROLES, constraintName=FK_H4WPD7W4HSOOLNI3H0SW7BTJE; dropForeignKeyConstraint baseTableName=CLIENT...		\N	3.5.4	\N	\N	5909293335
12.1.0-add-realm-localization-table	keycloak	META-INF/jpa-changelog-12.0.0.xml	2021-07-10 09:28:16.552903	88	EXECUTED	7:c95abe90d962c57a09ecaee57972835d	createTable tableName=REALM_LOCALIZATIONS; addPrimaryKey tableName=REALM_LOCALIZATIONS		\N	3.5.4	\N	\N	5909293335
default-roles	keycloak	META-INF/jpa-changelog-13.0.0.xml	2021-07-10 09:28:16.559455	89	EXECUTED	7:f1313bcc2994a5c4dc1062ed6d8282d3	addColumn tableName=REALM; customChange		\N	3.5.4	\N	\N	5909293335
default-roles-cleanup	keycloak	META-INF/jpa-changelog-13.0.0.xml	2021-07-10 09:28:16.567506	90	EXECUTED	7:90d763b52eaffebefbcbde55f269508b	dropTable tableName=REALM_DEFAULT_ROLES; dropTable tableName=CLIENT_DEFAULT_ROLES		\N	3.5.4	\N	\N	5909293335
13.0.0-KEYCLOAK-16844	keycloak	META-INF/jpa-changelog-13.0.0.xml	2021-07-10 09:28:16.58513	91	EXECUTED	7:d554f0cb92b764470dccfa5e0014a7dd	createIndex indexName=IDX_OFFLINE_USS_PRELOAD, tableName=OFFLINE_USER_SESSION		\N	3.5.4	\N	\N	5909293335
map-remove-ri-13.0.0	keycloak	META-INF/jpa-changelog-13.0.0.xml	2021-07-10 09:28:16.594117	92	EXECUTED	7:73193e3ab3c35cf0f37ccea3bf783764	dropForeignKeyConstraint baseTableName=DEFAULT_CLIENT_SCOPE, constraintName=FK_R_DEF_CLI_SCOPE_SCOPE; dropForeignKeyConstraint baseTableName=CLIENT_SCOPE_CLIENT, constraintName=FK_C_CLI_SCOPE_SCOPE; dropForeignKeyConstraint baseTableName=CLIENT_SC...		\N	3.5.4	\N	\N	5909293335
13.0.0-KEYCLOAK-17992-drop-constraints	keycloak	META-INF/jpa-changelog-13.0.0.xml	2021-07-10 09:28:16.597016	93	MARK_RAN	7:90a1e74f92e9cbaa0c5eab80b8a037f3	dropPrimaryKey constraintName=C_CLI_SCOPE_BIND, tableName=CLIENT_SCOPE_CLIENT; dropIndex indexName=IDX_CLSCOPE_CL, tableName=CLIENT_SCOPE_CLIENT; dropIndex indexName=IDX_CL_CLSCOPE, tableName=CLIENT_SCOPE_CLIENT		\N	3.5.4	\N	\N	5909293335
13.0.0-increase-column-size-federated	keycloak	META-INF/jpa-changelog-13.0.0.xml	2021-07-10 09:28:16.608269	94	EXECUTED	7:5b9248f29cd047c200083cc6d8388b16	modifyDataType columnName=CLIENT_ID, tableName=CLIENT_SCOPE_CLIENT; modifyDataType columnName=SCOPE_ID, tableName=CLIENT_SCOPE_CLIENT		\N	3.5.4	\N	\N	5909293335
13.0.0-KEYCLOAK-17992-recreate-constraints	keycloak	META-INF/jpa-changelog-13.0.0.xml	2021-07-10 09:28:16.611166	95	MARK_RAN	7:64db59e44c374f13955489e8990d17a1	addNotNullConstraint columnName=CLIENT_ID, tableName=CLIENT_SCOPE_CLIENT; addNotNullConstraint columnName=SCOPE_ID, tableName=CLIENT_SCOPE_CLIENT; addPrimaryKey constraintName=C_CLI_SCOPE_BIND, tableName=CLIENT_SCOPE_CLIENT; createIndex indexName=...		\N	3.5.4	\N	\N	5909293335
json-string-accomodation-fixed	keycloak	META-INF/jpa-changelog-13.0.0.xml	2021-07-10 09:28:16.617645	96	EXECUTED	7:329a578cdb43262fff975f0a7f6cda60	addColumn tableName=REALM_ATTRIBUTE; update tableName=REALM_ATTRIBUTE; dropColumn columnName=VALUE, tableName=REALM_ATTRIBUTE; renameColumn newColumnName=VALUE, oldColumnName=VALUE_NEW, tableName=REALM_ATTRIBUTE		\N	3.5.4	\N	\N	5909293335
14.0.0-KEYCLOAK-11019	keycloak	META-INF/jpa-changelog-14.0.0.xml	2021-07-10 09:28:16.661854	97	EXECUTED	7:fae0de241ac0fd0bbc2b380b85e4f567	createIndex indexName=IDX_OFFLINE_CSS_PRELOAD, tableName=OFFLINE_CLIENT_SESSION; createIndex indexName=IDX_OFFLINE_USS_BY_USER, tableName=OFFLINE_USER_SESSION; createIndex indexName=IDX_OFFLINE_USS_BY_USERSESS, tableName=OFFLINE_USER_SESSION		\N	3.5.4	\N	\N	5909293335
14.0.0-KEYCLOAK-18286	keycloak	META-INF/jpa-changelog-14.0.0.xml	2021-07-10 09:28:16.681302	98	EXECUTED	7:075d54e9180f49bb0c64ca4218936e81	createIndex indexName=IDX_CLIENT_ATT_BY_NAME_VALUE, tableName=CLIENT_ATTRIBUTES		\N	3.5.4	\N	\N	5909293335
14.0.0-KEYCLOAK-18286-mysql	keycloak	META-INF/jpa-changelog-14.0.0.xml	2021-07-10 09:28:16.684479	99	MARK_RAN	7:b558ad47ea0e4d3c3514225a49cc0d65	createIndex indexName=IDX_CLIENT_ATT_BY_NAME_VALUE, tableName=CLIENT_ATTRIBUTES		\N	3.5.4	\N	\N	5909293335
KEYCLOAK-17267-add-index-to-user-attributes	keycloak	META-INF/jpa-changelog-14.0.0.xml	2021-07-10 09:28:16.702465	100	EXECUTED	7:1a7f28ff8d9e53aeb879d76ea3d9341a	createIndex indexName=IDX_USER_ATTRIBUTE_NAME, tableName=USER_ATTRIBUTE		\N	3.5.4	\N	\N	5909293335
KEYCLOAK-18146-add-saml-art-binding-identifier	keycloak	META-INF/jpa-changelog-14.0.0.xml	2021-07-10 09:28:16.707296	101	EXECUTED	7:2fd554456fed4a82c698c555c5b751b6	customChange		\N	3.5.4	\N	\N	5909293335
\.


--
-- Data for Name: databasechangeloglock; Type: TABLE DATA; Schema: public; Owner: keycloak
--

COPY public.databasechangeloglock (id, locked, lockgranted, lockedby) FROM stdin;
1	f	\N	\N
1000	f	\N	\N
1001	f	\N	\N
\.


--
-- Data for Name: default_client_scope; Type: TABLE DATA; Schema: public; Owner: keycloak
--

COPY public.default_client_scope (realm_id, scope_id, default_scope) FROM stdin;
master	40dede99-d0c8-4723-b60e-716e9e82e85f	f
master	35c7d452-01e3-49e7-bb27-be0e7177cbc0	t
master	c243f89b-c6d0-4fc4-9392-a4eaaacb9b3e	t
master	373bdcaf-2669-4cd5-b2b0-cfaee6acba99	t
master	a62152f2-4d17-48f6-bd80-0ec85f4be131	f
master	f6fbfb19-4a16-4178-89d0-2e7e8579c022	f
master	baea9655-0cce-403a-af40-14c343d7b97d	t
master	86007ce1-cb1c-4a3b-aed9-5030a7e42acc	t
master	f25eafa6-89a3-4734-9ca7-11329dc181d3	f
fiware_service	bb65f812-e812-4bf1-aee8-0776c436b711	f
fiware_service	6ab21a08-f270-4c47-baec-9ecaa075a492	t
fiware_service	edc90a1e-e346-4d1f-8cb7-8a2ecfbb3189	t
fiware_service	1e90b592-874e-44de-86a2-fc0f6b070e42	t
fiware_service	bedb72d4-f331-4238-9db7-33295a37136c	f
fiware_service	f5922278-676a-4e9f-bde4-7a1f9d98aeaf	f
fiware_service	9f5243a8-bf2e-4f55-bef5-53d9bc0e4752	t
fiware_service	f124c487-b123-41d2-9b56-380cf6d7f42b	t
fiware_service	1430b17c-e711-4114-8f9c-900cfda97dd5	f
\.


--
-- Data for Name: event_entity; Type: TABLE DATA; Schema: public; Owner: keycloak
--

COPY public.event_entity (id, client_id, details_json, error, ip_address, realm_id, session_id, event_time, type, user_id) FROM stdin;
\.


--
-- Data for Name: fed_user_attribute; Type: TABLE DATA; Schema: public; Owner: keycloak
--

COPY public.fed_user_attribute (id, name, user_id, realm_id, storage_provider_id, value) FROM stdin;
\.


--
-- Data for Name: fed_user_consent; Type: TABLE DATA; Schema: public; Owner: keycloak
--

COPY public.fed_user_consent (id, client_id, user_id, realm_id, storage_provider_id, created_date, last_updated_date, client_storage_provider, external_client_id) FROM stdin;
\.


--
-- Data for Name: fed_user_consent_cl_scope; Type: TABLE DATA; Schema: public; Owner: keycloak
--

COPY public.fed_user_consent_cl_scope (user_consent_id, scope_id) FROM stdin;
\.


--
-- Data for Name: fed_user_credential; Type: TABLE DATA; Schema: public; Owner: keycloak
--

COPY public.fed_user_credential (id, salt, type, created_date, user_id, realm_id, storage_provider_id, user_label, secret_data, credential_data, priority) FROM stdin;
\.


--
-- Data for Name: fed_user_group_membership; Type: TABLE DATA; Schema: public; Owner: keycloak
--

COPY public.fed_user_group_membership (group_id, user_id, realm_id, storage_provider_id) FROM stdin;
\.


--
-- Data for Name: fed_user_required_action; Type: TABLE DATA; Schema: public; Owner: keycloak
--

COPY public.fed_user_required_action (required_action, user_id, realm_id, storage_provider_id) FROM stdin;
\.


--
-- Data for Name: fed_user_role_mapping; Type: TABLE DATA; Schema: public; Owner: keycloak
--

COPY public.fed_user_role_mapping (role_id, user_id, realm_id, storage_provider_id) FROM stdin;
\.


--
-- Data for Name: federated_identity; Type: TABLE DATA; Schema: public; Owner: keycloak
--

COPY public.federated_identity (identity_provider, realm_id, federated_user_id, federated_username, token, user_id) FROM stdin;
\.


--
-- Data for Name: federated_user; Type: TABLE DATA; Schema: public; Owner: keycloak
--

COPY public.federated_user (id, storage_provider_id, realm_id) FROM stdin;
\.


--
-- Data for Name: group_attribute; Type: TABLE DATA; Schema: public; Owner: keycloak
--

COPY public.group_attribute (id, name, value, group_id) FROM stdin;
\.


--
-- Data for Name: group_role_mapping; Type: TABLE DATA; Schema: public; Owner: keycloak
--

COPY public.group_role_mapping (role_id, group_id) FROM stdin;
\.


--
-- Data for Name: identity_provider; Type: TABLE DATA; Schema: public; Owner: keycloak
--

COPY public.identity_provider (internal_id, enabled, provider_alias, provider_id, store_token, authenticate_by_default, realm_id, add_token_role, trust_email, first_broker_login_flow_id, post_broker_login_flow_id, provider_display_name, link_only) FROM stdin;
\.


--
-- Data for Name: identity_provider_config; Type: TABLE DATA; Schema: public; Owner: keycloak
--

COPY public.identity_provider_config (identity_provider_id, value, name) FROM stdin;
\.


--
-- Data for Name: identity_provider_mapper; Type: TABLE DATA; Schema: public; Owner: keycloak
--

COPY public.identity_provider_mapper (id, name, idp_alias, idp_mapper_name, realm_id) FROM stdin;
\.


--
-- Data for Name: idp_mapper_config; Type: TABLE DATA; Schema: public; Owner: keycloak
--

COPY public.idp_mapper_config (idp_mapper_id, value, name) FROM stdin;
\.


--
-- Data for Name: keycloak_group; Type: TABLE DATA; Schema: public; Owner: keycloak
--

COPY public.keycloak_group (id, name, parent_group, realm_id) FROM stdin;
\.


--
-- Data for Name: keycloak_role; Type: TABLE DATA; Schema: public; Owner: keycloak
--

COPY public.keycloak_role (id, client_realm_constraint, client_role, description, name, realm_id, client, realm) FROM stdin;
6db63c36-52fd-4a03-88ca-6dfa9538386f	master	f	${role_default-roles}	default-roles-master	master	\N	\N
ef0cd6e4-9f1d-46f9-afc7-13ac35305d2a	master	f	${role_admin}	admin	master	\N	\N
f665eb74-b984-45af-8470-7b86826de9b8	master	f	${role_create-realm}	create-realm	master	\N	\N
8086569b-aa21-4e5b-8a36-e20e27045bd6	3f8f0ad2-a399-4b08-969d-cff26f73eb7d	t	${role_create-client}	create-client	master	3f8f0ad2-a399-4b08-969d-cff26f73eb7d	\N
634122ef-9a08-4c96-a835-6304b9af6ddd	3f8f0ad2-a399-4b08-969d-cff26f73eb7d	t	${role_view-realm}	view-realm	master	3f8f0ad2-a399-4b08-969d-cff26f73eb7d	\N
7880de73-b0cb-4ed9-847e-6cd7aa4f30f1	3f8f0ad2-a399-4b08-969d-cff26f73eb7d	t	${role_view-users}	view-users	master	3f8f0ad2-a399-4b08-969d-cff26f73eb7d	\N
979459bc-d365-497f-ad07-acb94552c055	3f8f0ad2-a399-4b08-969d-cff26f73eb7d	t	${role_view-clients}	view-clients	master	3f8f0ad2-a399-4b08-969d-cff26f73eb7d	\N
56916e64-ae52-4e09-88c3-220855f2aaff	3f8f0ad2-a399-4b08-969d-cff26f73eb7d	t	${role_view-events}	view-events	master	3f8f0ad2-a399-4b08-969d-cff26f73eb7d	\N
5ff29db4-3882-4a29-9228-7d8c899424ac	3f8f0ad2-a399-4b08-969d-cff26f73eb7d	t	${role_view-identity-providers}	view-identity-providers	master	3f8f0ad2-a399-4b08-969d-cff26f73eb7d	\N
9beaca23-6a0c-4c5d-8792-f4c8dd8a79b3	3f8f0ad2-a399-4b08-969d-cff26f73eb7d	t	${role_view-authorization}	view-authorization	master	3f8f0ad2-a399-4b08-969d-cff26f73eb7d	\N
1cb33ca7-16b3-4eff-a829-adbe42ddfb47	3f8f0ad2-a399-4b08-969d-cff26f73eb7d	t	${role_manage-realm}	manage-realm	master	3f8f0ad2-a399-4b08-969d-cff26f73eb7d	\N
7be18d57-e82c-47cb-9059-3697e3d4d1eb	3f8f0ad2-a399-4b08-969d-cff26f73eb7d	t	${role_manage-users}	manage-users	master	3f8f0ad2-a399-4b08-969d-cff26f73eb7d	\N
af302ee6-90ab-49db-beea-c380eafc44fb	3f8f0ad2-a399-4b08-969d-cff26f73eb7d	t	${role_manage-clients}	manage-clients	master	3f8f0ad2-a399-4b08-969d-cff26f73eb7d	\N
231f7859-f54d-4a72-996c-859e87760b82	3f8f0ad2-a399-4b08-969d-cff26f73eb7d	t	${role_manage-events}	manage-events	master	3f8f0ad2-a399-4b08-969d-cff26f73eb7d	\N
73d55283-ed17-4e61-aea2-1f04f8f16c7b	3f8f0ad2-a399-4b08-969d-cff26f73eb7d	t	${role_manage-identity-providers}	manage-identity-providers	master	3f8f0ad2-a399-4b08-969d-cff26f73eb7d	\N
1d579813-ca3f-49b0-8e7d-36208c88a43c	3f8f0ad2-a399-4b08-969d-cff26f73eb7d	t	${role_manage-authorization}	manage-authorization	master	3f8f0ad2-a399-4b08-969d-cff26f73eb7d	\N
f4f9c91f-a819-4606-a827-6912c8d0836f	3f8f0ad2-a399-4b08-969d-cff26f73eb7d	t	${role_query-users}	query-users	master	3f8f0ad2-a399-4b08-969d-cff26f73eb7d	\N
e536f537-160b-4274-8daf-4dd23bdd7c7d	3f8f0ad2-a399-4b08-969d-cff26f73eb7d	t	${role_query-clients}	query-clients	master	3f8f0ad2-a399-4b08-969d-cff26f73eb7d	\N
b0b7e6fe-19d4-414c-af0a-5108c0184682	3f8f0ad2-a399-4b08-969d-cff26f73eb7d	t	${role_query-realms}	query-realms	master	3f8f0ad2-a399-4b08-969d-cff26f73eb7d	\N
19f19937-59ea-495f-9b91-923513b80ecd	3f8f0ad2-a399-4b08-969d-cff26f73eb7d	t	${role_query-groups}	query-groups	master	3f8f0ad2-a399-4b08-969d-cff26f73eb7d	\N
feaf2529-cc90-4660-b07a-748e333528b9	e3222dd4-baa4-4f42-9042-e0190fb22ef8	t	${role_view-profile}	view-profile	master	e3222dd4-baa4-4f42-9042-e0190fb22ef8	\N
f448399b-6e3b-415d-88a4-817fc76b1bc5	e3222dd4-baa4-4f42-9042-e0190fb22ef8	t	${role_manage-account}	manage-account	master	e3222dd4-baa4-4f42-9042-e0190fb22ef8	\N
4b3a2a56-45eb-4b53-9657-84cf83c80990	e3222dd4-baa4-4f42-9042-e0190fb22ef8	t	${role_manage-account-links}	manage-account-links	master	e3222dd4-baa4-4f42-9042-e0190fb22ef8	\N
1a921711-f87c-4066-942d-f7dac8a9e44b	e3222dd4-baa4-4f42-9042-e0190fb22ef8	t	${role_view-applications}	view-applications	master	e3222dd4-baa4-4f42-9042-e0190fb22ef8	\N
6efe4b7b-d3b3-449a-bccf-9edcc6f38761	e3222dd4-baa4-4f42-9042-e0190fb22ef8	t	${role_view-consent}	view-consent	master	e3222dd4-baa4-4f42-9042-e0190fb22ef8	\N
82d6b41f-1bf4-4054-b93a-9f9f824bd105	e3222dd4-baa4-4f42-9042-e0190fb22ef8	t	${role_manage-consent}	manage-consent	master	e3222dd4-baa4-4f42-9042-e0190fb22ef8	\N
7098be1a-0812-4bd8-9aaa-7fd4318ae980	e3222dd4-baa4-4f42-9042-e0190fb22ef8	t	${role_delete-account}	delete-account	master	e3222dd4-baa4-4f42-9042-e0190fb22ef8	\N
c11f306e-0b0a-4154-b98f-012f35c0512f	45c60e97-84b5-4742-97d8-c57fa691d587	t	${role_read-token}	read-token	master	45c60e97-84b5-4742-97d8-c57fa691d587	\N
c1c378c7-511a-4ab7-b4d6-83efedc1c6c5	3f8f0ad2-a399-4b08-969d-cff26f73eb7d	t	${role_impersonation}	impersonation	master	3f8f0ad2-a399-4b08-969d-cff26f73eb7d	\N
aa4bdbb6-6fa2-44b4-980c-12aa927819ab	master	f	${role_offline-access}	offline_access	master	\N	\N
75c06f1b-84a6-42d1-82e9-e40ab3271c5c	master	f	${role_uma_authorization}	uma_authorization	master	\N	\N
f158f973-07e3-49d6-9d78-4b4c4c12d04b	fiware_service	f	${role_default-roles}	default-roles-fiware_service	fiware_service	\N	\N
468ebd44-b3a0-414a-8d26-cedcc2619412	ccedade4-74d9-4315-9131-8c4f6a9b966f	t	${role_create-client}	create-client	master	ccedade4-74d9-4315-9131-8c4f6a9b966f	\N
d078f83a-827f-4ca5-bfc5-233c6862c9fb	ccedade4-74d9-4315-9131-8c4f6a9b966f	t	${role_view-realm}	view-realm	master	ccedade4-74d9-4315-9131-8c4f6a9b966f	\N
604a0e2c-eadc-41b8-82f9-74ed680eb156	ccedade4-74d9-4315-9131-8c4f6a9b966f	t	${role_view-users}	view-users	master	ccedade4-74d9-4315-9131-8c4f6a9b966f	\N
1414c86f-3ade-4118-ad2b-4c9efc42080c	ccedade4-74d9-4315-9131-8c4f6a9b966f	t	${role_view-clients}	view-clients	master	ccedade4-74d9-4315-9131-8c4f6a9b966f	\N
f83908a8-ee72-4e4a-94f9-a53a6c0b5e63	ccedade4-74d9-4315-9131-8c4f6a9b966f	t	${role_view-events}	view-events	master	ccedade4-74d9-4315-9131-8c4f6a9b966f	\N
e7ff4f32-0db3-430a-a06e-14fec2c356df	ccedade4-74d9-4315-9131-8c4f6a9b966f	t	${role_view-identity-providers}	view-identity-providers	master	ccedade4-74d9-4315-9131-8c4f6a9b966f	\N
c39cd10c-ba84-4b06-b97a-863ed8666567	ccedade4-74d9-4315-9131-8c4f6a9b966f	t	${role_view-authorization}	view-authorization	master	ccedade4-74d9-4315-9131-8c4f6a9b966f	\N
f1f47718-61ff-46fd-9fe4-9b2061cdd4b3	ccedade4-74d9-4315-9131-8c4f6a9b966f	t	${role_manage-realm}	manage-realm	master	ccedade4-74d9-4315-9131-8c4f6a9b966f	\N
731954a7-fa21-4ecd-8d32-ae090b0ef0fd	ccedade4-74d9-4315-9131-8c4f6a9b966f	t	${role_manage-users}	manage-users	master	ccedade4-74d9-4315-9131-8c4f6a9b966f	\N
439782e6-471e-47bd-9aa9-89d3c4a7bb3c	ccedade4-74d9-4315-9131-8c4f6a9b966f	t	${role_manage-clients}	manage-clients	master	ccedade4-74d9-4315-9131-8c4f6a9b966f	\N
2cbe30ff-d816-46d9-bb73-46b936fcdb52	ccedade4-74d9-4315-9131-8c4f6a9b966f	t	${role_manage-events}	manage-events	master	ccedade4-74d9-4315-9131-8c4f6a9b966f	\N
e2f3bb82-fbcb-45f9-9bad-68c0fcb4854d	ccedade4-74d9-4315-9131-8c4f6a9b966f	t	${role_manage-identity-providers}	manage-identity-providers	master	ccedade4-74d9-4315-9131-8c4f6a9b966f	\N
5dbb5537-2f1d-4f35-a04e-77f6e1cdc3a4	ccedade4-74d9-4315-9131-8c4f6a9b966f	t	${role_manage-authorization}	manage-authorization	master	ccedade4-74d9-4315-9131-8c4f6a9b966f	\N
6482da18-271a-48e1-8b55-062bfbe4a2d0	ccedade4-74d9-4315-9131-8c4f6a9b966f	t	${role_query-users}	query-users	master	ccedade4-74d9-4315-9131-8c4f6a9b966f	\N
6fb3268a-3ca6-43d9-85d8-c6d8ba580fb3	ccedade4-74d9-4315-9131-8c4f6a9b966f	t	${role_query-clients}	query-clients	master	ccedade4-74d9-4315-9131-8c4f6a9b966f	\N
fb8df4e4-4d93-4b95-8397-ace1c7a586fc	ccedade4-74d9-4315-9131-8c4f6a9b966f	t	${role_query-realms}	query-realms	master	ccedade4-74d9-4315-9131-8c4f6a9b966f	\N
d4de3d6a-2d9c-4c0c-87f2-874df57a0650	ccedade4-74d9-4315-9131-8c4f6a9b966f	t	${role_query-groups}	query-groups	master	ccedade4-74d9-4315-9131-8c4f6a9b966f	\N
6dc0c70e-e458-4132-9c6b-e353057ef114	3cea1058-358e-4b9c-9d83-c1ffded25b90	t	${role_realm-admin}	realm-admin	fiware_service	3cea1058-358e-4b9c-9d83-c1ffded25b90	\N
b55127fa-ed5c-4f10-9a8d-6f35c77006bd	3cea1058-358e-4b9c-9d83-c1ffded25b90	t	${role_create-client}	create-client	fiware_service	3cea1058-358e-4b9c-9d83-c1ffded25b90	\N
590185cb-d4ad-481d-902c-a6ca17b46c63	3cea1058-358e-4b9c-9d83-c1ffded25b90	t	${role_view-realm}	view-realm	fiware_service	3cea1058-358e-4b9c-9d83-c1ffded25b90	\N
bfde42a4-21ef-4292-af9b-da6ac9a45030	3cea1058-358e-4b9c-9d83-c1ffded25b90	t	${role_view-users}	view-users	fiware_service	3cea1058-358e-4b9c-9d83-c1ffded25b90	\N
2b7cbdf7-3bc0-4133-9e03-1c134e08c119	3cea1058-358e-4b9c-9d83-c1ffded25b90	t	${role_view-clients}	view-clients	fiware_service	3cea1058-358e-4b9c-9d83-c1ffded25b90	\N
5c8a5b83-4119-4d8e-aa99-6264327f38f3	3cea1058-358e-4b9c-9d83-c1ffded25b90	t	${role_view-events}	view-events	fiware_service	3cea1058-358e-4b9c-9d83-c1ffded25b90	\N
4c572214-7f42-4c24-92f7-f8dd0114d761	3cea1058-358e-4b9c-9d83-c1ffded25b90	t	${role_view-identity-providers}	view-identity-providers	fiware_service	3cea1058-358e-4b9c-9d83-c1ffded25b90	\N
2671b949-ab23-4c28-b208-75b6b10be914	3cea1058-358e-4b9c-9d83-c1ffded25b90	t	${role_view-authorization}	view-authorization	fiware_service	3cea1058-358e-4b9c-9d83-c1ffded25b90	\N
1bb1e489-1b6c-4ce3-b7d6-ed66238b07eb	3cea1058-358e-4b9c-9d83-c1ffded25b90	t	${role_manage-realm}	manage-realm	fiware_service	3cea1058-358e-4b9c-9d83-c1ffded25b90	\N
fb9eaccf-63a5-4130-bc96-228bd8196fb7	3cea1058-358e-4b9c-9d83-c1ffded25b90	t	${role_manage-users}	manage-users	fiware_service	3cea1058-358e-4b9c-9d83-c1ffded25b90	\N
c5890f9a-65b2-415e-906f-efc3e326e02e	3cea1058-358e-4b9c-9d83-c1ffded25b90	t	${role_manage-clients}	manage-clients	fiware_service	3cea1058-358e-4b9c-9d83-c1ffded25b90	\N
895377e9-fe42-4289-bb76-0fc63539bd45	3cea1058-358e-4b9c-9d83-c1ffded25b90	t	${role_manage-events}	manage-events	fiware_service	3cea1058-358e-4b9c-9d83-c1ffded25b90	\N
105521cc-1a55-4864-958b-c35b7a604e88	3cea1058-358e-4b9c-9d83-c1ffded25b90	t	${role_manage-identity-providers}	manage-identity-providers	fiware_service	3cea1058-358e-4b9c-9d83-c1ffded25b90	\N
260c68fe-5481-4d2f-bfa6-fc676733efb4	3cea1058-358e-4b9c-9d83-c1ffded25b90	t	${role_manage-authorization}	manage-authorization	fiware_service	3cea1058-358e-4b9c-9d83-c1ffded25b90	\N
3eee919d-98ca-4b42-a722-c8de4a14b258	3cea1058-358e-4b9c-9d83-c1ffded25b90	t	${role_query-users}	query-users	fiware_service	3cea1058-358e-4b9c-9d83-c1ffded25b90	\N
1136e5a8-ae4a-4f6a-8864-928a1db57ad3	3cea1058-358e-4b9c-9d83-c1ffded25b90	t	${role_query-clients}	query-clients	fiware_service	3cea1058-358e-4b9c-9d83-c1ffded25b90	\N
68d35cad-b5e7-4b94-8208-dd9efd9c4402	3cea1058-358e-4b9c-9d83-c1ffded25b90	t	${role_query-realms}	query-realms	fiware_service	3cea1058-358e-4b9c-9d83-c1ffded25b90	\N
4bbc68e0-6085-4665-978b-23f7ac01fce5	3cea1058-358e-4b9c-9d83-c1ffded25b90	t	${role_query-groups}	query-groups	fiware_service	3cea1058-358e-4b9c-9d83-c1ffded25b90	\N
7c8f3edb-893e-4777-b87a-7610f76f016c	ae0a3deb-9d51-45a1-9fde-ac887ac98178	t	${role_view-profile}	view-profile	fiware_service	ae0a3deb-9d51-45a1-9fde-ac887ac98178	\N
fa8ede85-4362-4d1b-a84e-9ad7c666a558	ae0a3deb-9d51-45a1-9fde-ac887ac98178	t	${role_manage-account}	manage-account	fiware_service	ae0a3deb-9d51-45a1-9fde-ac887ac98178	\N
c3824089-15df-49c6-9530-6d9404c4b0a6	ae0a3deb-9d51-45a1-9fde-ac887ac98178	t	${role_manage-account-links}	manage-account-links	fiware_service	ae0a3deb-9d51-45a1-9fde-ac887ac98178	\N
7c77a0c3-8b72-4504-96bb-802dd8a4578a	ae0a3deb-9d51-45a1-9fde-ac887ac98178	t	${role_view-applications}	view-applications	fiware_service	ae0a3deb-9d51-45a1-9fde-ac887ac98178	\N
1650f8dd-8c7c-4d14-89fa-488febbe0985	ae0a3deb-9d51-45a1-9fde-ac887ac98178	t	${role_view-consent}	view-consent	fiware_service	ae0a3deb-9d51-45a1-9fde-ac887ac98178	\N
5da9f919-4bcc-4f14-bb23-dbfdec3f702a	ae0a3deb-9d51-45a1-9fde-ac887ac98178	t	${role_manage-consent}	manage-consent	fiware_service	ae0a3deb-9d51-45a1-9fde-ac887ac98178	\N
6552cfbc-0734-48d7-9e72-ef99dfcbc07a	ae0a3deb-9d51-45a1-9fde-ac887ac98178	t	${role_delete-account}	delete-account	fiware_service	ae0a3deb-9d51-45a1-9fde-ac887ac98178	\N
2c8c91ab-dfa4-4773-93fa-43a0715d61e7	ccedade4-74d9-4315-9131-8c4f6a9b966f	t	${role_impersonation}	impersonation	master	ccedade4-74d9-4315-9131-8c4f6a9b966f	\N
e243ba60-2b76-42c6-a259-4f3126cdf550	3cea1058-358e-4b9c-9d83-c1ffded25b90	t	${role_impersonation}	impersonation	fiware_service	3cea1058-358e-4b9c-9d83-c1ffded25b90	\N
932033c0-f1ab-46a6-bfc9-81e997009c12	89af4714-83b6-49d7-a06a-c7f1619d3be1	t	${role_read-token}	read-token	fiware_service	89af4714-83b6-49d7-a06a-c7f1619d3be1	\N
5f9f401f-2d60-4641-a1a2-83bc0971f864	fiware_service	f	${role_offline-access}	offline_access	fiware_service	\N	\N
5d3f889a-a494-4673-beb0-af59964ad544	fiware_service	f	${role_uma_authorization}	uma_authorization	fiware_service	\N	\N
\.


--
-- Data for Name: migration_model; Type: TABLE DATA; Schema: public; Owner: keycloak
--

COPY public.migration_model (id, version, update_time) FROM stdin;
5pco3	14.0.0	1625909299
\.


--
-- Data for Name: offline_client_session; Type: TABLE DATA; Schema: public; Owner: keycloak
--

COPY public.offline_client_session (user_session_id, client_id, offline_flag, "timestamp", data, client_storage_provider, external_client_id) FROM stdin;
\.


--
-- Data for Name: offline_user_session; Type: TABLE DATA; Schema: public; Owner: keycloak
--

COPY public.offline_user_session (user_session_id, user_id, realm_id, created_on, offline_flag, data, last_session_refresh) FROM stdin;
\.


--
-- Data for Name: policy_config; Type: TABLE DATA; Schema: public; Owner: keycloak
--

COPY public.policy_config (policy_id, name, value) FROM stdin;
\.


--
-- Data for Name: protocol_mapper; Type: TABLE DATA; Schema: public; Owner: keycloak
--

COPY public.protocol_mapper (id, name, protocol, protocol_mapper_name, client_id, client_scope_id) FROM stdin;
6730cc98-eb6b-44ab-9e86-4761183d1542	audience resolve	openid-connect	oidc-audience-resolve-mapper	3ac10acb-7ef8-4489-9077-16a81264dd18	\N
14f537d2-f81f-4975-90f8-a3958a1dbd36	locale	openid-connect	oidc-usermodel-attribute-mapper	eaa78be2-e4bb-47af-8f6b-5aa43b433ab5	\N
7cf33591-73f8-40ab-b190-095f2d16d58f	role list	saml	saml-role-list-mapper	\N	35c7d452-01e3-49e7-bb27-be0e7177cbc0
81e72056-dc80-468a-af2b-bf36231411b1	full name	openid-connect	oidc-full-name-mapper	\N	c243f89b-c6d0-4fc4-9392-a4eaaacb9b3e
e21ef430-2bab-4b9e-b08c-5ec7b1c93e2c	family name	openid-connect	oidc-usermodel-property-mapper	\N	c243f89b-c6d0-4fc4-9392-a4eaaacb9b3e
dfbae996-94bb-40e0-919a-c85183f3e9f2	given name	openid-connect	oidc-usermodel-property-mapper	\N	c243f89b-c6d0-4fc4-9392-a4eaaacb9b3e
4363ede4-0d61-4aa9-be8e-f57f5cda7883	middle name	openid-connect	oidc-usermodel-attribute-mapper	\N	c243f89b-c6d0-4fc4-9392-a4eaaacb9b3e
3e17f77a-a561-4436-b29c-5c2032407e2e	nickname	openid-connect	oidc-usermodel-attribute-mapper	\N	c243f89b-c6d0-4fc4-9392-a4eaaacb9b3e
5af1ea21-c5f3-4049-92b6-748107a765d3	username	openid-connect	oidc-usermodel-property-mapper	\N	c243f89b-c6d0-4fc4-9392-a4eaaacb9b3e
76cb4407-777e-4459-b5d4-c80c58ca86ae	profile	openid-connect	oidc-usermodel-attribute-mapper	\N	c243f89b-c6d0-4fc4-9392-a4eaaacb9b3e
8e2e7985-cab6-45ec-bd9c-f39709f1ab37	picture	openid-connect	oidc-usermodel-attribute-mapper	\N	c243f89b-c6d0-4fc4-9392-a4eaaacb9b3e
62ce2860-fee8-4d40-ba6d-cee2d75a6c02	website	openid-connect	oidc-usermodel-attribute-mapper	\N	c243f89b-c6d0-4fc4-9392-a4eaaacb9b3e
f30e65d4-a5f7-43ea-a105-92371c0f6e56	gender	openid-connect	oidc-usermodel-attribute-mapper	\N	c243f89b-c6d0-4fc4-9392-a4eaaacb9b3e
d818ba99-4b13-441f-af04-00e52674b0ef	birthdate	openid-connect	oidc-usermodel-attribute-mapper	\N	c243f89b-c6d0-4fc4-9392-a4eaaacb9b3e
bb2acbd4-2e4f-4b81-8383-63a8ef9eae7f	zoneinfo	openid-connect	oidc-usermodel-attribute-mapper	\N	c243f89b-c6d0-4fc4-9392-a4eaaacb9b3e
13d98285-19d9-4d41-add6-3c2dafe289a2	locale	openid-connect	oidc-usermodel-attribute-mapper	\N	c243f89b-c6d0-4fc4-9392-a4eaaacb9b3e
173fd1ae-e4bb-48ec-9bf5-093512c79efc	updated at	openid-connect	oidc-usermodel-attribute-mapper	\N	c243f89b-c6d0-4fc4-9392-a4eaaacb9b3e
4cda177e-20a9-4842-a3c7-5125e32b4ba5	email	openid-connect	oidc-usermodel-property-mapper	\N	373bdcaf-2669-4cd5-b2b0-cfaee6acba99
4973e9dd-0d23-4da6-8b12-0227a79c0cfc	email verified	openid-connect	oidc-usermodel-property-mapper	\N	373bdcaf-2669-4cd5-b2b0-cfaee6acba99
5e0bc1f5-400c-4268-9ad2-d6a45cd69338	address	openid-connect	oidc-address-mapper	\N	a62152f2-4d17-48f6-bd80-0ec85f4be131
7020d0e8-e644-4458-9cd6-371c42ff9471	phone number	openid-connect	oidc-usermodel-attribute-mapper	\N	f6fbfb19-4a16-4178-89d0-2e7e8579c022
891b87c0-2813-4f48-8515-9d16dfab0dd1	phone number verified	openid-connect	oidc-usermodel-attribute-mapper	\N	f6fbfb19-4a16-4178-89d0-2e7e8579c022
d6ceb752-b902-4faf-80b8-d3bb96aafd99	realm roles	openid-connect	oidc-usermodel-realm-role-mapper	\N	baea9655-0cce-403a-af40-14c343d7b97d
aef759b9-8a8e-48ac-a928-701fec0cf04b	client roles	openid-connect	oidc-usermodel-client-role-mapper	\N	baea9655-0cce-403a-af40-14c343d7b97d
d819104d-41d7-4522-ae59-f23edbc2256b	audience resolve	openid-connect	oidc-audience-resolve-mapper	\N	baea9655-0cce-403a-af40-14c343d7b97d
a353b893-095b-435b-881f-f23f9b5d2a1e	allowed web origins	openid-connect	oidc-allowed-origins-mapper	\N	86007ce1-cb1c-4a3b-aed9-5030a7e42acc
f815c8ec-53fb-4082-8f8c-a7a9ff9e1767	upn	openid-connect	oidc-usermodel-property-mapper	\N	f25eafa6-89a3-4734-9ca7-11329dc181d3
399922b9-8166-4720-9476-511f2cf1cff6	groups	openid-connect	oidc-usermodel-realm-role-mapper	\N	f25eafa6-89a3-4734-9ca7-11329dc181d3
dea00c25-78a2-4481-a1b3-77e67f407704	audience resolve	openid-connect	oidc-audience-resolve-mapper	b864547a-1317-4451-958b-b56a7fef9265	\N
91e046e8-a451-4c61-8261-370dba67ea21	role list	saml	saml-role-list-mapper	\N	6ab21a08-f270-4c47-baec-9ecaa075a492
a19939ec-f573-498b-95e0-e0a6ea30b113	full name	openid-connect	oidc-full-name-mapper	\N	edc90a1e-e346-4d1f-8cb7-8a2ecfbb3189
f2d7b315-d92c-414a-896e-a4eacbbee014	family name	openid-connect	oidc-usermodel-property-mapper	\N	edc90a1e-e346-4d1f-8cb7-8a2ecfbb3189
9e1e895a-d9e5-4aaa-8b84-842d7fc760f5	given name	openid-connect	oidc-usermodel-property-mapper	\N	edc90a1e-e346-4d1f-8cb7-8a2ecfbb3189
5ebc39a8-962b-40ad-b823-be569c692413	middle name	openid-connect	oidc-usermodel-attribute-mapper	\N	edc90a1e-e346-4d1f-8cb7-8a2ecfbb3189
84d79618-5a46-4490-af7a-4031cfb251f0	nickname	openid-connect	oidc-usermodel-attribute-mapper	\N	edc90a1e-e346-4d1f-8cb7-8a2ecfbb3189
29788ced-f9d2-4668-9649-59eaac1997fd	username	openid-connect	oidc-usermodel-property-mapper	\N	edc90a1e-e346-4d1f-8cb7-8a2ecfbb3189
70db6130-e1ed-49d3-aed9-35a2b0055984	profile	openid-connect	oidc-usermodel-attribute-mapper	\N	edc90a1e-e346-4d1f-8cb7-8a2ecfbb3189
b4aeef57-a0ec-4c6f-a4a0-1c3bd0c2f9ea	picture	openid-connect	oidc-usermodel-attribute-mapper	\N	edc90a1e-e346-4d1f-8cb7-8a2ecfbb3189
86834197-2e93-4873-8091-b8cda48412f2	website	openid-connect	oidc-usermodel-attribute-mapper	\N	edc90a1e-e346-4d1f-8cb7-8a2ecfbb3189
fd4d290c-89f6-4c45-80cb-14f479f25df2	gender	openid-connect	oidc-usermodel-attribute-mapper	\N	edc90a1e-e346-4d1f-8cb7-8a2ecfbb3189
d359663e-c376-4215-918e-fe67ccd12327	birthdate	openid-connect	oidc-usermodel-attribute-mapper	\N	edc90a1e-e346-4d1f-8cb7-8a2ecfbb3189
54003e4d-6b25-4a48-85ac-a03fa6b28ffc	zoneinfo	openid-connect	oidc-usermodel-attribute-mapper	\N	edc90a1e-e346-4d1f-8cb7-8a2ecfbb3189
163bce62-100c-4580-9360-45dabd0f8972	locale	openid-connect	oidc-usermodel-attribute-mapper	\N	edc90a1e-e346-4d1f-8cb7-8a2ecfbb3189
6ffa72de-02c4-4c6a-8911-020a8a213858	updated at	openid-connect	oidc-usermodel-attribute-mapper	\N	edc90a1e-e346-4d1f-8cb7-8a2ecfbb3189
fd9a5684-83b5-4760-96b1-5af3e12439c6	email	openid-connect	oidc-usermodel-property-mapper	\N	1e90b592-874e-44de-86a2-fc0f6b070e42
8114944d-bfcb-4541-942c-a1bf94457be2	email verified	openid-connect	oidc-usermodel-property-mapper	\N	1e90b592-874e-44de-86a2-fc0f6b070e42
7f393caf-7307-4042-998d-358dc85317f8	address	openid-connect	oidc-address-mapper	\N	bedb72d4-f331-4238-9db7-33295a37136c
80b01174-4bb2-4b31-b08d-3320d1620784	phone number	openid-connect	oidc-usermodel-attribute-mapper	\N	f5922278-676a-4e9f-bde4-7a1f9d98aeaf
8d6554a9-14e1-4d30-8ec6-2513bf579cdf	phone number verified	openid-connect	oidc-usermodel-attribute-mapper	\N	f5922278-676a-4e9f-bde4-7a1f9d98aeaf
886788b2-c26c-4ddb-903d-6b3a817a5751	realm roles	openid-connect	oidc-usermodel-realm-role-mapper	\N	9f5243a8-bf2e-4f55-bef5-53d9bc0e4752
f8b7c11d-4ca7-445d-9318-b30196181baa	client roles	openid-connect	oidc-usermodel-client-role-mapper	\N	9f5243a8-bf2e-4f55-bef5-53d9bc0e4752
d1265390-2e17-466a-92f9-22f6561674a1	audience resolve	openid-connect	oidc-audience-resolve-mapper	\N	9f5243a8-bf2e-4f55-bef5-53d9bc0e4752
01e820fe-4f07-422b-bf81-79e032b7bf5e	allowed web origins	openid-connect	oidc-allowed-origins-mapper	\N	f124c487-b123-41d2-9b56-380cf6d7f42b
fbb80bac-a350-43ff-9a3c-5a64d7b853ae	upn	openid-connect	oidc-usermodel-property-mapper	\N	1430b17c-e711-4114-8f9c-900cfda97dd5
bd739202-0bd7-4267-8812-d92055ac784c	groups	openid-connect	oidc-usermodel-realm-role-mapper	\N	1430b17c-e711-4114-8f9c-900cfda97dd5
4e758617-526e-4632-81b1-067c7a4f228e	locale	openid-connect	oidc-usermodel-attribute-mapper	6e12da5c-e596-4d59-a3af-c52dfc906e1d	\N
\.


--
-- Data for Name: protocol_mapper_config; Type: TABLE DATA; Schema: public; Owner: keycloak
--

COPY public.protocol_mapper_config (protocol_mapper_id, value, name) FROM stdin;
14f537d2-f81f-4975-90f8-a3958a1dbd36	true	userinfo.token.claim
14f537d2-f81f-4975-90f8-a3958a1dbd36	locale	user.attribute
14f537d2-f81f-4975-90f8-a3958a1dbd36	true	id.token.claim
14f537d2-f81f-4975-90f8-a3958a1dbd36	true	access.token.claim
14f537d2-f81f-4975-90f8-a3958a1dbd36	locale	claim.name
14f537d2-f81f-4975-90f8-a3958a1dbd36	String	jsonType.label
7cf33591-73f8-40ab-b190-095f2d16d58f	false	single
7cf33591-73f8-40ab-b190-095f2d16d58f	Basic	attribute.nameformat
7cf33591-73f8-40ab-b190-095f2d16d58f	Role	attribute.name
81e72056-dc80-468a-af2b-bf36231411b1	true	userinfo.token.claim
81e72056-dc80-468a-af2b-bf36231411b1	true	id.token.claim
81e72056-dc80-468a-af2b-bf36231411b1	true	access.token.claim
e21ef430-2bab-4b9e-b08c-5ec7b1c93e2c	true	userinfo.token.claim
e21ef430-2bab-4b9e-b08c-5ec7b1c93e2c	lastName	user.attribute
e21ef430-2bab-4b9e-b08c-5ec7b1c93e2c	true	id.token.claim
e21ef430-2bab-4b9e-b08c-5ec7b1c93e2c	true	access.token.claim
e21ef430-2bab-4b9e-b08c-5ec7b1c93e2c	family_name	claim.name
e21ef430-2bab-4b9e-b08c-5ec7b1c93e2c	String	jsonType.label
dfbae996-94bb-40e0-919a-c85183f3e9f2	true	userinfo.token.claim
dfbae996-94bb-40e0-919a-c85183f3e9f2	firstName	user.attribute
dfbae996-94bb-40e0-919a-c85183f3e9f2	true	id.token.claim
dfbae996-94bb-40e0-919a-c85183f3e9f2	true	access.token.claim
dfbae996-94bb-40e0-919a-c85183f3e9f2	given_name	claim.name
dfbae996-94bb-40e0-919a-c85183f3e9f2	String	jsonType.label
4363ede4-0d61-4aa9-be8e-f57f5cda7883	true	userinfo.token.claim
4363ede4-0d61-4aa9-be8e-f57f5cda7883	middleName	user.attribute
4363ede4-0d61-4aa9-be8e-f57f5cda7883	true	id.token.claim
4363ede4-0d61-4aa9-be8e-f57f5cda7883	true	access.token.claim
4363ede4-0d61-4aa9-be8e-f57f5cda7883	middle_name	claim.name
4363ede4-0d61-4aa9-be8e-f57f5cda7883	String	jsonType.label
3e17f77a-a561-4436-b29c-5c2032407e2e	true	userinfo.token.claim
3e17f77a-a561-4436-b29c-5c2032407e2e	nickname	user.attribute
3e17f77a-a561-4436-b29c-5c2032407e2e	true	id.token.claim
3e17f77a-a561-4436-b29c-5c2032407e2e	true	access.token.claim
3e17f77a-a561-4436-b29c-5c2032407e2e	nickname	claim.name
3e17f77a-a561-4436-b29c-5c2032407e2e	String	jsonType.label
5af1ea21-c5f3-4049-92b6-748107a765d3	true	userinfo.token.claim
5af1ea21-c5f3-4049-92b6-748107a765d3	username	user.attribute
5af1ea21-c5f3-4049-92b6-748107a765d3	true	id.token.claim
5af1ea21-c5f3-4049-92b6-748107a765d3	true	access.token.claim
5af1ea21-c5f3-4049-92b6-748107a765d3	preferred_username	claim.name
5af1ea21-c5f3-4049-92b6-748107a765d3	String	jsonType.label
76cb4407-777e-4459-b5d4-c80c58ca86ae	true	userinfo.token.claim
76cb4407-777e-4459-b5d4-c80c58ca86ae	profile	user.attribute
76cb4407-777e-4459-b5d4-c80c58ca86ae	true	id.token.claim
76cb4407-777e-4459-b5d4-c80c58ca86ae	true	access.token.claim
76cb4407-777e-4459-b5d4-c80c58ca86ae	profile	claim.name
76cb4407-777e-4459-b5d4-c80c58ca86ae	String	jsonType.label
8e2e7985-cab6-45ec-bd9c-f39709f1ab37	true	userinfo.token.claim
8e2e7985-cab6-45ec-bd9c-f39709f1ab37	picture	user.attribute
8e2e7985-cab6-45ec-bd9c-f39709f1ab37	true	id.token.claim
8e2e7985-cab6-45ec-bd9c-f39709f1ab37	true	access.token.claim
8e2e7985-cab6-45ec-bd9c-f39709f1ab37	picture	claim.name
8e2e7985-cab6-45ec-bd9c-f39709f1ab37	String	jsonType.label
62ce2860-fee8-4d40-ba6d-cee2d75a6c02	true	userinfo.token.claim
62ce2860-fee8-4d40-ba6d-cee2d75a6c02	website	user.attribute
62ce2860-fee8-4d40-ba6d-cee2d75a6c02	true	id.token.claim
62ce2860-fee8-4d40-ba6d-cee2d75a6c02	true	access.token.claim
62ce2860-fee8-4d40-ba6d-cee2d75a6c02	website	claim.name
62ce2860-fee8-4d40-ba6d-cee2d75a6c02	String	jsonType.label
f30e65d4-a5f7-43ea-a105-92371c0f6e56	true	userinfo.token.claim
f30e65d4-a5f7-43ea-a105-92371c0f6e56	gender	user.attribute
f30e65d4-a5f7-43ea-a105-92371c0f6e56	true	id.token.claim
f30e65d4-a5f7-43ea-a105-92371c0f6e56	true	access.token.claim
f30e65d4-a5f7-43ea-a105-92371c0f6e56	gender	claim.name
f30e65d4-a5f7-43ea-a105-92371c0f6e56	String	jsonType.label
d818ba99-4b13-441f-af04-00e52674b0ef	true	userinfo.token.claim
d818ba99-4b13-441f-af04-00e52674b0ef	birthdate	user.attribute
d818ba99-4b13-441f-af04-00e52674b0ef	true	id.token.claim
d818ba99-4b13-441f-af04-00e52674b0ef	true	access.token.claim
d818ba99-4b13-441f-af04-00e52674b0ef	birthdate	claim.name
d818ba99-4b13-441f-af04-00e52674b0ef	String	jsonType.label
bb2acbd4-2e4f-4b81-8383-63a8ef9eae7f	true	userinfo.token.claim
bb2acbd4-2e4f-4b81-8383-63a8ef9eae7f	zoneinfo	user.attribute
bb2acbd4-2e4f-4b81-8383-63a8ef9eae7f	true	id.token.claim
bb2acbd4-2e4f-4b81-8383-63a8ef9eae7f	true	access.token.claim
bb2acbd4-2e4f-4b81-8383-63a8ef9eae7f	zoneinfo	claim.name
bb2acbd4-2e4f-4b81-8383-63a8ef9eae7f	String	jsonType.label
13d98285-19d9-4d41-add6-3c2dafe289a2	true	userinfo.token.claim
13d98285-19d9-4d41-add6-3c2dafe289a2	locale	user.attribute
13d98285-19d9-4d41-add6-3c2dafe289a2	true	id.token.claim
13d98285-19d9-4d41-add6-3c2dafe289a2	true	access.token.claim
13d98285-19d9-4d41-add6-3c2dafe289a2	locale	claim.name
13d98285-19d9-4d41-add6-3c2dafe289a2	String	jsonType.label
173fd1ae-e4bb-48ec-9bf5-093512c79efc	true	userinfo.token.claim
173fd1ae-e4bb-48ec-9bf5-093512c79efc	updatedAt	user.attribute
173fd1ae-e4bb-48ec-9bf5-093512c79efc	true	id.token.claim
173fd1ae-e4bb-48ec-9bf5-093512c79efc	true	access.token.claim
173fd1ae-e4bb-48ec-9bf5-093512c79efc	updated_at	claim.name
173fd1ae-e4bb-48ec-9bf5-093512c79efc	String	jsonType.label
4cda177e-20a9-4842-a3c7-5125e32b4ba5	true	userinfo.token.claim
4cda177e-20a9-4842-a3c7-5125e32b4ba5	email	user.attribute
4cda177e-20a9-4842-a3c7-5125e32b4ba5	true	id.token.claim
4cda177e-20a9-4842-a3c7-5125e32b4ba5	true	access.token.claim
4cda177e-20a9-4842-a3c7-5125e32b4ba5	email	claim.name
4cda177e-20a9-4842-a3c7-5125e32b4ba5	String	jsonType.label
4973e9dd-0d23-4da6-8b12-0227a79c0cfc	true	userinfo.token.claim
4973e9dd-0d23-4da6-8b12-0227a79c0cfc	emailVerified	user.attribute
4973e9dd-0d23-4da6-8b12-0227a79c0cfc	true	id.token.claim
4973e9dd-0d23-4da6-8b12-0227a79c0cfc	true	access.token.claim
4973e9dd-0d23-4da6-8b12-0227a79c0cfc	email_verified	claim.name
4973e9dd-0d23-4da6-8b12-0227a79c0cfc	boolean	jsonType.label
5e0bc1f5-400c-4268-9ad2-d6a45cd69338	formatted	user.attribute.formatted
5e0bc1f5-400c-4268-9ad2-d6a45cd69338	country	user.attribute.country
5e0bc1f5-400c-4268-9ad2-d6a45cd69338	postal_code	user.attribute.postal_code
5e0bc1f5-400c-4268-9ad2-d6a45cd69338	true	userinfo.token.claim
5e0bc1f5-400c-4268-9ad2-d6a45cd69338	street	user.attribute.street
5e0bc1f5-400c-4268-9ad2-d6a45cd69338	true	id.token.claim
5e0bc1f5-400c-4268-9ad2-d6a45cd69338	region	user.attribute.region
5e0bc1f5-400c-4268-9ad2-d6a45cd69338	true	access.token.claim
5e0bc1f5-400c-4268-9ad2-d6a45cd69338	locality	user.attribute.locality
7020d0e8-e644-4458-9cd6-371c42ff9471	true	userinfo.token.claim
7020d0e8-e644-4458-9cd6-371c42ff9471	phoneNumber	user.attribute
7020d0e8-e644-4458-9cd6-371c42ff9471	true	id.token.claim
7020d0e8-e644-4458-9cd6-371c42ff9471	true	access.token.claim
7020d0e8-e644-4458-9cd6-371c42ff9471	phone_number	claim.name
7020d0e8-e644-4458-9cd6-371c42ff9471	String	jsonType.label
891b87c0-2813-4f48-8515-9d16dfab0dd1	true	userinfo.token.claim
891b87c0-2813-4f48-8515-9d16dfab0dd1	phoneNumberVerified	user.attribute
891b87c0-2813-4f48-8515-9d16dfab0dd1	true	id.token.claim
891b87c0-2813-4f48-8515-9d16dfab0dd1	true	access.token.claim
891b87c0-2813-4f48-8515-9d16dfab0dd1	phone_number_verified	claim.name
891b87c0-2813-4f48-8515-9d16dfab0dd1	boolean	jsonType.label
d6ceb752-b902-4faf-80b8-d3bb96aafd99	true	multivalued
d6ceb752-b902-4faf-80b8-d3bb96aafd99	foo	user.attribute
d6ceb752-b902-4faf-80b8-d3bb96aafd99	true	access.token.claim
d6ceb752-b902-4faf-80b8-d3bb96aafd99	realm_access.roles	claim.name
d6ceb752-b902-4faf-80b8-d3bb96aafd99	String	jsonType.label
aef759b9-8a8e-48ac-a928-701fec0cf04b	true	multivalued
aef759b9-8a8e-48ac-a928-701fec0cf04b	foo	user.attribute
aef759b9-8a8e-48ac-a928-701fec0cf04b	true	access.token.claim
aef759b9-8a8e-48ac-a928-701fec0cf04b	resource_access.${client_id}.roles	claim.name
aef759b9-8a8e-48ac-a928-701fec0cf04b	String	jsonType.label
f815c8ec-53fb-4082-8f8c-a7a9ff9e1767	true	userinfo.token.claim
f815c8ec-53fb-4082-8f8c-a7a9ff9e1767	username	user.attribute
f815c8ec-53fb-4082-8f8c-a7a9ff9e1767	true	id.token.claim
f815c8ec-53fb-4082-8f8c-a7a9ff9e1767	true	access.token.claim
f815c8ec-53fb-4082-8f8c-a7a9ff9e1767	upn	claim.name
f815c8ec-53fb-4082-8f8c-a7a9ff9e1767	String	jsonType.label
399922b9-8166-4720-9476-511f2cf1cff6	true	multivalued
399922b9-8166-4720-9476-511f2cf1cff6	foo	user.attribute
399922b9-8166-4720-9476-511f2cf1cff6	true	id.token.claim
399922b9-8166-4720-9476-511f2cf1cff6	true	access.token.claim
399922b9-8166-4720-9476-511f2cf1cff6	groups	claim.name
399922b9-8166-4720-9476-511f2cf1cff6	String	jsonType.label
91e046e8-a451-4c61-8261-370dba67ea21	false	single
91e046e8-a451-4c61-8261-370dba67ea21	Basic	attribute.nameformat
91e046e8-a451-4c61-8261-370dba67ea21	Role	attribute.name
a19939ec-f573-498b-95e0-e0a6ea30b113	true	userinfo.token.claim
a19939ec-f573-498b-95e0-e0a6ea30b113	true	id.token.claim
a19939ec-f573-498b-95e0-e0a6ea30b113	true	access.token.claim
f2d7b315-d92c-414a-896e-a4eacbbee014	true	userinfo.token.claim
f2d7b315-d92c-414a-896e-a4eacbbee014	lastName	user.attribute
f2d7b315-d92c-414a-896e-a4eacbbee014	true	id.token.claim
f2d7b315-d92c-414a-896e-a4eacbbee014	true	access.token.claim
f2d7b315-d92c-414a-896e-a4eacbbee014	family_name	claim.name
f2d7b315-d92c-414a-896e-a4eacbbee014	String	jsonType.label
9e1e895a-d9e5-4aaa-8b84-842d7fc760f5	true	userinfo.token.claim
9e1e895a-d9e5-4aaa-8b84-842d7fc760f5	firstName	user.attribute
9e1e895a-d9e5-4aaa-8b84-842d7fc760f5	true	id.token.claim
9e1e895a-d9e5-4aaa-8b84-842d7fc760f5	true	access.token.claim
9e1e895a-d9e5-4aaa-8b84-842d7fc760f5	given_name	claim.name
9e1e895a-d9e5-4aaa-8b84-842d7fc760f5	String	jsonType.label
5ebc39a8-962b-40ad-b823-be569c692413	true	userinfo.token.claim
5ebc39a8-962b-40ad-b823-be569c692413	middleName	user.attribute
5ebc39a8-962b-40ad-b823-be569c692413	true	id.token.claim
5ebc39a8-962b-40ad-b823-be569c692413	true	access.token.claim
5ebc39a8-962b-40ad-b823-be569c692413	middle_name	claim.name
5ebc39a8-962b-40ad-b823-be569c692413	String	jsonType.label
84d79618-5a46-4490-af7a-4031cfb251f0	true	userinfo.token.claim
84d79618-5a46-4490-af7a-4031cfb251f0	nickname	user.attribute
84d79618-5a46-4490-af7a-4031cfb251f0	true	id.token.claim
84d79618-5a46-4490-af7a-4031cfb251f0	true	access.token.claim
84d79618-5a46-4490-af7a-4031cfb251f0	nickname	claim.name
84d79618-5a46-4490-af7a-4031cfb251f0	String	jsonType.label
29788ced-f9d2-4668-9649-59eaac1997fd	true	userinfo.token.claim
29788ced-f9d2-4668-9649-59eaac1997fd	username	user.attribute
29788ced-f9d2-4668-9649-59eaac1997fd	true	id.token.claim
29788ced-f9d2-4668-9649-59eaac1997fd	true	access.token.claim
29788ced-f9d2-4668-9649-59eaac1997fd	preferred_username	claim.name
29788ced-f9d2-4668-9649-59eaac1997fd	String	jsonType.label
70db6130-e1ed-49d3-aed9-35a2b0055984	true	userinfo.token.claim
70db6130-e1ed-49d3-aed9-35a2b0055984	profile	user.attribute
70db6130-e1ed-49d3-aed9-35a2b0055984	true	id.token.claim
70db6130-e1ed-49d3-aed9-35a2b0055984	true	access.token.claim
70db6130-e1ed-49d3-aed9-35a2b0055984	profile	claim.name
70db6130-e1ed-49d3-aed9-35a2b0055984	String	jsonType.label
b4aeef57-a0ec-4c6f-a4a0-1c3bd0c2f9ea	true	userinfo.token.claim
b4aeef57-a0ec-4c6f-a4a0-1c3bd0c2f9ea	picture	user.attribute
b4aeef57-a0ec-4c6f-a4a0-1c3bd0c2f9ea	true	id.token.claim
b4aeef57-a0ec-4c6f-a4a0-1c3bd0c2f9ea	true	access.token.claim
b4aeef57-a0ec-4c6f-a4a0-1c3bd0c2f9ea	picture	claim.name
b4aeef57-a0ec-4c6f-a4a0-1c3bd0c2f9ea	String	jsonType.label
86834197-2e93-4873-8091-b8cda48412f2	true	userinfo.token.claim
86834197-2e93-4873-8091-b8cda48412f2	website	user.attribute
86834197-2e93-4873-8091-b8cda48412f2	true	id.token.claim
86834197-2e93-4873-8091-b8cda48412f2	true	access.token.claim
86834197-2e93-4873-8091-b8cda48412f2	website	claim.name
86834197-2e93-4873-8091-b8cda48412f2	String	jsonType.label
fd4d290c-89f6-4c45-80cb-14f479f25df2	true	userinfo.token.claim
fd4d290c-89f6-4c45-80cb-14f479f25df2	gender	user.attribute
fd4d290c-89f6-4c45-80cb-14f479f25df2	true	id.token.claim
fd4d290c-89f6-4c45-80cb-14f479f25df2	true	access.token.claim
fd4d290c-89f6-4c45-80cb-14f479f25df2	gender	claim.name
fd4d290c-89f6-4c45-80cb-14f479f25df2	String	jsonType.label
d359663e-c376-4215-918e-fe67ccd12327	true	userinfo.token.claim
d359663e-c376-4215-918e-fe67ccd12327	birthdate	user.attribute
d359663e-c376-4215-918e-fe67ccd12327	true	id.token.claim
d359663e-c376-4215-918e-fe67ccd12327	true	access.token.claim
d359663e-c376-4215-918e-fe67ccd12327	birthdate	claim.name
d359663e-c376-4215-918e-fe67ccd12327	String	jsonType.label
54003e4d-6b25-4a48-85ac-a03fa6b28ffc	true	userinfo.token.claim
54003e4d-6b25-4a48-85ac-a03fa6b28ffc	zoneinfo	user.attribute
54003e4d-6b25-4a48-85ac-a03fa6b28ffc	true	id.token.claim
54003e4d-6b25-4a48-85ac-a03fa6b28ffc	true	access.token.claim
54003e4d-6b25-4a48-85ac-a03fa6b28ffc	zoneinfo	claim.name
54003e4d-6b25-4a48-85ac-a03fa6b28ffc	String	jsonType.label
163bce62-100c-4580-9360-45dabd0f8972	true	userinfo.token.claim
163bce62-100c-4580-9360-45dabd0f8972	locale	user.attribute
163bce62-100c-4580-9360-45dabd0f8972	true	id.token.claim
163bce62-100c-4580-9360-45dabd0f8972	true	access.token.claim
163bce62-100c-4580-9360-45dabd0f8972	locale	claim.name
163bce62-100c-4580-9360-45dabd0f8972	String	jsonType.label
6ffa72de-02c4-4c6a-8911-020a8a213858	true	userinfo.token.claim
6ffa72de-02c4-4c6a-8911-020a8a213858	updatedAt	user.attribute
6ffa72de-02c4-4c6a-8911-020a8a213858	true	id.token.claim
6ffa72de-02c4-4c6a-8911-020a8a213858	true	access.token.claim
6ffa72de-02c4-4c6a-8911-020a8a213858	updated_at	claim.name
6ffa72de-02c4-4c6a-8911-020a8a213858	String	jsonType.label
fd9a5684-83b5-4760-96b1-5af3e12439c6	true	userinfo.token.claim
fd9a5684-83b5-4760-96b1-5af3e12439c6	email	user.attribute
fd9a5684-83b5-4760-96b1-5af3e12439c6	true	id.token.claim
fd9a5684-83b5-4760-96b1-5af3e12439c6	true	access.token.claim
fd9a5684-83b5-4760-96b1-5af3e12439c6	email	claim.name
fd9a5684-83b5-4760-96b1-5af3e12439c6	String	jsonType.label
8114944d-bfcb-4541-942c-a1bf94457be2	true	userinfo.token.claim
8114944d-bfcb-4541-942c-a1bf94457be2	emailVerified	user.attribute
8114944d-bfcb-4541-942c-a1bf94457be2	true	id.token.claim
8114944d-bfcb-4541-942c-a1bf94457be2	true	access.token.claim
8114944d-bfcb-4541-942c-a1bf94457be2	email_verified	claim.name
8114944d-bfcb-4541-942c-a1bf94457be2	boolean	jsonType.label
7f393caf-7307-4042-998d-358dc85317f8	formatted	user.attribute.formatted
7f393caf-7307-4042-998d-358dc85317f8	country	user.attribute.country
7f393caf-7307-4042-998d-358dc85317f8	postal_code	user.attribute.postal_code
7f393caf-7307-4042-998d-358dc85317f8	true	userinfo.token.claim
7f393caf-7307-4042-998d-358dc85317f8	street	user.attribute.street
7f393caf-7307-4042-998d-358dc85317f8	true	id.token.claim
7f393caf-7307-4042-998d-358dc85317f8	region	user.attribute.region
7f393caf-7307-4042-998d-358dc85317f8	true	access.token.claim
7f393caf-7307-4042-998d-358dc85317f8	locality	user.attribute.locality
80b01174-4bb2-4b31-b08d-3320d1620784	true	userinfo.token.claim
80b01174-4bb2-4b31-b08d-3320d1620784	phoneNumber	user.attribute
80b01174-4bb2-4b31-b08d-3320d1620784	true	id.token.claim
80b01174-4bb2-4b31-b08d-3320d1620784	true	access.token.claim
80b01174-4bb2-4b31-b08d-3320d1620784	phone_number	claim.name
80b01174-4bb2-4b31-b08d-3320d1620784	String	jsonType.label
8d6554a9-14e1-4d30-8ec6-2513bf579cdf	true	userinfo.token.claim
8d6554a9-14e1-4d30-8ec6-2513bf579cdf	phoneNumberVerified	user.attribute
8d6554a9-14e1-4d30-8ec6-2513bf579cdf	true	id.token.claim
8d6554a9-14e1-4d30-8ec6-2513bf579cdf	true	access.token.claim
8d6554a9-14e1-4d30-8ec6-2513bf579cdf	phone_number_verified	claim.name
8d6554a9-14e1-4d30-8ec6-2513bf579cdf	boolean	jsonType.label
886788b2-c26c-4ddb-903d-6b3a817a5751	true	multivalued
886788b2-c26c-4ddb-903d-6b3a817a5751	foo	user.attribute
886788b2-c26c-4ddb-903d-6b3a817a5751	true	access.token.claim
886788b2-c26c-4ddb-903d-6b3a817a5751	realm_access.roles	claim.name
886788b2-c26c-4ddb-903d-6b3a817a5751	String	jsonType.label
f8b7c11d-4ca7-445d-9318-b30196181baa	true	multivalued
f8b7c11d-4ca7-445d-9318-b30196181baa	foo	user.attribute
f8b7c11d-4ca7-445d-9318-b30196181baa	true	access.token.claim
f8b7c11d-4ca7-445d-9318-b30196181baa	resource_access.${client_id}.roles	claim.name
f8b7c11d-4ca7-445d-9318-b30196181baa	String	jsonType.label
fbb80bac-a350-43ff-9a3c-5a64d7b853ae	true	userinfo.token.claim
fbb80bac-a350-43ff-9a3c-5a64d7b853ae	username	user.attribute
fbb80bac-a350-43ff-9a3c-5a64d7b853ae	true	id.token.claim
fbb80bac-a350-43ff-9a3c-5a64d7b853ae	true	access.token.claim
fbb80bac-a350-43ff-9a3c-5a64d7b853ae	upn	claim.name
fbb80bac-a350-43ff-9a3c-5a64d7b853ae	String	jsonType.label
bd739202-0bd7-4267-8812-d92055ac784c	true	multivalued
bd739202-0bd7-4267-8812-d92055ac784c	foo	user.attribute
bd739202-0bd7-4267-8812-d92055ac784c	true	id.token.claim
bd739202-0bd7-4267-8812-d92055ac784c	true	access.token.claim
bd739202-0bd7-4267-8812-d92055ac784c	groups	claim.name
bd739202-0bd7-4267-8812-d92055ac784c	String	jsonType.label
4e758617-526e-4632-81b1-067c7a4f228e	true	userinfo.token.claim
4e758617-526e-4632-81b1-067c7a4f228e	locale	user.attribute
4e758617-526e-4632-81b1-067c7a4f228e	true	id.token.claim
4e758617-526e-4632-81b1-067c7a4f228e	true	access.token.claim
4e758617-526e-4632-81b1-067c7a4f228e	locale	claim.name
4e758617-526e-4632-81b1-067c7a4f228e	String	jsonType.label
\.


--
-- Data for Name: realm; Type: TABLE DATA; Schema: public; Owner: keycloak
--

COPY public.realm (id, access_code_lifespan, user_action_lifespan, access_token_lifespan, account_theme, admin_theme, email_theme, enabled, events_enabled, events_expiration, login_theme, name, not_before, password_policy, registration_allowed, remember_me, reset_password_allowed, social, ssl_required, sso_idle_timeout, sso_max_lifespan, update_profile_on_soc_login, verify_email, master_admin_client, login_lifespan, internationalization_enabled, default_locale, reg_email_as_username, admin_events_enabled, admin_events_details_enabled, edit_username_allowed, otp_policy_counter, otp_policy_window, otp_policy_period, otp_policy_digits, otp_policy_alg, otp_policy_type, browser_flow, registration_flow, direct_grant_flow, reset_credentials_flow, client_auth_flow, offline_session_idle_timeout, revoke_refresh_token, access_token_life_implicit, login_with_email_allowed, duplicate_emails_allowed, docker_auth_flow, refresh_token_max_reuse, allow_user_managed_access, sso_max_lifespan_remember_me, sso_idle_timeout_remember_me, default_role) FROM stdin;
master	60	300	60	\N	\N	\N	t	f	0	\N	master	0	\N	f	f	f	f	EXTERNAL	1800	36000	f	f	3f8f0ad2-a399-4b08-969d-cff26f73eb7d	1800	f	\N	f	f	f	f	0	1	30	6	HmacSHA1	totp	b4f74719-5181-4e61-9844-d5257d6493f4	6421bcdb-674f-453a-8d07-d4badef008e7	a25459eb-a7a4-4f50-9147-1c6c6edc07a5	7bb7ec8a-43a8-4046-afed-d28e9fd64c88	a87d8849-4b61-43c7-a67a-8f85f415fe6e	2592000	f	900	t	f	60e4eac4-9aae-4729-9453-f81ca44fa4b6	0	f	0	0	6db63c36-52fd-4a03-88ca-6dfa9538386f
fiware_service	60	300	300	\N	\N	\N	t	f	0	\N	fiware_service	0	\N	f	f	f	f	EXTERNAL	1800	36000	f	f	ccedade4-74d9-4315-9131-8c4f6a9b966f	1800	f	\N	f	f	f	f	0	1	30	6	HmacSHA1	totp	46601f6a-192b-4f2f-8012-dcba10eca461	a12a5b0d-1a80-4ea7-92a4-335dabcb58e9	013fc056-3ba8-4a33-8b3d-c058d3feb3d3	0e0113b9-d907-4896-8bee-468b80af852c	f1966204-8255-4984-9bd1-9152736eb81e	2592000	f	900	t	f	6b1890c5-4fab-4408-988f-f1566d9b8c6d	0	f	0	0	f158f973-07e3-49d6-9d78-4b4c4c12d04b
\.


--
-- Data for Name: realm_attribute; Type: TABLE DATA; Schema: public; Owner: keycloak
--

COPY public.realm_attribute (name, realm_id, value) FROM stdin;
_browser_header.contentSecurityPolicyReportOnly	master	
_browser_header.xContentTypeOptions	master	nosniff
_browser_header.xRobotsTag	master	none
_browser_header.xFrameOptions	master	SAMEORIGIN
_browser_header.contentSecurityPolicy	master	frame-src 'self'; frame-ancestors 'self'; object-src 'none';
_browser_header.xXSSProtection	master	1; mode=block
_browser_header.strictTransportSecurity	master	max-age=31536000; includeSubDomains
bruteForceProtected	master	false
permanentLockout	master	false
maxFailureWaitSeconds	master	900
minimumQuickLoginWaitSeconds	master	60
waitIncrementSeconds	master	60
quickLoginCheckMilliSeconds	master	1000
maxDeltaTimeSeconds	master	43200
failureFactor	master	30
displayName	master	Keycloak
displayNameHtml	master	<div class="kc-logo-text"><span>Keycloak</span></div>
defaultSignatureAlgorithm	master	RS256
offlineSessionMaxLifespanEnabled	master	false
offlineSessionMaxLifespan	master	5184000
_browser_header.contentSecurityPolicyReportOnly	fiware_service	
_browser_header.xContentTypeOptions	fiware_service	nosniff
_browser_header.xRobotsTag	fiware_service	none
_browser_header.xFrameOptions	fiware_service	SAMEORIGIN
_browser_header.contentSecurityPolicy	fiware_service	frame-src 'self'; frame-ancestors 'self'; object-src 'none';
_browser_header.xXSSProtection	fiware_service	1; mode=block
_browser_header.strictTransportSecurity	fiware_service	max-age=31536000; includeSubDomains
bruteForceProtected	fiware_service	false
permanentLockout	fiware_service	false
maxFailureWaitSeconds	fiware_service	900
minimumQuickLoginWaitSeconds	fiware_service	60
waitIncrementSeconds	fiware_service	60
quickLoginCheckMilliSeconds	fiware_service	1000
maxDeltaTimeSeconds	fiware_service	43200
failureFactor	fiware_service	30
defaultSignatureAlgorithm	fiware_service	RS256
offlineSessionMaxLifespanEnabled	fiware_service	false
offlineSessionMaxLifespan	fiware_service	5184000
actionTokenGeneratedByAdminLifespan	fiware_service	43200
actionTokenGeneratedByUserLifespan	fiware_service	300
oauth2DeviceCodeLifespan	fiware_service	600
oauth2DevicePollingInterval	fiware_service	5
webAuthnPolicyRpEntityName	fiware_service	keycloak
webAuthnPolicySignatureAlgorithms	fiware_service	ES256
webAuthnPolicyRpId	fiware_service	
webAuthnPolicyAttestationConveyancePreference	fiware_service	not specified
webAuthnPolicyAuthenticatorAttachment	fiware_service	not specified
webAuthnPolicyRequireResidentKey	fiware_service	not specified
webAuthnPolicyUserVerificationRequirement	fiware_service	not specified
webAuthnPolicyCreateTimeout	fiware_service	0
webAuthnPolicyAvoidSameAuthenticatorRegister	fiware_service	false
webAuthnPolicyRpEntityNamePasswordless	fiware_service	keycloak
webAuthnPolicySignatureAlgorithmsPasswordless	fiware_service	ES256
webAuthnPolicyRpIdPasswordless	fiware_service	
webAuthnPolicyAttestationConveyancePreferencePasswordless	fiware_service	not specified
webAuthnPolicyAuthenticatorAttachmentPasswordless	fiware_service	not specified
webAuthnPolicyRequireResidentKeyPasswordless	fiware_service	not specified
webAuthnPolicyUserVerificationRequirementPasswordless	fiware_service	not specified
webAuthnPolicyCreateTimeoutPasswordless	fiware_service	0
webAuthnPolicyAvoidSameAuthenticatorRegisterPasswordless	fiware_service	false
cibaBackchannelTokenDeliveryMode	fiware_service	poll
cibaExpiresIn	fiware_service	120
cibaInterval	fiware_service	5
cibaAuthRequestedUserHint	fiware_service	login_hint
\.


--
-- Data for Name: realm_default_groups; Type: TABLE DATA; Schema: public; Owner: keycloak
--

COPY public.realm_default_groups (realm_id, group_id) FROM stdin;
\.


--
-- Data for Name: realm_enabled_event_types; Type: TABLE DATA; Schema: public; Owner: keycloak
--

COPY public.realm_enabled_event_types (realm_id, value) FROM stdin;
\.


--
-- Data for Name: realm_events_listeners; Type: TABLE DATA; Schema: public; Owner: keycloak
--

COPY public.realm_events_listeners (realm_id, value) FROM stdin;
master	jboss-logging
fiware_service	jboss-logging
\.


--
-- Data for Name: realm_localizations; Type: TABLE DATA; Schema: public; Owner: keycloak
--

COPY public.realm_localizations (realm_id, locale, texts) FROM stdin;
\.


--
-- Data for Name: realm_required_credential; Type: TABLE DATA; Schema: public; Owner: keycloak
--

COPY public.realm_required_credential (type, form_label, input, secret, realm_id) FROM stdin;
password	password	t	t	master
password	password	t	t	fiware_service
\.


--
-- Data for Name: realm_smtp_config; Type: TABLE DATA; Schema: public; Owner: keycloak
--

COPY public.realm_smtp_config (realm_id, value, name) FROM stdin;
\.


--
-- Data for Name: realm_supported_locales; Type: TABLE DATA; Schema: public; Owner: keycloak
--

COPY public.realm_supported_locales (realm_id, value) FROM stdin;
\.


--
-- Data for Name: redirect_uris; Type: TABLE DATA; Schema: public; Owner: keycloak
--

COPY public.redirect_uris (client_id, value) FROM stdin;
e3222dd4-baa4-4f42-9042-e0190fb22ef8	/realms/master/account/*
3ac10acb-7ef8-4489-9077-16a81264dd18	/realms/master/account/*
eaa78be2-e4bb-47af-8f6b-5aa43b433ab5	/admin/master/console/*
ae0a3deb-9d51-45a1-9fde-ac887ac98178	/realms/fiware_service/account/*
b864547a-1317-4451-958b-b56a7fef9265	/realms/fiware_service/account/*
6e12da5c-e596-4d59-a3af-c52dfc906e1d	/admin/fiware_service/console/*
\.


--
-- Data for Name: required_action_config; Type: TABLE DATA; Schema: public; Owner: keycloak
--

COPY public.required_action_config (required_action_id, value, name) FROM stdin;
\.


--
-- Data for Name: required_action_provider; Type: TABLE DATA; Schema: public; Owner: keycloak
--

COPY public.required_action_provider (id, alias, name, realm_id, enabled, default_action, provider_id, priority) FROM stdin;
f986f746-90a1-469e-9ed2-d5603ed74d8e	VERIFY_EMAIL	Verify Email	master	t	f	VERIFY_EMAIL	50
9ed174f1-350a-4be2-8f6b-ae26ba209cce	UPDATE_PROFILE	Update Profile	master	t	f	UPDATE_PROFILE	40
16d7e7f8-63a5-44c2-ac34-0412bbcf0e1d	CONFIGURE_TOTP	Configure OTP	master	t	f	CONFIGURE_TOTP	10
c10f83da-5945-4056-9a8e-b344a6ae9015	UPDATE_PASSWORD	Update Password	master	t	f	UPDATE_PASSWORD	30
32865ea7-7fc2-49c2-985e-f35ab31f6c3c	terms_and_conditions	Terms and Conditions	master	f	f	terms_and_conditions	20
7c5eab14-1f6c-41dc-a622-1a99cfd041cb	update_user_locale	Update User Locale	master	t	f	update_user_locale	1000
074d6bd6-7ea1-47ab-a4bd-5f433e54f82a	delete_account	Delete Account	master	f	f	delete_account	60
7c795f47-c1a3-44fe-b82c-7a17e8066cab	VERIFY_EMAIL	Verify Email	fiware_service	t	f	VERIFY_EMAIL	50
798bb06f-d727-4272-97be-c9c2a9c90729	UPDATE_PROFILE	Update Profile	fiware_service	t	f	UPDATE_PROFILE	40
273ebff8-c33d-4b47-a929-e2a133950621	CONFIGURE_TOTP	Configure OTP	fiware_service	t	f	CONFIGURE_TOTP	10
f0ce190e-f10f-4ab8-913a-ba01f1e4224a	UPDATE_PASSWORD	Update Password	fiware_service	t	f	UPDATE_PASSWORD	30
0403fe7e-541e-493c-8196-fb67bf055442	terms_and_conditions	Terms and Conditions	fiware_service	f	f	terms_and_conditions	20
08c6b9ef-96e3-40b4-9bdd-15622083a84b	update_user_locale	Update User Locale	fiware_service	t	f	update_user_locale	1000
606d0ef5-5508-4e9e-8645-b1767469ee32	delete_account	Delete Account	fiware_service	f	f	delete_account	60
\.


--
-- Data for Name: resource_attribute; Type: TABLE DATA; Schema: public; Owner: keycloak
--

COPY public.resource_attribute (id, name, value, resource_id) FROM stdin;
\.


--
-- Data for Name: resource_policy; Type: TABLE DATA; Schema: public; Owner: keycloak
--

COPY public.resource_policy (resource_id, policy_id) FROM stdin;
\.


--
-- Data for Name: resource_scope; Type: TABLE DATA; Schema: public; Owner: keycloak
--

COPY public.resource_scope (resource_id, scope_id) FROM stdin;
\.


--
-- Data for Name: resource_server; Type: TABLE DATA; Schema: public; Owner: keycloak
--

COPY public.resource_server (id, allow_rs_remote_mgmt, policy_enforce_mode, decision_strategy) FROM stdin;
\.


--
-- Data for Name: resource_server_perm_ticket; Type: TABLE DATA; Schema: public; Owner: keycloak
--

COPY public.resource_server_perm_ticket (id, owner, requester, created_timestamp, granted_timestamp, resource_id, scope_id, resource_server_id, policy_id) FROM stdin;
\.


--
-- Data for Name: resource_server_policy; Type: TABLE DATA; Schema: public; Owner: keycloak
--

COPY public.resource_server_policy (id, name, description, type, decision_strategy, logic, resource_server_id, owner) FROM stdin;
\.


--
-- Data for Name: resource_server_resource; Type: TABLE DATA; Schema: public; Owner: keycloak
--

COPY public.resource_server_resource (id, name, type, icon_uri, owner, resource_server_id, owner_managed_access, display_name) FROM stdin;
\.


--
-- Data for Name: resource_server_scope; Type: TABLE DATA; Schema: public; Owner: keycloak
--

COPY public.resource_server_scope (id, name, icon_uri, resource_server_id, display_name) FROM stdin;
\.


--
-- Data for Name: resource_uris; Type: TABLE DATA; Schema: public; Owner: keycloak
--

COPY public.resource_uris (resource_id, value) FROM stdin;
\.


--
-- Data for Name: role_attribute; Type: TABLE DATA; Schema: public; Owner: keycloak
--

COPY public.role_attribute (id, role_id, name, value) FROM stdin;
\.


--
-- Data for Name: scope_mapping; Type: TABLE DATA; Schema: public; Owner: keycloak
--

COPY public.scope_mapping (client_id, role_id) FROM stdin;
3ac10acb-7ef8-4489-9077-16a81264dd18	f448399b-6e3b-415d-88a4-817fc76b1bc5
b864547a-1317-4451-958b-b56a7fef9265	fa8ede85-4362-4d1b-a84e-9ad7c666a558
\.


--
-- Data for Name: scope_policy; Type: TABLE DATA; Schema: public; Owner: keycloak
--

COPY public.scope_policy (scope_id, policy_id) FROM stdin;
\.


--
-- Data for Name: user_attribute; Type: TABLE DATA; Schema: public; Owner: keycloak
--

COPY public.user_attribute (name, value, user_id, id) FROM stdin;
\.


--
-- Data for Name: user_consent; Type: TABLE DATA; Schema: public; Owner: keycloak
--

COPY public.user_consent (id, client_id, user_id, created_date, last_updated_date, client_storage_provider, external_client_id) FROM stdin;
\.


--
-- Data for Name: user_consent_client_scope; Type: TABLE DATA; Schema: public; Owner: keycloak
--

COPY public.user_consent_client_scope (user_consent_id, scope_id) FROM stdin;
\.


--
-- Data for Name: user_entity; Type: TABLE DATA; Schema: public; Owner: keycloak
--

COPY public.user_entity (id, email, email_constraint, email_verified, enabled, federation_link, first_name, last_name, realm_id, username, created_timestamp, service_account_client_link, not_before) FROM stdin;
6229de20-bfed-49ed-8f3f-41bd0b5a6565	\N	e52c56e0-bfc3-4bea-9541-16fcffde2e34	f	t	\N	\N	\N	master	admin	1625909300911	\N	0
a4883bb9-630f-40b9-867b-bfbe3d78e963	\N	86c6c671-d442-4ca5-a42c-403982d5de3c	f	t	\N	\N	\N	fiware_service	fiware	1625909462561	\N	0
\.


--
-- Data for Name: user_federation_config; Type: TABLE DATA; Schema: public; Owner: keycloak
--

COPY public.user_federation_config (user_federation_provider_id, value, name) FROM stdin;
\.


--
-- Data for Name: user_federation_mapper; Type: TABLE DATA; Schema: public; Owner: keycloak
--

COPY public.user_federation_mapper (id, name, federation_provider_id, federation_mapper_type, realm_id) FROM stdin;
\.


--
-- Data for Name: user_federation_mapper_config; Type: TABLE DATA; Schema: public; Owner: keycloak
--

COPY public.user_federation_mapper_config (user_federation_mapper_id, value, name) FROM stdin;
\.


--
-- Data for Name: user_federation_provider; Type: TABLE DATA; Schema: public; Owner: keycloak
--

COPY public.user_federation_provider (id, changed_sync_period, display_name, full_sync_period, last_sync, priority, provider_name, realm_id) FROM stdin;
\.


--
-- Data for Name: user_group_membership; Type: TABLE DATA; Schema: public; Owner: keycloak
--

COPY public.user_group_membership (group_id, user_id) FROM stdin;
\.


--
-- Data for Name: user_required_action; Type: TABLE DATA; Schema: public; Owner: keycloak
--

COPY public.user_required_action (user_id, required_action) FROM stdin;
\.


--
-- Data for Name: user_role_mapping; Type: TABLE DATA; Schema: public; Owner: keycloak
--

COPY public.user_role_mapping (role_id, user_id) FROM stdin;
6db63c36-52fd-4a03-88ca-6dfa9538386f	6229de20-bfed-49ed-8f3f-41bd0b5a6565
ef0cd6e4-9f1d-46f9-afc7-13ac35305d2a	6229de20-bfed-49ed-8f3f-41bd0b5a6565
f158f973-07e3-49d6-9d78-4b4c4c12d04b	a4883bb9-630f-40b9-867b-bfbe3d78e963
\.


--
-- Data for Name: user_session; Type: TABLE DATA; Schema: public; Owner: keycloak
--

COPY public.user_session (id, auth_method, ip_address, last_session_refresh, login_username, realm_id, remember_me, started, user_id, user_session_state, broker_session_id, broker_user_id) FROM stdin;
\.


--
-- Data for Name: user_session_note; Type: TABLE DATA; Schema: public; Owner: keycloak
--

COPY public.user_session_note (user_session, name, value) FROM stdin;
\.


--
-- Data for Name: username_login_failure; Type: TABLE DATA; Schema: public; Owner: keycloak
--

COPY public.username_login_failure (realm_id, username, failed_login_not_before, last_failure, last_ip_failure, num_failures) FROM stdin;
\.


--
-- Data for Name: web_origins; Type: TABLE DATA; Schema: public; Owner: keycloak
--

COPY public.web_origins (client_id, value) FROM stdin;
eaa78be2-e4bb-47af-8f6b-5aa43b433ab5	+
6e12da5c-e596-4d59-a3af-c52dfc906e1d	+
\.


--
-- Name: username_login_failure CONSTRAINT_17-2; Type: CONSTRAINT; Schema: public; Owner: keycloak
--

ALTER TABLE ONLY public.username_login_failure
    ADD CONSTRAINT "CONSTRAINT_17-2" PRIMARY KEY (realm_id, username);


--
-- Name: keycloak_role UK_J3RWUVD56ONTGSUHOGM184WW2-2; Type: CONSTRAINT; Schema: public; Owner: keycloak
--

ALTER TABLE ONLY public.keycloak_role
    ADD CONSTRAINT "UK_J3RWUVD56ONTGSUHOGM184WW2-2" UNIQUE (name, client_realm_constraint);


--
-- Name: client_auth_flow_bindings c_cli_flow_bind; Type: CONSTRAINT; Schema: public; Owner: keycloak
--

ALTER TABLE ONLY public.client_auth_flow_bindings
    ADD CONSTRAINT c_cli_flow_bind PRIMARY KEY (client_id, binding_name);


--
-- Name: client_scope_client c_cli_scope_bind; Type: CONSTRAINT; Schema: public; Owner: keycloak
--

ALTER TABLE ONLY public.client_scope_client
    ADD CONSTRAINT c_cli_scope_bind PRIMARY KEY (client_id, scope_id);


--
-- Name: client_initial_access cnstr_client_init_acc_pk; Type: CONSTRAINT; Schema: public; Owner: keycloak
--

ALTER TABLE ONLY public.client_initial_access
    ADD CONSTRAINT cnstr_client_init_acc_pk PRIMARY KEY (id);


--
-- Name: realm_default_groups con_group_id_def_groups; Type: CONSTRAINT; Schema: public; Owner: keycloak
--

ALTER TABLE ONLY public.realm_default_groups
    ADD CONSTRAINT con_group_id_def_groups UNIQUE (group_id);


--
-- Name: broker_link constr_broker_link_pk; Type: CONSTRAINT; Schema: public; Owner: keycloak
--

ALTER TABLE ONLY public.broker_link
    ADD CONSTRAINT constr_broker_link_pk PRIMARY KEY (identity_provider, user_id);


--
-- Name: client_user_session_note constr_cl_usr_ses_note; Type: CONSTRAINT; Schema: public; Owner: keycloak
--

ALTER TABLE ONLY public.client_user_session_note
    ADD CONSTRAINT constr_cl_usr_ses_note PRIMARY KEY (client_session, name);


--
-- Name: component_config constr_component_config_pk; Type: CONSTRAINT; Schema: public; Owner: keycloak
--

ALTER TABLE ONLY public.component_config
    ADD CONSTRAINT constr_component_config_pk PRIMARY KEY (id);


--
-- Name: component constr_component_pk; Type: CONSTRAINT; Schema: public; Owner: keycloak
--

ALTER TABLE ONLY public.component
    ADD CONSTRAINT constr_component_pk PRIMARY KEY (id);


--
-- Name: fed_user_required_action constr_fed_required_action; Type: CONSTRAINT; Schema: public; Owner: keycloak
--

ALTER TABLE ONLY public.fed_user_required_action
    ADD CONSTRAINT constr_fed_required_action PRIMARY KEY (required_action, user_id);


--
-- Name: fed_user_attribute constr_fed_user_attr_pk; Type: CONSTRAINT; Schema: public; Owner: keycloak
--

ALTER TABLE ONLY public.fed_user_attribute
    ADD CONSTRAINT constr_fed_user_attr_pk PRIMARY KEY (id);


--
-- Name: fed_user_consent constr_fed_user_consent_pk; Type: CONSTRAINT; Schema: public; Owner: keycloak
--

ALTER TABLE ONLY public.fed_user_consent
    ADD CONSTRAINT constr_fed_user_consent_pk PRIMARY KEY (id);


--
-- Name: fed_user_credential constr_fed_user_cred_pk; Type: CONSTRAINT; Schema: public; Owner: keycloak
--

ALTER TABLE ONLY public.fed_user_credential
    ADD CONSTRAINT constr_fed_user_cred_pk PRIMARY KEY (id);


--
-- Name: fed_user_group_membership constr_fed_user_group; Type: CONSTRAINT; Schema: public; Owner: keycloak
--

ALTER TABLE ONLY public.fed_user_group_membership
    ADD CONSTRAINT constr_fed_user_group PRIMARY KEY (group_id, user_id);


--
-- Name: fed_user_role_mapping constr_fed_user_role; Type: CONSTRAINT; Schema: public; Owner: keycloak
--

ALTER TABLE ONLY public.fed_user_role_mapping
    ADD CONSTRAINT constr_fed_user_role PRIMARY KEY (role_id, user_id);


--
-- Name: federated_user constr_federated_user; Type: CONSTRAINT; Schema: public; Owner: keycloak
--

ALTER TABLE ONLY public.federated_user
    ADD CONSTRAINT constr_federated_user PRIMARY KEY (id);


--
-- Name: realm_default_groups constr_realm_default_groups; Type: CONSTRAINT; Schema: public; Owner: keycloak
--

ALTER TABLE ONLY public.realm_default_groups
    ADD CONSTRAINT constr_realm_default_groups PRIMARY KEY (realm_id, group_id);


--
-- Name: realm_enabled_event_types constr_realm_enabl_event_types; Type: CONSTRAINT; Schema: public; Owner: keycloak
--

ALTER TABLE ONLY public.realm_enabled_event_types
    ADD CONSTRAINT constr_realm_enabl_event_types PRIMARY KEY (realm_id, value);


--
-- Name: realm_events_listeners constr_realm_events_listeners; Type: CONSTRAINT; Schema: public; Owner: keycloak
--

ALTER TABLE ONLY public.realm_events_listeners
    ADD CONSTRAINT constr_realm_events_listeners PRIMARY KEY (realm_id, value);


--
-- Name: realm_supported_locales constr_realm_supported_locales; Type: CONSTRAINT; Schema: public; Owner: keycloak
--

ALTER TABLE ONLY public.realm_supported_locales
    ADD CONSTRAINT constr_realm_supported_locales PRIMARY KEY (realm_id, value);


--
-- Name: identity_provider constraint_2b; Type: CONSTRAINT; Schema: public; Owner: keycloak
--

ALTER TABLE ONLY public.identity_provider
    ADD CONSTRAINT constraint_2b PRIMARY KEY (internal_id);


--
-- Name: client_attributes constraint_3c; Type: CONSTRAINT; Schema: public; Owner: keycloak
--

ALTER TABLE ONLY public.client_attributes
    ADD CONSTRAINT constraint_3c PRIMARY KEY (client_id, name);


--
-- Name: event_entity constraint_4; Type: CONSTRAINT; Schema: public; Owner: keycloak
--

ALTER TABLE ONLY public.event_entity
    ADD CONSTRAINT constraint_4 PRIMARY KEY (id);


--
-- Name: federated_identity constraint_40; Type: CONSTRAINT; Schema: public; Owner: keycloak
--

ALTER TABLE ONLY public.federated_identity
    ADD CONSTRAINT constraint_40 PRIMARY KEY (identity_provider, user_id);


--
-- Name: realm constraint_4a; Type: CONSTRAINT; Schema: public; Owner: keycloak
--

ALTER TABLE ONLY public.realm
    ADD CONSTRAINT constraint_4a PRIMARY KEY (id);


--
-- Name: client_session_role constraint_5; Type: CONSTRAINT; Schema: public; Owner: keycloak
--

ALTER TABLE ONLY public.client_session_role
    ADD CONSTRAINT constraint_5 PRIMARY KEY (client_session, role_id);


--
-- Name: user_session constraint_57; Type: CONSTRAINT; Schema: public; Owner: keycloak
--

ALTER TABLE ONLY public.user_session
    ADD CONSTRAINT constraint_57 PRIMARY KEY (id);


--
-- Name: user_federation_provider constraint_5c; Type: CONSTRAINT; Schema: public; Owner: keycloak
--

ALTER TABLE ONLY public.user_federation_provider
    ADD CONSTRAINT constraint_5c PRIMARY KEY (id);


--
-- Name: client_session_note constraint_5e; Type: CONSTRAINT; Schema: public; Owner: keycloak
--

ALTER TABLE ONLY public.client_session_note
    ADD CONSTRAINT constraint_5e PRIMARY KEY (client_session, name);


--
-- Name: client constraint_7; Type: CONSTRAINT; Schema: public; Owner: keycloak
--

ALTER TABLE ONLY public.client
    ADD CONSTRAINT constraint_7 PRIMARY KEY (id);


--
-- Name: client_session constraint_8; Type: CONSTRAINT; Schema: public; Owner: keycloak
--

ALTER TABLE ONLY public.client_session
    ADD CONSTRAINT constraint_8 PRIMARY KEY (id);


--
-- Name: scope_mapping constraint_81; Type: CONSTRAINT; Schema: public; Owner: keycloak
--

ALTER TABLE ONLY public.scope_mapping
    ADD CONSTRAINT constraint_81 PRIMARY KEY (client_id, role_id);


--
-- Name: client_node_registrations constraint_84; Type: CONSTRAINT; Schema: public; Owner: keycloak
--

ALTER TABLE ONLY public.client_node_registrations
    ADD CONSTRAINT constraint_84 PRIMARY KEY (client_id, name);


--
-- Name: realm_attribute constraint_9; Type: CONSTRAINT; Schema: public; Owner: keycloak
--

ALTER TABLE ONLY public.realm_attribute
    ADD CONSTRAINT constraint_9 PRIMARY KEY (name, realm_id);


--
-- Name: realm_required_credential constraint_92; Type: CONSTRAINT; Schema: public; Owner: keycloak
--

ALTER TABLE ONLY public.realm_required_credential
    ADD CONSTRAINT constraint_92 PRIMARY KEY (realm_id, type);


--
-- Name: keycloak_role constraint_a; Type: CONSTRAINT; Schema: public; Owner: keycloak
--

ALTER TABLE ONLY public.keycloak_role
    ADD CONSTRAINT constraint_a PRIMARY KEY (id);


--
-- Name: admin_event_entity constraint_admin_event_entity; Type: CONSTRAINT; Schema: public; Owner: keycloak
--

ALTER TABLE ONLY public.admin_event_entity
    ADD CONSTRAINT constraint_admin_event_entity PRIMARY KEY (id);


--
-- Name: authenticator_config_entry constraint_auth_cfg_pk; Type: CONSTRAINT; Schema: public; Owner: keycloak
--

ALTER TABLE ONLY public.authenticator_config_entry
    ADD CONSTRAINT constraint_auth_cfg_pk PRIMARY KEY (authenticator_id, name);


--
-- Name: authentication_execution constraint_auth_exec_pk; Type: CONSTRAINT; Schema: public; Owner: keycloak
--

ALTER TABLE ONLY public.authentication_execution
    ADD CONSTRAINT constraint_auth_exec_pk PRIMARY KEY (id);


--
-- Name: authentication_flow constraint_auth_flow_pk; Type: CONSTRAINT; Schema: public; Owner: keycloak
--

ALTER TABLE ONLY public.authentication_flow
    ADD CONSTRAINT constraint_auth_flow_pk PRIMARY KEY (id);


--
-- Name: authenticator_config constraint_auth_pk; Type: CONSTRAINT; Schema: public; Owner: keycloak
--

ALTER TABLE ONLY public.authenticator_config
    ADD CONSTRAINT constraint_auth_pk PRIMARY KEY (id);


--
-- Name: client_session_auth_status constraint_auth_status_pk; Type: CONSTRAINT; Schema: public; Owner: keycloak
--

ALTER TABLE ONLY public.client_session_auth_status
    ADD CONSTRAINT constraint_auth_status_pk PRIMARY KEY (client_session, authenticator);


--
-- Name: user_role_mapping constraint_c; Type: CONSTRAINT; Schema: public; Owner: keycloak
--

ALTER TABLE ONLY public.user_role_mapping
    ADD CONSTRAINT constraint_c PRIMARY KEY (role_id, user_id);


--
-- Name: composite_role constraint_composite_role; Type: CONSTRAINT; Schema: public; Owner: keycloak
--

ALTER TABLE ONLY public.composite_role
    ADD CONSTRAINT constraint_composite_role PRIMARY KEY (composite, child_role);


--
-- Name: client_session_prot_mapper constraint_cs_pmp_pk; Type: CONSTRAINT; Schema: public; Owner: keycloak
--

ALTER TABLE ONLY public.client_session_prot_mapper
    ADD CONSTRAINT constraint_cs_pmp_pk PRIMARY KEY (client_session, protocol_mapper_id);


--
-- Name: identity_provider_config constraint_d; Type: CONSTRAINT; Schema: public; Owner: keycloak
--

ALTER TABLE ONLY public.identity_provider_config
    ADD CONSTRAINT constraint_d PRIMARY KEY (identity_provider_id, name);


--
-- Name: policy_config constraint_dpc; Type: CONSTRAINT; Schema: public; Owner: keycloak
--

ALTER TABLE ONLY public.policy_config
    ADD CONSTRAINT constraint_dpc PRIMARY KEY (policy_id, name);


--
-- Name: realm_smtp_config constraint_e; Type: CONSTRAINT; Schema: public; Owner: keycloak
--

ALTER TABLE ONLY public.realm_smtp_config
    ADD CONSTRAINT constraint_e PRIMARY KEY (realm_id, name);


--
-- Name: credential constraint_f; Type: CONSTRAINT; Schema: public; Owner: keycloak
--

ALTER TABLE ONLY public.credential
    ADD CONSTRAINT constraint_f PRIMARY KEY (id);


--
-- Name: user_federation_config constraint_f9; Type: CONSTRAINT; Schema: public; Owner: keycloak
--

ALTER TABLE ONLY public.user_federation_config
    ADD CONSTRAINT constraint_f9 PRIMARY KEY (user_federation_provider_id, name);


--
-- Name: resource_server_perm_ticket constraint_fapmt; Type: CONSTRAINT; Schema: public; Owner: keycloak
--

ALTER TABLE ONLY public.resource_server_perm_ticket
    ADD CONSTRAINT constraint_fapmt PRIMARY KEY (id);


--
-- Name: resource_server_resource constraint_farsr; Type: CONSTRAINT; Schema: public; Owner: keycloak
--

ALTER TABLE ONLY public.resource_server_resource
    ADD CONSTRAINT constraint_farsr PRIMARY KEY (id);


--
-- Name: resource_server_policy constraint_farsrp; Type: CONSTRAINT; Schema: public; Owner: keycloak
--

ALTER TABLE ONLY public.resource_server_policy
    ADD CONSTRAINT constraint_farsrp PRIMARY KEY (id);


--
-- Name: associated_policy constraint_farsrpap; Type: CONSTRAINT; Schema: public; Owner: keycloak
--

ALTER TABLE ONLY public.associated_policy
    ADD CONSTRAINT constraint_farsrpap PRIMARY KEY (policy_id, associated_policy_id);


--
-- Name: resource_policy constraint_farsrpp; Type: CONSTRAINT; Schema: public; Owner: keycloak
--

ALTER TABLE ONLY public.resource_policy
    ADD CONSTRAINT constraint_farsrpp PRIMARY KEY (resource_id, policy_id);


--
-- Name: resource_server_scope constraint_farsrs; Type: CONSTRAINT; Schema: public; Owner: keycloak
--

ALTER TABLE ONLY public.resource_server_scope
    ADD CONSTRAINT constraint_farsrs PRIMARY KEY (id);


--
-- Name: resource_scope constraint_farsrsp; Type: CONSTRAINT; Schema: public; Owner: keycloak
--

ALTER TABLE ONLY public.resource_scope
    ADD CONSTRAINT constraint_farsrsp PRIMARY KEY (resource_id, scope_id);


--
-- Name: scope_policy constraint_farsrsps; Type: CONSTRAINT; Schema: public; Owner: keycloak
--

ALTER TABLE ONLY public.scope_policy
    ADD CONSTRAINT constraint_farsrsps PRIMARY KEY (scope_id, policy_id);


--
-- Name: user_entity constraint_fb; Type: CONSTRAINT; Schema: public; Owner: keycloak
--

ALTER TABLE ONLY public.user_entity
    ADD CONSTRAINT constraint_fb PRIMARY KEY (id);


--
-- Name: user_federation_mapper_config constraint_fedmapper_cfg_pm; Type: CONSTRAINT; Schema: public; Owner: keycloak
--

ALTER TABLE ONLY public.user_federation_mapper_config
    ADD CONSTRAINT constraint_fedmapper_cfg_pm PRIMARY KEY (user_federation_mapper_id, name);


--
-- Name: user_federation_mapper constraint_fedmapperpm; Type: CONSTRAINT; Schema: public; Owner: keycloak
--

ALTER TABLE ONLY public.user_federation_mapper
    ADD CONSTRAINT constraint_fedmapperpm PRIMARY KEY (id);


--
-- Name: fed_user_consent_cl_scope constraint_fgrntcsnt_clsc_pm; Type: CONSTRAINT; Schema: public; Owner: keycloak
--

ALTER TABLE ONLY public.fed_user_consent_cl_scope
    ADD CONSTRAINT constraint_fgrntcsnt_clsc_pm PRIMARY KEY (user_consent_id, scope_id);


--
-- Name: user_consent_client_scope constraint_grntcsnt_clsc_pm; Type: CONSTRAINT; Schema: public; Owner: keycloak
--

ALTER TABLE ONLY public.user_consent_client_scope
    ADD CONSTRAINT constraint_grntcsnt_clsc_pm PRIMARY KEY (user_consent_id, scope_id);


--
-- Name: user_consent constraint_grntcsnt_pm; Type: CONSTRAINT; Schema: public; Owner: keycloak
--

ALTER TABLE ONLY public.user_consent
    ADD CONSTRAINT constraint_grntcsnt_pm PRIMARY KEY (id);


--
-- Name: keycloak_group constraint_group; Type: CONSTRAINT; Schema: public; Owner: keycloak
--

ALTER TABLE ONLY public.keycloak_group
    ADD CONSTRAINT constraint_group PRIMARY KEY (id);


--
-- Name: group_attribute constraint_group_attribute_pk; Type: CONSTRAINT; Schema: public; Owner: keycloak
--

ALTER TABLE ONLY public.group_attribute
    ADD CONSTRAINT constraint_group_attribute_pk PRIMARY KEY (id);


--
-- Name: group_role_mapping constraint_group_role; Type: CONSTRAINT; Schema: public; Owner: keycloak
--

ALTER TABLE ONLY public.group_role_mapping
    ADD CONSTRAINT constraint_group_role PRIMARY KEY (role_id, group_id);


--
-- Name: identity_provider_mapper constraint_idpm; Type: CONSTRAINT; Schema: public; Owner: keycloak
--

ALTER TABLE ONLY public.identity_provider_mapper
    ADD CONSTRAINT constraint_idpm PRIMARY KEY (id);


--
-- Name: idp_mapper_config constraint_idpmconfig; Type: CONSTRAINT; Schema: public; Owner: keycloak
--

ALTER TABLE ONLY public.idp_mapper_config
    ADD CONSTRAINT constraint_idpmconfig PRIMARY KEY (idp_mapper_id, name);


--
-- Name: migration_model constraint_migmod; Type: CONSTRAINT; Schema: public; Owner: keycloak
--

ALTER TABLE ONLY public.migration_model
    ADD CONSTRAINT constraint_migmod PRIMARY KEY (id);


--
-- Name: offline_client_session constraint_offl_cl_ses_pk3; Type: CONSTRAINT; Schema: public; Owner: keycloak
--

ALTER TABLE ONLY public.offline_client_session
    ADD CONSTRAINT constraint_offl_cl_ses_pk3 PRIMARY KEY (user_session_id, client_id, client_storage_provider, external_client_id, offline_flag);


--
-- Name: offline_user_session constraint_offl_us_ses_pk2; Type: CONSTRAINT; Schema: public; Owner: keycloak
--

ALTER TABLE ONLY public.offline_user_session
    ADD CONSTRAINT constraint_offl_us_ses_pk2 PRIMARY KEY (user_session_id, offline_flag);


--
-- Name: protocol_mapper constraint_pcm; Type: CONSTRAINT; Schema: public; Owner: keycloak
--

ALTER TABLE ONLY public.protocol_mapper
    ADD CONSTRAINT constraint_pcm PRIMARY KEY (id);


--
-- Name: protocol_mapper_config constraint_pmconfig; Type: CONSTRAINT; Schema: public; Owner: keycloak
--

ALTER TABLE ONLY public.protocol_mapper_config
    ADD CONSTRAINT constraint_pmconfig PRIMARY KEY (protocol_mapper_id, name);


--
-- Name: redirect_uris constraint_redirect_uris; Type: CONSTRAINT; Schema: public; Owner: keycloak
--

ALTER TABLE ONLY public.redirect_uris
    ADD CONSTRAINT constraint_redirect_uris PRIMARY KEY (client_id, value);


--
-- Name: required_action_config constraint_req_act_cfg_pk; Type: CONSTRAINT; Schema: public; Owner: keycloak
--

ALTER TABLE ONLY public.required_action_config
    ADD CONSTRAINT constraint_req_act_cfg_pk PRIMARY KEY (required_action_id, name);


--
-- Name: required_action_provider constraint_req_act_prv_pk; Type: CONSTRAINT; Schema: public; Owner: keycloak
--

ALTER TABLE ONLY public.required_action_provider
    ADD CONSTRAINT constraint_req_act_prv_pk PRIMARY KEY (id);


--
-- Name: user_required_action constraint_required_action; Type: CONSTRAINT; Schema: public; Owner: keycloak
--

ALTER TABLE ONLY public.user_required_action
    ADD CONSTRAINT constraint_required_action PRIMARY KEY (required_action, user_id);


--
-- Name: resource_uris constraint_resour_uris_pk; Type: CONSTRAINT; Schema: public; Owner: keycloak
--

ALTER TABLE ONLY public.resource_uris
    ADD CONSTRAINT constraint_resour_uris_pk PRIMARY KEY (resource_id, value);


--
-- Name: role_attribute constraint_role_attribute_pk; Type: CONSTRAINT; Schema: public; Owner: keycloak
--

ALTER TABLE ONLY public.role_attribute
    ADD CONSTRAINT constraint_role_attribute_pk PRIMARY KEY (id);


--
-- Name: user_attribute constraint_user_attribute_pk; Type: CONSTRAINT; Schema: public; Owner: keycloak
--

ALTER TABLE ONLY public.user_attribute
    ADD CONSTRAINT constraint_user_attribute_pk PRIMARY KEY (id);


--
-- Name: user_group_membership constraint_user_group; Type: CONSTRAINT; Schema: public; Owner: keycloak
--

ALTER TABLE ONLY public.user_group_membership
    ADD CONSTRAINT constraint_user_group PRIMARY KEY (group_id, user_id);


--
-- Name: user_session_note constraint_usn_pk; Type: CONSTRAINT; Schema: public; Owner: keycloak
--

ALTER TABLE ONLY public.user_session_note
    ADD CONSTRAINT constraint_usn_pk PRIMARY KEY (user_session, name);


--
-- Name: web_origins constraint_web_origins; Type: CONSTRAINT; Schema: public; Owner: keycloak
--

ALTER TABLE ONLY public.web_origins
    ADD CONSTRAINT constraint_web_origins PRIMARY KEY (client_id, value);


--
-- Name: client_scope_attributes pk_cl_tmpl_attr; Type: CONSTRAINT; Schema: public; Owner: keycloak
--

ALTER TABLE ONLY public.client_scope_attributes
    ADD CONSTRAINT pk_cl_tmpl_attr PRIMARY KEY (scope_id, name);


--
-- Name: client_scope pk_cli_template; Type: CONSTRAINT; Schema: public; Owner: keycloak
--

ALTER TABLE ONLY public.client_scope
    ADD CONSTRAINT pk_cli_template PRIMARY KEY (id);


--
-- Name: databasechangeloglock pk_databasechangeloglock; Type: CONSTRAINT; Schema: public; Owner: keycloak
--

ALTER TABLE ONLY public.databasechangeloglock
    ADD CONSTRAINT pk_databasechangeloglock PRIMARY KEY (id);


--
-- Name: resource_server pk_resource_server; Type: CONSTRAINT; Schema: public; Owner: keycloak
--

ALTER TABLE ONLY public.resource_server
    ADD CONSTRAINT pk_resource_server PRIMARY KEY (id);


--
-- Name: client_scope_role_mapping pk_template_scope; Type: CONSTRAINT; Schema: public; Owner: keycloak
--

ALTER TABLE ONLY public.client_scope_role_mapping
    ADD CONSTRAINT pk_template_scope PRIMARY KEY (scope_id, role_id);


--
-- Name: default_client_scope r_def_cli_scope_bind; Type: CONSTRAINT; Schema: public; Owner: keycloak
--

ALTER TABLE ONLY public.default_client_scope
    ADD CONSTRAINT r_def_cli_scope_bind PRIMARY KEY (realm_id, scope_id);


--
-- Name: realm_localizations realm_localizations_pkey; Type: CONSTRAINT; Schema: public; Owner: keycloak
--

ALTER TABLE ONLY public.realm_localizations
    ADD CONSTRAINT realm_localizations_pkey PRIMARY KEY (realm_id, locale);


--
-- Name: resource_attribute res_attr_pk; Type: CONSTRAINT; Schema: public; Owner: keycloak
--

ALTER TABLE ONLY public.resource_attribute
    ADD CONSTRAINT res_attr_pk PRIMARY KEY (id);


--
-- Name: keycloak_group sibling_names; Type: CONSTRAINT; Schema: public; Owner: keycloak
--

ALTER TABLE ONLY public.keycloak_group
    ADD CONSTRAINT sibling_names UNIQUE (realm_id, parent_group, name);


--
-- Name: identity_provider uk_2daelwnibji49avxsrtuf6xj33; Type: CONSTRAINT; Schema: public; Owner: keycloak
--

ALTER TABLE ONLY public.identity_provider
    ADD CONSTRAINT uk_2daelwnibji49avxsrtuf6xj33 UNIQUE (provider_alias, realm_id);


--
-- Name: client uk_b71cjlbenv945rb6gcon438at; Type: CONSTRAINT; Schema: public; Owner: keycloak
--

ALTER TABLE ONLY public.client
    ADD CONSTRAINT uk_b71cjlbenv945rb6gcon438at UNIQUE (realm_id, client_id);


--
-- Name: client_scope uk_cli_scope; Type: CONSTRAINT; Schema: public; Owner: keycloak
--

ALTER TABLE ONLY public.client_scope
    ADD CONSTRAINT uk_cli_scope UNIQUE (realm_id, name);


--
-- Name: user_entity uk_dykn684sl8up1crfei6eckhd7; Type: CONSTRAINT; Schema: public; Owner: keycloak
--

ALTER TABLE ONLY public.user_entity
    ADD CONSTRAINT uk_dykn684sl8up1crfei6eckhd7 UNIQUE (realm_id, email_constraint);


--
-- Name: resource_server_resource uk_frsr6t700s9v50bu18ws5ha6; Type: CONSTRAINT; Schema: public; Owner: keycloak
--

ALTER TABLE ONLY public.resource_server_resource
    ADD CONSTRAINT uk_frsr6t700s9v50bu18ws5ha6 UNIQUE (name, owner, resource_server_id);


--
-- Name: resource_server_perm_ticket uk_frsr6t700s9v50bu18ws5pmt; Type: CONSTRAINT; Schema: public; Owner: keycloak
--

ALTER TABLE ONLY public.resource_server_perm_ticket
    ADD CONSTRAINT uk_frsr6t700s9v50bu18ws5pmt UNIQUE (owner, requester, resource_server_id, resource_id, scope_id);


--
-- Name: resource_server_policy uk_frsrpt700s9v50bu18ws5ha6; Type: CONSTRAINT; Schema: public; Owner: keycloak
--

ALTER TABLE ONLY public.resource_server_policy
    ADD CONSTRAINT uk_frsrpt700s9v50bu18ws5ha6 UNIQUE (name, resource_server_id);


--
-- Name: resource_server_scope uk_frsrst700s9v50bu18ws5ha6; Type: CONSTRAINT; Schema: public; Owner: keycloak
--

ALTER TABLE ONLY public.resource_server_scope
    ADD CONSTRAINT uk_frsrst700s9v50bu18ws5ha6 UNIQUE (name, resource_server_id);


--
-- Name: user_consent uk_jkuwuvd56ontgsuhogm8uewrt; Type: CONSTRAINT; Schema: public; Owner: keycloak
--

ALTER TABLE ONLY public.user_consent
    ADD CONSTRAINT uk_jkuwuvd56ontgsuhogm8uewrt UNIQUE (client_id, client_storage_provider, external_client_id, user_id);


--
-- Name: realm uk_orvsdmla56612eaefiq6wl5oi; Type: CONSTRAINT; Schema: public; Owner: keycloak
--

ALTER TABLE ONLY public.realm
    ADD CONSTRAINT uk_orvsdmla56612eaefiq6wl5oi UNIQUE (name);


--
-- Name: user_entity uk_ru8tt6t700s9v50bu18ws5ha6; Type: CONSTRAINT; Schema: public; Owner: keycloak
--

ALTER TABLE ONLY public.user_entity
    ADD CONSTRAINT uk_ru8tt6t700s9v50bu18ws5ha6 UNIQUE (realm_id, username);


--
-- Name: idx_assoc_pol_assoc_pol_id; Type: INDEX; Schema: public; Owner: keycloak
--

CREATE INDEX idx_assoc_pol_assoc_pol_id ON public.associated_policy USING btree (associated_policy_id);


--
-- Name: idx_auth_config_realm; Type: INDEX; Schema: public; Owner: keycloak
--

CREATE INDEX idx_auth_config_realm ON public.authenticator_config USING btree (realm_id);


--
-- Name: idx_auth_exec_flow; Type: INDEX; Schema: public; Owner: keycloak
--

CREATE INDEX idx_auth_exec_flow ON public.authentication_execution USING btree (flow_id);


--
-- Name: idx_auth_exec_realm_flow; Type: INDEX; Schema: public; Owner: keycloak
--

CREATE INDEX idx_auth_exec_realm_flow ON public.authentication_execution USING btree (realm_id, flow_id);


--
-- Name: idx_auth_flow_realm; Type: INDEX; Schema: public; Owner: keycloak
--

CREATE INDEX idx_auth_flow_realm ON public.authentication_flow USING btree (realm_id);


--
-- Name: idx_cl_clscope; Type: INDEX; Schema: public; Owner: keycloak
--

CREATE INDEX idx_cl_clscope ON public.client_scope_client USING btree (scope_id);


--
-- Name: idx_client_att_by_name_value; Type: INDEX; Schema: public; Owner: keycloak
--

CREATE INDEX idx_client_att_by_name_value ON public.client_attributes USING btree (name, value);


--
-- Name: idx_client_id; Type: INDEX; Schema: public; Owner: keycloak
--

CREATE INDEX idx_client_id ON public.client USING btree (client_id);


--
-- Name: idx_client_init_acc_realm; Type: INDEX; Schema: public; Owner: keycloak
--

CREATE INDEX idx_client_init_acc_realm ON public.client_initial_access USING btree (realm_id);


--
-- Name: idx_client_session_session; Type: INDEX; Schema: public; Owner: keycloak
--

CREATE INDEX idx_client_session_session ON public.client_session USING btree (session_id);


--
-- Name: idx_clscope_attrs; Type: INDEX; Schema: public; Owner: keycloak
--

CREATE INDEX idx_clscope_attrs ON public.client_scope_attributes USING btree (scope_id);


--
-- Name: idx_clscope_cl; Type: INDEX; Schema: public; Owner: keycloak
--

CREATE INDEX idx_clscope_cl ON public.client_scope_client USING btree (client_id);


--
-- Name: idx_clscope_protmap; Type: INDEX; Schema: public; Owner: keycloak
--

CREATE INDEX idx_clscope_protmap ON public.protocol_mapper USING btree (client_scope_id);


--
-- Name: idx_clscope_role; Type: INDEX; Schema: public; Owner: keycloak
--

CREATE INDEX idx_clscope_role ON public.client_scope_role_mapping USING btree (scope_id);


--
-- Name: idx_compo_config_compo; Type: INDEX; Schema: public; Owner: keycloak
--

CREATE INDEX idx_compo_config_compo ON public.component_config USING btree (component_id);


--
-- Name: idx_component_provider_type; Type: INDEX; Schema: public; Owner: keycloak
--

CREATE INDEX idx_component_provider_type ON public.component USING btree (provider_type);


--
-- Name: idx_component_realm; Type: INDEX; Schema: public; Owner: keycloak
--

CREATE INDEX idx_component_realm ON public.component USING btree (realm_id);


--
-- Name: idx_composite; Type: INDEX; Schema: public; Owner: keycloak
--

CREATE INDEX idx_composite ON public.composite_role USING btree (composite);


--
-- Name: idx_composite_child; Type: INDEX; Schema: public; Owner: keycloak
--

CREATE INDEX idx_composite_child ON public.composite_role USING btree (child_role);


--
-- Name: idx_defcls_realm; Type: INDEX; Schema: public; Owner: keycloak
--

CREATE INDEX idx_defcls_realm ON public.default_client_scope USING btree (realm_id);


--
-- Name: idx_defcls_scope; Type: INDEX; Schema: public; Owner: keycloak
--

CREATE INDEX idx_defcls_scope ON public.default_client_scope USING btree (scope_id);


--
-- Name: idx_event_time; Type: INDEX; Schema: public; Owner: keycloak
--

CREATE INDEX idx_event_time ON public.event_entity USING btree (realm_id, event_time);


--
-- Name: idx_fedidentity_feduser; Type: INDEX; Schema: public; Owner: keycloak
--

CREATE INDEX idx_fedidentity_feduser ON public.federated_identity USING btree (federated_user_id);


--
-- Name: idx_fedidentity_user; Type: INDEX; Schema: public; Owner: keycloak
--

CREATE INDEX idx_fedidentity_user ON public.federated_identity USING btree (user_id);


--
-- Name: idx_fu_attribute; Type: INDEX; Schema: public; Owner: keycloak
--

CREATE INDEX idx_fu_attribute ON public.fed_user_attribute USING btree (user_id, realm_id, name);


--
-- Name: idx_fu_cnsnt_ext; Type: INDEX; Schema: public; Owner: keycloak
--

CREATE INDEX idx_fu_cnsnt_ext ON public.fed_user_consent USING btree (user_id, client_storage_provider, external_client_id);


--
-- Name: idx_fu_consent; Type: INDEX; Schema: public; Owner: keycloak
--

CREATE INDEX idx_fu_consent ON public.fed_user_consent USING btree (user_id, client_id);


--
-- Name: idx_fu_consent_ru; Type: INDEX; Schema: public; Owner: keycloak
--

CREATE INDEX idx_fu_consent_ru ON public.fed_user_consent USING btree (realm_id, user_id);


--
-- Name: idx_fu_credential; Type: INDEX; Schema: public; Owner: keycloak
--

CREATE INDEX idx_fu_credential ON public.fed_user_credential USING btree (user_id, type);


--
-- Name: idx_fu_credential_ru; Type: INDEX; Schema: public; Owner: keycloak
--

CREATE INDEX idx_fu_credential_ru ON public.fed_user_credential USING btree (realm_id, user_id);


--
-- Name: idx_fu_group_membership; Type: INDEX; Schema: public; Owner: keycloak
--

CREATE INDEX idx_fu_group_membership ON public.fed_user_group_membership USING btree (user_id, group_id);


--
-- Name: idx_fu_group_membership_ru; Type: INDEX; Schema: public; Owner: keycloak
--

CREATE INDEX idx_fu_group_membership_ru ON public.fed_user_group_membership USING btree (realm_id, user_id);


--
-- Name: idx_fu_required_action; Type: INDEX; Schema: public; Owner: keycloak
--

CREATE INDEX idx_fu_required_action ON public.fed_user_required_action USING btree (user_id, required_action);


--
-- Name: idx_fu_required_action_ru; Type: INDEX; Schema: public; Owner: keycloak
--

CREATE INDEX idx_fu_required_action_ru ON public.fed_user_required_action USING btree (realm_id, user_id);


--
-- Name: idx_fu_role_mapping; Type: INDEX; Schema: public; Owner: keycloak
--

CREATE INDEX idx_fu_role_mapping ON public.fed_user_role_mapping USING btree (user_id, role_id);


--
-- Name: idx_fu_role_mapping_ru; Type: INDEX; Schema: public; Owner: keycloak
--

CREATE INDEX idx_fu_role_mapping_ru ON public.fed_user_role_mapping USING btree (realm_id, user_id);


--
-- Name: idx_group_attr_group; Type: INDEX; Schema: public; Owner: keycloak
--

CREATE INDEX idx_group_attr_group ON public.group_attribute USING btree (group_id);


--
-- Name: idx_group_role_mapp_group; Type: INDEX; Schema: public; Owner: keycloak
--

CREATE INDEX idx_group_role_mapp_group ON public.group_role_mapping USING btree (group_id);


--
-- Name: idx_id_prov_mapp_realm; Type: INDEX; Schema: public; Owner: keycloak
--

CREATE INDEX idx_id_prov_mapp_realm ON public.identity_provider_mapper USING btree (realm_id);


--
-- Name: idx_ident_prov_realm; Type: INDEX; Schema: public; Owner: keycloak
--

CREATE INDEX idx_ident_prov_realm ON public.identity_provider USING btree (realm_id);


--
-- Name: idx_keycloak_role_client; Type: INDEX; Schema: public; Owner: keycloak
--

CREATE INDEX idx_keycloak_role_client ON public.keycloak_role USING btree (client);


--
-- Name: idx_keycloak_role_realm; Type: INDEX; Schema: public; Owner: keycloak
--

CREATE INDEX idx_keycloak_role_realm ON public.keycloak_role USING btree (realm);


--
-- Name: idx_offline_css_preload; Type: INDEX; Schema: public; Owner: keycloak
--

CREATE INDEX idx_offline_css_preload ON public.offline_client_session USING btree (client_id, offline_flag);


--
-- Name: idx_offline_uss_by_user; Type: INDEX; Schema: public; Owner: keycloak
--

CREATE INDEX idx_offline_uss_by_user ON public.offline_user_session USING btree (user_id, realm_id, offline_flag);


--
-- Name: idx_offline_uss_by_usersess; Type: INDEX; Schema: public; Owner: keycloak
--

CREATE INDEX idx_offline_uss_by_usersess ON public.offline_user_session USING btree (realm_id, offline_flag, user_session_id);


--
-- Name: idx_offline_uss_createdon; Type: INDEX; Schema: public; Owner: keycloak
--

CREATE INDEX idx_offline_uss_createdon ON public.offline_user_session USING btree (created_on);


--
-- Name: idx_offline_uss_preload; Type: INDEX; Schema: public; Owner: keycloak
--

CREATE INDEX idx_offline_uss_preload ON public.offline_user_session USING btree (offline_flag, created_on, user_session_id);


--
-- Name: idx_protocol_mapper_client; Type: INDEX; Schema: public; Owner: keycloak
--

CREATE INDEX idx_protocol_mapper_client ON public.protocol_mapper USING btree (client_id);


--
-- Name: idx_realm_attr_realm; Type: INDEX; Schema: public; Owner: keycloak
--

CREATE INDEX idx_realm_attr_realm ON public.realm_attribute USING btree (realm_id);


--
-- Name: idx_realm_clscope; Type: INDEX; Schema: public; Owner: keycloak
--

CREATE INDEX idx_realm_clscope ON public.client_scope USING btree (realm_id);


--
-- Name: idx_realm_def_grp_realm; Type: INDEX; Schema: public; Owner: keycloak
--

CREATE INDEX idx_realm_def_grp_realm ON public.realm_default_groups USING btree (realm_id);


--
-- Name: idx_realm_evt_list_realm; Type: INDEX; Schema: public; Owner: keycloak
--

CREATE INDEX idx_realm_evt_list_realm ON public.realm_events_listeners USING btree (realm_id);


--
-- Name: idx_realm_evt_types_realm; Type: INDEX; Schema: public; Owner: keycloak
--

CREATE INDEX idx_realm_evt_types_realm ON public.realm_enabled_event_types USING btree (realm_id);


--
-- Name: idx_realm_master_adm_cli; Type: INDEX; Schema: public; Owner: keycloak
--

CREATE INDEX idx_realm_master_adm_cli ON public.realm USING btree (master_admin_client);


--
-- Name: idx_realm_supp_local_realm; Type: INDEX; Schema: public; Owner: keycloak
--

CREATE INDEX idx_realm_supp_local_realm ON public.realm_supported_locales USING btree (realm_id);


--
-- Name: idx_redir_uri_client; Type: INDEX; Schema: public; Owner: keycloak
--

CREATE INDEX idx_redir_uri_client ON public.redirect_uris USING btree (client_id);


--
-- Name: idx_req_act_prov_realm; Type: INDEX; Schema: public; Owner: keycloak
--

CREATE INDEX idx_req_act_prov_realm ON public.required_action_provider USING btree (realm_id);


--
-- Name: idx_res_policy_policy; Type: INDEX; Schema: public; Owner: keycloak
--

CREATE INDEX idx_res_policy_policy ON public.resource_policy USING btree (policy_id);


--
-- Name: idx_res_scope_scope; Type: INDEX; Schema: public; Owner: keycloak
--

CREATE INDEX idx_res_scope_scope ON public.resource_scope USING btree (scope_id);


--
-- Name: idx_res_serv_pol_res_serv; Type: INDEX; Schema: public; Owner: keycloak
--

CREATE INDEX idx_res_serv_pol_res_serv ON public.resource_server_policy USING btree (resource_server_id);


--
-- Name: idx_res_srv_res_res_srv; Type: INDEX; Schema: public; Owner: keycloak
--

CREATE INDEX idx_res_srv_res_res_srv ON public.resource_server_resource USING btree (resource_server_id);


--
-- Name: idx_res_srv_scope_res_srv; Type: INDEX; Schema: public; Owner: keycloak
--

CREATE INDEX idx_res_srv_scope_res_srv ON public.resource_server_scope USING btree (resource_server_id);


--
-- Name: idx_role_attribute; Type: INDEX; Schema: public; Owner: keycloak
--

CREATE INDEX idx_role_attribute ON public.role_attribute USING btree (role_id);


--
-- Name: idx_role_clscope; Type: INDEX; Schema: public; Owner: keycloak
--

CREATE INDEX idx_role_clscope ON public.client_scope_role_mapping USING btree (role_id);


--
-- Name: idx_scope_mapping_role; Type: INDEX; Schema: public; Owner: keycloak
--

CREATE INDEX idx_scope_mapping_role ON public.scope_mapping USING btree (role_id);


--
-- Name: idx_scope_policy_policy; Type: INDEX; Schema: public; Owner: keycloak
--

CREATE INDEX idx_scope_policy_policy ON public.scope_policy USING btree (policy_id);


--
-- Name: idx_update_time; Type: INDEX; Schema: public; Owner: keycloak
--

CREATE INDEX idx_update_time ON public.migration_model USING btree (update_time);


--
-- Name: idx_us_sess_id_on_cl_sess; Type: INDEX; Schema: public; Owner: keycloak
--

CREATE INDEX idx_us_sess_id_on_cl_sess ON public.offline_client_session USING btree (user_session_id);


--
-- Name: idx_usconsent_clscope; Type: INDEX; Schema: public; Owner: keycloak
--

CREATE INDEX idx_usconsent_clscope ON public.user_consent_client_scope USING btree (user_consent_id);


--
-- Name: idx_user_attribute; Type: INDEX; Schema: public; Owner: keycloak
--

CREATE INDEX idx_user_attribute ON public.user_attribute USING btree (user_id);


--
-- Name: idx_user_attribute_name; Type: INDEX; Schema: public; Owner: keycloak
--

CREATE INDEX idx_user_attribute_name ON public.user_attribute USING btree (name, value);


--
-- Name: idx_user_consent; Type: INDEX; Schema: public; Owner: keycloak
--

CREATE INDEX idx_user_consent ON public.user_consent USING btree (user_id);


--
-- Name: idx_user_credential; Type: INDEX; Schema: public; Owner: keycloak
--

CREATE INDEX idx_user_credential ON public.credential USING btree (user_id);


--
-- Name: idx_user_email; Type: INDEX; Schema: public; Owner: keycloak
--

CREATE INDEX idx_user_email ON public.user_entity USING btree (email);


--
-- Name: idx_user_group_mapping; Type: INDEX; Schema: public; Owner: keycloak
--

CREATE INDEX idx_user_group_mapping ON public.user_group_membership USING btree (user_id);


--
-- Name: idx_user_reqactions; Type: INDEX; Schema: public; Owner: keycloak
--

CREATE INDEX idx_user_reqactions ON public.user_required_action USING btree (user_id);


--
-- Name: idx_user_role_mapping; Type: INDEX; Schema: public; Owner: keycloak
--

CREATE INDEX idx_user_role_mapping ON public.user_role_mapping USING btree (user_id);


--
-- Name: idx_usr_fed_map_fed_prv; Type: INDEX; Schema: public; Owner: keycloak
--

CREATE INDEX idx_usr_fed_map_fed_prv ON public.user_federation_mapper USING btree (federation_provider_id);


--
-- Name: idx_usr_fed_map_realm; Type: INDEX; Schema: public; Owner: keycloak
--

CREATE INDEX idx_usr_fed_map_realm ON public.user_federation_mapper USING btree (realm_id);


--
-- Name: idx_usr_fed_prv_realm; Type: INDEX; Schema: public; Owner: keycloak
--

CREATE INDEX idx_usr_fed_prv_realm ON public.user_federation_provider USING btree (realm_id);


--
-- Name: idx_web_orig_client; Type: INDEX; Schema: public; Owner: keycloak
--

CREATE INDEX idx_web_orig_client ON public.web_origins USING btree (client_id);


--
-- Name: client_session_auth_status auth_status_constraint; Type: FK CONSTRAINT; Schema: public; Owner: keycloak
--

ALTER TABLE ONLY public.client_session_auth_status
    ADD CONSTRAINT auth_status_constraint FOREIGN KEY (client_session) REFERENCES public.client_session(id);


--
-- Name: identity_provider fk2b4ebc52ae5c3b34; Type: FK CONSTRAINT; Schema: public; Owner: keycloak
--

ALTER TABLE ONLY public.identity_provider
    ADD CONSTRAINT fk2b4ebc52ae5c3b34 FOREIGN KEY (realm_id) REFERENCES public.realm(id);


--
-- Name: client_attributes fk3c47c64beacca966; Type: FK CONSTRAINT; Schema: public; Owner: keycloak
--

ALTER TABLE ONLY public.client_attributes
    ADD CONSTRAINT fk3c47c64beacca966 FOREIGN KEY (client_id) REFERENCES public.client(id);


--
-- Name: federated_identity fk404288b92ef007a6; Type: FK CONSTRAINT; Schema: public; Owner: keycloak
--

ALTER TABLE ONLY public.federated_identity
    ADD CONSTRAINT fk404288b92ef007a6 FOREIGN KEY (user_id) REFERENCES public.user_entity(id);


--
-- Name: client_node_registrations fk4129723ba992f594; Type: FK CONSTRAINT; Schema: public; Owner: keycloak
--

ALTER TABLE ONLY public.client_node_registrations
    ADD CONSTRAINT fk4129723ba992f594 FOREIGN KEY (client_id) REFERENCES public.client(id);


--
-- Name: client_session_note fk5edfb00ff51c2736; Type: FK CONSTRAINT; Schema: public; Owner: keycloak
--

ALTER TABLE ONLY public.client_session_note
    ADD CONSTRAINT fk5edfb00ff51c2736 FOREIGN KEY (client_session) REFERENCES public.client_session(id);


--
-- Name: user_session_note fk5edfb00ff51d3472; Type: FK CONSTRAINT; Schema: public; Owner: keycloak
--

ALTER TABLE ONLY public.user_session_note
    ADD CONSTRAINT fk5edfb00ff51d3472 FOREIGN KEY (user_session) REFERENCES public.user_session(id);


--
-- Name: client_session_role fk_11b7sgqw18i532811v7o2dv76; Type: FK CONSTRAINT; Schema: public; Owner: keycloak
--

ALTER TABLE ONLY public.client_session_role
    ADD CONSTRAINT fk_11b7sgqw18i532811v7o2dv76 FOREIGN KEY (client_session) REFERENCES public.client_session(id);


--
-- Name: redirect_uris fk_1burs8pb4ouj97h5wuppahv9f; Type: FK CONSTRAINT; Schema: public; Owner: keycloak
--

ALTER TABLE ONLY public.redirect_uris
    ADD CONSTRAINT fk_1burs8pb4ouj97h5wuppahv9f FOREIGN KEY (client_id) REFERENCES public.client(id);


--
-- Name: user_federation_provider fk_1fj32f6ptolw2qy60cd8n01e8; Type: FK CONSTRAINT; Schema: public; Owner: keycloak
--

ALTER TABLE ONLY public.user_federation_provider
    ADD CONSTRAINT fk_1fj32f6ptolw2qy60cd8n01e8 FOREIGN KEY (realm_id) REFERENCES public.realm(id);


--
-- Name: client_session_prot_mapper fk_33a8sgqw18i532811v7o2dk89; Type: FK CONSTRAINT; Schema: public; Owner: keycloak
--

ALTER TABLE ONLY public.client_session_prot_mapper
    ADD CONSTRAINT fk_33a8sgqw18i532811v7o2dk89 FOREIGN KEY (client_session) REFERENCES public.client_session(id);


--
-- Name: realm_required_credential fk_5hg65lybevavkqfki3kponh9v; Type: FK CONSTRAINT; Schema: public; Owner: keycloak
--

ALTER TABLE ONLY public.realm_required_credential
    ADD CONSTRAINT fk_5hg65lybevavkqfki3kponh9v FOREIGN KEY (realm_id) REFERENCES public.realm(id);


--
-- Name: resource_attribute fk_5hrm2vlf9ql5fu022kqepovbr; Type: FK CONSTRAINT; Schema: public; Owner: keycloak
--

ALTER TABLE ONLY public.resource_attribute
    ADD CONSTRAINT fk_5hrm2vlf9ql5fu022kqepovbr FOREIGN KEY (resource_id) REFERENCES public.resource_server_resource(id);


--
-- Name: user_attribute fk_5hrm2vlf9ql5fu043kqepovbr; Type: FK CONSTRAINT; Schema: public; Owner: keycloak
--

ALTER TABLE ONLY public.user_attribute
    ADD CONSTRAINT fk_5hrm2vlf9ql5fu043kqepovbr FOREIGN KEY (user_id) REFERENCES public.user_entity(id);


--
-- Name: user_required_action fk_6qj3w1jw9cvafhe19bwsiuvmd; Type: FK CONSTRAINT; Schema: public; Owner: keycloak
--

ALTER TABLE ONLY public.user_required_action
    ADD CONSTRAINT fk_6qj3w1jw9cvafhe19bwsiuvmd FOREIGN KEY (user_id) REFERENCES public.user_entity(id);


--
-- Name: keycloak_role fk_6vyqfe4cn4wlq8r6kt5vdsj5c; Type: FK CONSTRAINT; Schema: public; Owner: keycloak
--

ALTER TABLE ONLY public.keycloak_role
    ADD CONSTRAINT fk_6vyqfe4cn4wlq8r6kt5vdsj5c FOREIGN KEY (realm) REFERENCES public.realm(id);


--
-- Name: realm_smtp_config fk_70ej8xdxgxd0b9hh6180irr0o; Type: FK CONSTRAINT; Schema: public; Owner: keycloak
--

ALTER TABLE ONLY public.realm_smtp_config
    ADD CONSTRAINT fk_70ej8xdxgxd0b9hh6180irr0o FOREIGN KEY (realm_id) REFERENCES public.realm(id);


--
-- Name: realm_attribute fk_8shxd6l3e9atqukacxgpffptw; Type: FK CONSTRAINT; Schema: public; Owner: keycloak
--

ALTER TABLE ONLY public.realm_attribute
    ADD CONSTRAINT fk_8shxd6l3e9atqukacxgpffptw FOREIGN KEY (realm_id) REFERENCES public.realm(id);


--
-- Name: composite_role fk_a63wvekftu8jo1pnj81e7mce2; Type: FK CONSTRAINT; Schema: public; Owner: keycloak
--

ALTER TABLE ONLY public.composite_role
    ADD CONSTRAINT fk_a63wvekftu8jo1pnj81e7mce2 FOREIGN KEY (composite) REFERENCES public.keycloak_role(id);


--
-- Name: authentication_execution fk_auth_exec_flow; Type: FK CONSTRAINT; Schema: public; Owner: keycloak
--

ALTER TABLE ONLY public.authentication_execution
    ADD CONSTRAINT fk_auth_exec_flow FOREIGN KEY (flow_id) REFERENCES public.authentication_flow(id);


--
-- Name: authentication_execution fk_auth_exec_realm; Type: FK CONSTRAINT; Schema: public; Owner: keycloak
--

ALTER TABLE ONLY public.authentication_execution
    ADD CONSTRAINT fk_auth_exec_realm FOREIGN KEY (realm_id) REFERENCES public.realm(id);


--
-- Name: authentication_flow fk_auth_flow_realm; Type: FK CONSTRAINT; Schema: public; Owner: keycloak
--

ALTER TABLE ONLY public.authentication_flow
    ADD CONSTRAINT fk_auth_flow_realm FOREIGN KEY (realm_id) REFERENCES public.realm(id);


--
-- Name: authenticator_config fk_auth_realm; Type: FK CONSTRAINT; Schema: public; Owner: keycloak
--

ALTER TABLE ONLY public.authenticator_config
    ADD CONSTRAINT fk_auth_realm FOREIGN KEY (realm_id) REFERENCES public.realm(id);


--
-- Name: client_session fk_b4ao2vcvat6ukau74wbwtfqo1; Type: FK CONSTRAINT; Schema: public; Owner: keycloak
--

ALTER TABLE ONLY public.client_session
    ADD CONSTRAINT fk_b4ao2vcvat6ukau74wbwtfqo1 FOREIGN KEY (session_id) REFERENCES public.user_session(id);


--
-- Name: user_role_mapping fk_c4fqv34p1mbylloxang7b1q3l; Type: FK CONSTRAINT; Schema: public; Owner: keycloak
--

ALTER TABLE ONLY public.user_role_mapping
    ADD CONSTRAINT fk_c4fqv34p1mbylloxang7b1q3l FOREIGN KEY (user_id) REFERENCES public.user_entity(id);


--
-- Name: client_scope_attributes fk_cl_scope_attr_scope; Type: FK CONSTRAINT; Schema: public; Owner: keycloak
--

ALTER TABLE ONLY public.client_scope_attributes
    ADD CONSTRAINT fk_cl_scope_attr_scope FOREIGN KEY (scope_id) REFERENCES public.client_scope(id);


--
-- Name: client_scope_role_mapping fk_cl_scope_rm_scope; Type: FK CONSTRAINT; Schema: public; Owner: keycloak
--

ALTER TABLE ONLY public.client_scope_role_mapping
    ADD CONSTRAINT fk_cl_scope_rm_scope FOREIGN KEY (scope_id) REFERENCES public.client_scope(id);


--
-- Name: client_user_session_note fk_cl_usr_ses_note; Type: FK CONSTRAINT; Schema: public; Owner: keycloak
--

ALTER TABLE ONLY public.client_user_session_note
    ADD CONSTRAINT fk_cl_usr_ses_note FOREIGN KEY (client_session) REFERENCES public.client_session(id);


--
-- Name: protocol_mapper fk_cli_scope_mapper; Type: FK CONSTRAINT; Schema: public; Owner: keycloak
--

ALTER TABLE ONLY public.protocol_mapper
    ADD CONSTRAINT fk_cli_scope_mapper FOREIGN KEY (client_scope_id) REFERENCES public.client_scope(id);


--
-- Name: client_initial_access fk_client_init_acc_realm; Type: FK CONSTRAINT; Schema: public; Owner: keycloak
--

ALTER TABLE ONLY public.client_initial_access
    ADD CONSTRAINT fk_client_init_acc_realm FOREIGN KEY (realm_id) REFERENCES public.realm(id);


--
-- Name: component_config fk_component_config; Type: FK CONSTRAINT; Schema: public; Owner: keycloak
--

ALTER TABLE ONLY public.component_config
    ADD CONSTRAINT fk_component_config FOREIGN KEY (component_id) REFERENCES public.component(id);


--
-- Name: component fk_component_realm; Type: FK CONSTRAINT; Schema: public; Owner: keycloak
--

ALTER TABLE ONLY public.component
    ADD CONSTRAINT fk_component_realm FOREIGN KEY (realm_id) REFERENCES public.realm(id);


--
-- Name: realm_default_groups fk_def_groups_realm; Type: FK CONSTRAINT; Schema: public; Owner: keycloak
--

ALTER TABLE ONLY public.realm_default_groups
    ADD CONSTRAINT fk_def_groups_realm FOREIGN KEY (realm_id) REFERENCES public.realm(id);


--
-- Name: user_federation_mapper_config fk_fedmapper_cfg; Type: FK CONSTRAINT; Schema: public; Owner: keycloak
--

ALTER TABLE ONLY public.user_federation_mapper_config
    ADD CONSTRAINT fk_fedmapper_cfg FOREIGN KEY (user_federation_mapper_id) REFERENCES public.user_federation_mapper(id);


--
-- Name: user_federation_mapper fk_fedmapperpm_fedprv; Type: FK CONSTRAINT; Schema: public; Owner: keycloak
--

ALTER TABLE ONLY public.user_federation_mapper
    ADD CONSTRAINT fk_fedmapperpm_fedprv FOREIGN KEY (federation_provider_id) REFERENCES public.user_federation_provider(id);


--
-- Name: user_federation_mapper fk_fedmapperpm_realm; Type: FK CONSTRAINT; Schema: public; Owner: keycloak
--

ALTER TABLE ONLY public.user_federation_mapper
    ADD CONSTRAINT fk_fedmapperpm_realm FOREIGN KEY (realm_id) REFERENCES public.realm(id);


--
-- Name: associated_policy fk_frsr5s213xcx4wnkog82ssrfy; Type: FK CONSTRAINT; Schema: public; Owner: keycloak
--

ALTER TABLE ONLY public.associated_policy
    ADD CONSTRAINT fk_frsr5s213xcx4wnkog82ssrfy FOREIGN KEY (associated_policy_id) REFERENCES public.resource_server_policy(id);


--
-- Name: scope_policy fk_frsrasp13xcx4wnkog82ssrfy; Type: FK CONSTRAINT; Schema: public; Owner: keycloak
--

ALTER TABLE ONLY public.scope_policy
    ADD CONSTRAINT fk_frsrasp13xcx4wnkog82ssrfy FOREIGN KEY (policy_id) REFERENCES public.resource_server_policy(id);


--
-- Name: resource_server_perm_ticket fk_frsrho213xcx4wnkog82sspmt; Type: FK CONSTRAINT; Schema: public; Owner: keycloak
--

ALTER TABLE ONLY public.resource_server_perm_ticket
    ADD CONSTRAINT fk_frsrho213xcx4wnkog82sspmt FOREIGN KEY (resource_server_id) REFERENCES public.resource_server(id);


--
-- Name: resource_server_resource fk_frsrho213xcx4wnkog82ssrfy; Type: FK CONSTRAINT; Schema: public; Owner: keycloak
--

ALTER TABLE ONLY public.resource_server_resource
    ADD CONSTRAINT fk_frsrho213xcx4wnkog82ssrfy FOREIGN KEY (resource_server_id) REFERENCES public.resource_server(id);


--
-- Name: resource_server_perm_ticket fk_frsrho213xcx4wnkog83sspmt; Type: FK CONSTRAINT; Schema: public; Owner: keycloak
--

ALTER TABLE ONLY public.resource_server_perm_ticket
    ADD CONSTRAINT fk_frsrho213xcx4wnkog83sspmt FOREIGN KEY (resource_id) REFERENCES public.resource_server_resource(id);


--
-- Name: resource_server_perm_ticket fk_frsrho213xcx4wnkog84sspmt; Type: FK CONSTRAINT; Schema: public; Owner: keycloak
--

ALTER TABLE ONLY public.resource_server_perm_ticket
    ADD CONSTRAINT fk_frsrho213xcx4wnkog84sspmt FOREIGN KEY (scope_id) REFERENCES public.resource_server_scope(id);


--
-- Name: associated_policy fk_frsrpas14xcx4wnkog82ssrfy; Type: FK CONSTRAINT; Schema: public; Owner: keycloak
--

ALTER TABLE ONLY public.associated_policy
    ADD CONSTRAINT fk_frsrpas14xcx4wnkog82ssrfy FOREIGN KEY (policy_id) REFERENCES public.resource_server_policy(id);


--
-- Name: scope_policy fk_frsrpass3xcx4wnkog82ssrfy; Type: FK CONSTRAINT; Schema: public; Owner: keycloak
--

ALTER TABLE ONLY public.scope_policy
    ADD CONSTRAINT fk_frsrpass3xcx4wnkog82ssrfy FOREIGN KEY (scope_id) REFERENCES public.resource_server_scope(id);


--
-- Name: resource_server_perm_ticket fk_frsrpo2128cx4wnkog82ssrfy; Type: FK CONSTRAINT; Schema: public; Owner: keycloak
--

ALTER TABLE ONLY public.resource_server_perm_ticket
    ADD CONSTRAINT fk_frsrpo2128cx4wnkog82ssrfy FOREIGN KEY (policy_id) REFERENCES public.resource_server_policy(id);


--
-- Name: resource_server_policy fk_frsrpo213xcx4wnkog82ssrfy; Type: FK CONSTRAINT; Schema: public; Owner: keycloak
--

ALTER TABLE ONLY public.resource_server_policy
    ADD CONSTRAINT fk_frsrpo213xcx4wnkog82ssrfy FOREIGN KEY (resource_server_id) REFERENCES public.resource_server(id);


--
-- Name: resource_scope fk_frsrpos13xcx4wnkog82ssrfy; Type: FK CONSTRAINT; Schema: public; Owner: keycloak
--

ALTER TABLE ONLY public.resource_scope
    ADD CONSTRAINT fk_frsrpos13xcx4wnkog82ssrfy FOREIGN KEY (resource_id) REFERENCES public.resource_server_resource(id);


--
-- Name: resource_policy fk_frsrpos53xcx4wnkog82ssrfy; Type: FK CONSTRAINT; Schema: public; Owner: keycloak
--

ALTER TABLE ONLY public.resource_policy
    ADD CONSTRAINT fk_frsrpos53xcx4wnkog82ssrfy FOREIGN KEY (resource_id) REFERENCES public.resource_server_resource(id);


--
-- Name: resource_policy fk_frsrpp213xcx4wnkog82ssrfy; Type: FK CONSTRAINT; Schema: public; Owner: keycloak
--

ALTER TABLE ONLY public.resource_policy
    ADD CONSTRAINT fk_frsrpp213xcx4wnkog82ssrfy FOREIGN KEY (policy_id) REFERENCES public.resource_server_policy(id);


--
-- Name: resource_scope fk_frsrps213xcx4wnkog82ssrfy; Type: FK CONSTRAINT; Schema: public; Owner: keycloak
--

ALTER TABLE ONLY public.resource_scope
    ADD CONSTRAINT fk_frsrps213xcx4wnkog82ssrfy FOREIGN KEY (scope_id) REFERENCES public.resource_server_scope(id);


--
-- Name: resource_server_scope fk_frsrso213xcx4wnkog82ssrfy; Type: FK CONSTRAINT; Schema: public; Owner: keycloak
--

ALTER TABLE ONLY public.resource_server_scope
    ADD CONSTRAINT fk_frsrso213xcx4wnkog82ssrfy FOREIGN KEY (resource_server_id) REFERENCES public.resource_server(id);


--
-- Name: composite_role fk_gr7thllb9lu8q4vqa4524jjy8; Type: FK CONSTRAINT; Schema: public; Owner: keycloak
--

ALTER TABLE ONLY public.composite_role
    ADD CONSTRAINT fk_gr7thllb9lu8q4vqa4524jjy8 FOREIGN KEY (child_role) REFERENCES public.keycloak_role(id);


--
-- Name: user_consent_client_scope fk_grntcsnt_clsc_usc; Type: FK CONSTRAINT; Schema: public; Owner: keycloak
--

ALTER TABLE ONLY public.user_consent_client_scope
    ADD CONSTRAINT fk_grntcsnt_clsc_usc FOREIGN KEY (user_consent_id) REFERENCES public.user_consent(id);


--
-- Name: user_consent fk_grntcsnt_user; Type: FK CONSTRAINT; Schema: public; Owner: keycloak
--

ALTER TABLE ONLY public.user_consent
    ADD CONSTRAINT fk_grntcsnt_user FOREIGN KEY (user_id) REFERENCES public.user_entity(id);


--
-- Name: group_attribute fk_group_attribute_group; Type: FK CONSTRAINT; Schema: public; Owner: keycloak
--

ALTER TABLE ONLY public.group_attribute
    ADD CONSTRAINT fk_group_attribute_group FOREIGN KEY (group_id) REFERENCES public.keycloak_group(id);


--
-- Name: group_role_mapping fk_group_role_group; Type: FK CONSTRAINT; Schema: public; Owner: keycloak
--

ALTER TABLE ONLY public.group_role_mapping
    ADD CONSTRAINT fk_group_role_group FOREIGN KEY (group_id) REFERENCES public.keycloak_group(id);


--
-- Name: realm_enabled_event_types fk_h846o4h0w8epx5nwedrf5y69j; Type: FK CONSTRAINT; Schema: public; Owner: keycloak
--

ALTER TABLE ONLY public.realm_enabled_event_types
    ADD CONSTRAINT fk_h846o4h0w8epx5nwedrf5y69j FOREIGN KEY (realm_id) REFERENCES public.realm(id);


--
-- Name: realm_events_listeners fk_h846o4h0w8epx5nxev9f5y69j; Type: FK CONSTRAINT; Schema: public; Owner: keycloak
--

ALTER TABLE ONLY public.realm_events_listeners
    ADD CONSTRAINT fk_h846o4h0w8epx5nxev9f5y69j FOREIGN KEY (realm_id) REFERENCES public.realm(id);


--
-- Name: identity_provider_mapper fk_idpm_realm; Type: FK CONSTRAINT; Schema: public; Owner: keycloak
--

ALTER TABLE ONLY public.identity_provider_mapper
    ADD CONSTRAINT fk_idpm_realm FOREIGN KEY (realm_id) REFERENCES public.realm(id);


--
-- Name: idp_mapper_config fk_idpmconfig; Type: FK CONSTRAINT; Schema: public; Owner: keycloak
--

ALTER TABLE ONLY public.idp_mapper_config
    ADD CONSTRAINT fk_idpmconfig FOREIGN KEY (idp_mapper_id) REFERENCES public.identity_provider_mapper(id);


--
-- Name: web_origins fk_lojpho213xcx4wnkog82ssrfy; Type: FK CONSTRAINT; Schema: public; Owner: keycloak
--

ALTER TABLE ONLY public.web_origins
    ADD CONSTRAINT fk_lojpho213xcx4wnkog82ssrfy FOREIGN KEY (client_id) REFERENCES public.client(id);


--
-- Name: scope_mapping fk_ouse064plmlr732lxjcn1q5f1; Type: FK CONSTRAINT; Schema: public; Owner: keycloak
--

ALTER TABLE ONLY public.scope_mapping
    ADD CONSTRAINT fk_ouse064plmlr732lxjcn1q5f1 FOREIGN KEY (client_id) REFERENCES public.client(id);


--
-- Name: protocol_mapper fk_pcm_realm; Type: FK CONSTRAINT; Schema: public; Owner: keycloak
--

ALTER TABLE ONLY public.protocol_mapper
    ADD CONSTRAINT fk_pcm_realm FOREIGN KEY (client_id) REFERENCES public.client(id);


--
-- Name: credential fk_pfyr0glasqyl0dei3kl69r6v0; Type: FK CONSTRAINT; Schema: public; Owner: keycloak
--

ALTER TABLE ONLY public.credential
    ADD CONSTRAINT fk_pfyr0glasqyl0dei3kl69r6v0 FOREIGN KEY (user_id) REFERENCES public.user_entity(id);


--
-- Name: protocol_mapper_config fk_pmconfig; Type: FK CONSTRAINT; Schema: public; Owner: keycloak
--

ALTER TABLE ONLY public.protocol_mapper_config
    ADD CONSTRAINT fk_pmconfig FOREIGN KEY (protocol_mapper_id) REFERENCES public.protocol_mapper(id);


--
-- Name: default_client_scope fk_r_def_cli_scope_realm; Type: FK CONSTRAINT; Schema: public; Owner: keycloak
--

ALTER TABLE ONLY public.default_client_scope
    ADD CONSTRAINT fk_r_def_cli_scope_realm FOREIGN KEY (realm_id) REFERENCES public.realm(id);


--
-- Name: required_action_provider fk_req_act_realm; Type: FK CONSTRAINT; Schema: public; Owner: keycloak
--

ALTER TABLE ONLY public.required_action_provider
    ADD CONSTRAINT fk_req_act_realm FOREIGN KEY (realm_id) REFERENCES public.realm(id);


--
-- Name: resource_uris fk_resource_server_uris; Type: FK CONSTRAINT; Schema: public; Owner: keycloak
--

ALTER TABLE ONLY public.resource_uris
    ADD CONSTRAINT fk_resource_server_uris FOREIGN KEY (resource_id) REFERENCES public.resource_server_resource(id);


--
-- Name: role_attribute fk_role_attribute_id; Type: FK CONSTRAINT; Schema: public; Owner: keycloak
--

ALTER TABLE ONLY public.role_attribute
    ADD CONSTRAINT fk_role_attribute_id FOREIGN KEY (role_id) REFERENCES public.keycloak_role(id);


--
-- Name: realm_supported_locales fk_supported_locales_realm; Type: FK CONSTRAINT; Schema: public; Owner: keycloak
--

ALTER TABLE ONLY public.realm_supported_locales
    ADD CONSTRAINT fk_supported_locales_realm FOREIGN KEY (realm_id) REFERENCES public.realm(id);


--
-- Name: user_federation_config fk_t13hpu1j94r2ebpekr39x5eu5; Type: FK CONSTRAINT; Schema: public; Owner: keycloak
--

ALTER TABLE ONLY public.user_federation_config
    ADD CONSTRAINT fk_t13hpu1j94r2ebpekr39x5eu5 FOREIGN KEY (user_federation_provider_id) REFERENCES public.user_federation_provider(id);


--
-- Name: user_group_membership fk_user_group_user; Type: FK CONSTRAINT; Schema: public; Owner: keycloak
--

ALTER TABLE ONLY public.user_group_membership
    ADD CONSTRAINT fk_user_group_user FOREIGN KEY (user_id) REFERENCES public.user_entity(id);


--
-- Name: policy_config fkdc34197cf864c4e43; Type: FK CONSTRAINT; Schema: public; Owner: keycloak
--

ALTER TABLE ONLY public.policy_config
    ADD CONSTRAINT fkdc34197cf864c4e43 FOREIGN KEY (policy_id) REFERENCES public.resource_server_policy(id);


--
-- Name: identity_provider_config fkdc4897cf864c4e43; Type: FK CONSTRAINT; Schema: public; Owner: keycloak
--

ALTER TABLE ONLY public.identity_provider_config
    ADD CONSTRAINT fkdc4897cf864c4e43 FOREIGN KEY (identity_provider_id) REFERENCES public.identity_provider(internal_id);


--
-- PostgreSQL database dump complete
--

--
-- Database "postgres" dump
--

\connect postgres

--
-- PostgreSQL database dump
--

-- Dumped from database version 13.3 (Debian 13.3-1.pgdg100+1)
-- Dumped by pg_dump version 13.3 (Debian 13.3-1.pgdg100+1)

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- PostgreSQL database dump complete
--

--
-- PostgreSQL database cluster dump complete
--

